"""Resumable cross-family inference with a shared hard budget and provider price caps."""
import concurrent.futures
import hashlib
import json
import math
import os
import shutil
import sys
import time
import urllib.error
from collections import Counter
from pathlib import Path
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT.parent/'hard_graph_v1'))
from run_pilot import api, final_answer, parse
from prepare import price_bound

class Budget:
    def __init__(self,cap,spent=0):self.cap=cap;self.spent=spent;self.reserved=0
    def reserve(self,value):
        if not math.isfinite(value) or value<0:raise ValueError('Invalid reservation.')
        if self.spent+self.reserved+value>self.cap+1e-12:return False
        self.reserved+=value;return True
    def settle(self,bound,actual):
        if not math.isfinite(actual) or actual<0:raise ValueError('Invalid cost.')
        self.reserved-=bound;self.spent+=actual
        return actual<=bound+1e-9 and self.spent+self.reserved<=self.cap+1e-9

def normalize_record(record):
    row=dict(record)
    if row.get('status')=='ok' and row.get('finish_reason')=='error':
        row['collector_status']='ok';row['status']='error';row['error_type']='provider_finish_error'
    return row

def select_attempts(records):
    selected={}
    for record in records:
        row=normalize_record(record);key=(row['model'],row['id'])
        if key not in selected or selected[key]['status']!='ok':selected[key]=row
    return list(selected.values())

def reasoning(model):
    params=model.get('supported_parameters',[])
    if 'reasoning_effort' in params:return {'effort':'high'}
    if 'reasoning' in params:return {'enabled':True}
    return None

def payload(model,r,rates):
    from benchmark import SYSTEM
    body={'model':model['id'],'messages':[{'role':'system','content':SYSTEM},{'role':'user','content':r['prompt']}],
          'max_tokens':8192,'stream':False,
          'provider':{'sort':'price','require_parameters':True,
                      'max_price':{'prompt':rates['prompt']*1e6,'completion':rates['completion']*1e6,'request':rates['request']}}}
    settings=reasoning(model)
    if settings is not None:body['reasoning']=settings
    return body

def call(model,r,bound,rates,key):
    started=time.time();body=payload(model,r,rates)
    result={**r,'model':model['id'],'family':model['family'],'reserved_usd':bound,
            'request_settings':{k:v for k,v in body.items() if k!='messages'}}
    try:
        response=api('/chat/completions',key,body,timeout=600)
        if response.get('error'):raise ValueError('Provider returned an application error.')
        choice=response['choices'][0];content=choice['message'].get('content') or ''
        if isinstance(content,list):content=''.join(part.get('text','') for part in content if isinstance(part,dict))
        if not isinstance(content,str):raise ValueError('Non-text completion.')
        content=content.replace(key,'[REDACTED]');usage=response.get('usage') or {};cost=usage.get('cost')
        answer=final_answer(content)
        result.update(status='ok',response_id=response.get('id'),provider=response.get('provider'),model_returned=response.get('model'),
                      model_answer=content,parsed_answer=answer,correct=answer==r['ground_truth'],format_compliant=parse(content) is not None,
                      finish_reason=choice.get('finish_reason'),usage=usage,cost_usd=float(cost) if cost is not None else bound,
                      cost_source='provider' if cost is not None else 'reserved_upper_bound')
    except urllib.error.HTTPError as exc:
        message=''
        try:message=exc.read().decode('utf-8',errors='replace').replace(key,'[REDACTED]')[:1200]
        except Exception:pass
        known_free=exc.code in [400,401,402,403,404,422,429]
        result.update(status='error',http_status=exc.code,error=message,cost_usd=0 if known_free else bound,
                      cost_source='pre_generation_rejection' if known_free else 'reserved_uncertain_request')
    except Exception as exc:
        result.update(status='error',error_type=type(exc).__name__,cost_usd=bound,cost_source='reserved_uncertain_request')
    result['latency_seconds']=round(time.time()-started,3)
    return result

def run(resume_blocked=False):
    plan=json.loads((ROOT/'plan.json').read_text());fixture=ROOT/'prompts.json'
    assert hashlib.sha256(fixture.read_bytes()).hexdigest()==plan['prompt_sha256']
    key=os.environ.get('OPENROUTER_API_KEY')
    if not key:raise SystemExit('OPENROUTER_API_KEY is not set.')
    credit=api('/credits',key)['data'];available=credit['total_credits']-credit['total_usage']
    fresh={m['id']:m for m in api('/models',key)['data']}
    profiles={entry['model']:{**fresh[entry['model']],'family':entry['family']} for entry in plan['new_models']}
    assert all('fable' not in model for model in profiles)
    prompts=json.loads(fixture.read_text())
    ledger=ROOT/'results.jsonl';rows=[json.loads(s) for s in ledger.read_text().splitlines()] if ledger.exists() else []
    done={(r['model'],r['id']) for r in rows};spent=sum(r['cost_usd'] for r in rows)
    budget=Budget(min(plan['new_budget_usd'],spent+max(0,available-.5)),spent)
    # Round-robin model order gives breadth early; at most two concurrent calls per model.
    work=[(m,r) for r in prompts for m in profiles if (m,r['id']) not in done]
    blocked=set() if resume_blocked else {r['model'] for r in rows if r['status']=='error'}
    pending={};active=Counter();fatal=False
    if (ROOT/'execution.json').exists():
        shutil.copy2(ROOT/'execution.json',ROOT/('execution_before_resume_'+str(time.time_ns())+'.json'))
    (ROOT/'execution.json').write_text(json.dumps({'prior_spend_usd':plan['prior_recorded_spend_usd'],
         'new_round_cap_usd':budget.cap,'effective_cumulative_cap_usd':plan['prior_recorded_spend_usd']+budget.cap,
         'workers':8,'per_model_concurrency':2,'models':[{k:p.get(k) for k in ['id','family','pricing','supported_parameters','context_length','top_provider','reasoning']} for p in profiles.values()]},indent=2))
    print(json.dumps({'new_planned':len(work),'models':len(profiles),'cap_usd':budget.cap,
                      'resume_previously_blocked_models':resume_blocked}),flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        while pending or (work and not fatal):
            while len(pending)<8 and not fatal:
                picked=None
                for i,(m,r) in enumerate(work):
                    if m in blocked:continue
                    if active[m]>=2:continue
                    bound,rates=price_bound(profiles[m],r['prompt'])
                    if budget.reserve(bound):picked=(i,m,r,bound,rates);break
                if picked is None:break
                i,m,r,bound,rates=picked;work.pop(i);active[m]+=1
                pending[pool.submit(call,profiles[m],r,bound,rates,key)]=(m,bound)
            if not pending:break
            finished,_=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
            for future in finished:
                m,bound=pending.pop(future);active[m]-=1;row=future.result()
                if not budget.settle(bound,row['cost_usd']):fatal=True
                rows.append(row)
                with ledger.open('a',encoding='utf-8') as out:out.write(json.dumps(row)+'\n');out.flush();os.fsync(out.fileno())
                if row['status']=='error':
                    blocked.add(m)
                    if row.get('http_status') in [401,402]:fatal=True
                print(json.dumps({'completed':len(rows),'family':row['family'],'case':row['case_id'],'condition':row['condition'],
                     'status':row['status'],'http_status':row.get('http_status'),'correct':row.get('correct'),
                     'finish_reason':row.get('finish_reason'),'round_cost_usd':round(budget.spent,6)}),flush=True)
                (ROOT/'progress.json').write_text(json.dumps({'responses':len(rows),'planned':plan['new_planned_requests'],
                     'spent_usd':budget.spent,'reserved_usd':budget.reserved,'blocked_models':sorted(blocked),
                     'models':{m:{'responses':sum(r['model']==m for r in rows),'ok':sum(r['model']==m and r['status']=='ok' for r in rows)} for m in profiles}},indent=2))
    print(json.dumps({'finished':True,'responses':len(rows),'spent_usd':budget.spent,'blocked':sorted(blocked),'fatal':fatal}),flush=True)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--resume-blocked',action='store_true',
                        help='After the previous process exits, attempt only never-started slots despite a prior model pause. Existing error slots are never repeated.')
    run(parser.parse_args().resume_blocked)
