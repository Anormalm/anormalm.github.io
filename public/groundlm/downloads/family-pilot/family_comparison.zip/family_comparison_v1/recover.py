"""One bounded recovery attempt for provider errors, after the main batch stops."""
import json
import hashlib
import concurrent.futures
import os
import time
from pathlib import Path
from run import ROOT,Budget,normalize_record,select_attempts,api,call
from prepare import price_bound

def recover():
    plan=json.loads((ROOT/'plan.json').read_text())
    assert hashlib.sha256((ROOT/'prompts.json').read_bytes()).hexdigest()==plan['prompt_sha256']
    base=[json.loads(line) for line in (ROOT/'results.jsonl').read_text().splitlines()]
    if len(base)!=plan['new_planned_requests']:raise SystemExit('Wait until the full main batch has finished.')
    log=ROOT/'recovery_results.jsonl';prior=[json.loads(s) for s in log.read_text().splitlines()] if log.exists() else []
    tried={(r['model'],r['id']) for r in prior}
    candidates=[r for r in select_attempts(base) if r['status']!='ok' and (r['model'],r['id']) not in tried]
    spent=sum(r['cost_usd'] for r in base+prior);budget=Budget(plan['new_budget_usd'],spent)
    key=os.environ['OPENROUTER_API_KEY'];catalog={m['id']:m for m in api('/models',key)['data']}
    prompts={r['id']:r for r in json.loads((ROOT/'prompts.json').read_text())}
    families={m['model']:m['family'] for m in plan['new_models']}
    # Two workers preserve the main run's per-model concurrency ceiling.
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        pending={}
        for r in candidates:
            model={**catalog[r['model']],'family':families[r['model']]};prompt=prompts[r['id']]
            bound,rates=price_bound(model,prompt['prompt'])
            if not budget.reserve(bound):continue
            pending[pool.submit(call,model,prompt,bound,rates,key)]=bound
        print(json.dumps({'provider_recovery_calls':len(pending),'starting_cost_usd':spent,'cap_usd':budget.cap}),flush=True)
        for future in concurrent.futures.as_completed(pending):
            bound=pending[future];answer=future.result()
            answer.update(attempt=2,reason='one provider-error recovery; never retry model answers')
            safe=budget.settle(bound,answer['cost_usd'])
            with log.open('a',encoding='utf-8') as out:out.write(json.dumps(answer)+'\n');out.flush();os.fsync(out.fileno())
            print(json.dumps({'model':answer['model'],'id':answer['id'],'status':normalize_record(answer)['status'],'finish_reason':answer.get('finish_reason'),'round_cost_usd':budget.spent,'within_bound':safe}),flush=True)

if __name__=='__main__':recover()
