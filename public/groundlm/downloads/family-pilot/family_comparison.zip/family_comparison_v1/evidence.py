"""Exact witnesses for shared questions and a complete completed-error index."""
import hashlib
import itertools
import json
from pathlib import Path
import networkx as nx
ROOT=Path(__file__).parent

def build():
    rows=json.loads((ROOT/'scored_results.json').read_text())
    cases={c['id']:c for c in json.loads((ROOT.parent/'hard_graph_v1/replication/cases.json').read_text())}
    out=ROOT/'evidence';out.mkdir(exist_ok=True);selected={r['case_id'] for r in rows}
    for cid in selected:
        c=cases[cid];g=nx.Graph();g.add_nodes_from(range(c['n']));g.add_weighted_edges_from(c['edges']);s,t=c['source'],c['target']
        proof={'case_id':cid,'task':c['task'],'answer':c['answer'],'n':c['n'],'source':s,'target':t,'edges':c['edges']}
        if c['task']=='triangle_count':
            triangles=[list(v) for v in itertools.combinations(g,3) if all(g.has_edge(a,b) for a,b in itertools.combinations(v,2))]
            assert len(triangles)==c['answer'];proof['triangles']=triangles
        elif c['task']=='weighted_shortest_path':
            d,paths=nx.single_source_dijkstra(g,s,weight='weight');path=paths[t]
            assert d[t]==c['answer'] and sum(g[a][b]['weight'] for a,b in zip(path,path[1:]))==c['answer']
            assert all(abs(d[a]-d[b])<=data['weight'] for a,b,data in g.edges(data=True))
            proof.update(path=path,distances=d)
        else:
            value,(left,right)=nx.minimum_cut(g,s,t,capacity='weight')
            flow_value,flow=nx.maximum_flow(g,s,t,capacity='weight',flow_func=nx.algorithms.flow.edmonds_karp)
            cut=[[a,b,data['weight']] for a,b,data in g.edges(data=True) if (a in left)!=(b in left)]
            assert value==flow_value==sum(w for a,b,w in cut)==c['answer']
            for a in g:
                assert all(0<=flow[a][b]<=g[a][b]['weight'] for b in g.neighbors(a))
                assert sum(flow[a].values())-sum(flow[b].get(a,0) for b in g)==(value if a==s else -value if a==t else 0)
            proof.update(source_side=sorted(left),target_side=sorted(right),cut_edges=cut,flow=flow)
        (out/(cid+'.json')).write_text(json.dumps(proof,indent=2))
    failures=[]
    for r in rows:
        if r['status']!='ok' or r['finish_reason']=='length' or r['parsed_answer'] is None or r['correct']:continue
        name=r['model'].replace('/','__')+'__'+r['id']+'.json'
        labels=r['prompt'].split('complete node set is:\n')[1].split('\nThe complete edge list')[0].split(', ')
        record={**r,'node_index_to_prompt_identifier':labels,'oracle_witness':r['case_id']+'.json'}
        (out/name).write_text(json.dumps(record,indent=2),encoding='utf-8')
        failures.append({k:r[k] for k in ['model','family','case_id','condition','ground_truth','parsed_answer','comparison_source']})
    (out/'completed_errors.json').write_text(json.dumps(failures,indent=2))
    print(f'Verified all {len(selected)} shared ground truths; saved {len(failures)} completed numeric-error responses.')

if __name__=='__main__':build()
