"""Audit completed coverage, preserve a spending ledger, and export the local bundle.

This script makes no network requests and never runs inference.
"""
import collections
import datetime
import hashlib
import importlib.metadata
import json
import math
import os
import platform
import re
import zipfile
from pathlib import Path

from run import normalize_record, select_attempts

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def finalize():
    plan = json.loads((ROOT / 'plan.json').read_text())
    prompts = json.loads((ROOT / 'prompts.json').read_text())
    prompt_map = {r['id']: r for r in prompts}
    models = {m['model'] for m in plan['new_models']}
    expected = {(m, p) for m in models for p in prompt_map}
    base = [json.loads(s) for s in (ROOT / 'results.jsonl').read_text().splitlines()]
    recovery_path = ROOT / 'recovery_results.jsonl'
    recovery = [json.loads(s) for s in recovery_path.read_text().splitlines()] if recovery_path.exists() else []
    refs = json.loads((ROOT / 'claude_reference_results.json').read_text())
    key_of = lambda r: (r['model'], r['id'])
    assert len(base) == len(expected) == plan['new_planned_requests'] == 456
    assert {key_of(r) for r in base} == expected
    assert len({key_of(r) for r in base}) == len(base)
    assert len({key_of(r) for r in recovery}) == len(recovery)
    initial = {key_of(r): normalize_record(r) for r in base}
    for r in recovery:
        assert initial[key_of(r)]['status'] != 'ok', 'Only provider errors can be retried.'
        assert r['attempt'] == 2
    chosen = select_attempts(base + recovery)
    assert len(chosen) == 456 and {key_of(r) for r in chosen} == expected
    assert len(refs) == 48
    assert {key_of(r) for r in refs} == {(m, p) for m in plan['reused_models'] for p in prompt_map}
    assert sha(ROOT / 'prompts.json') == plan['prompt_sha256']
    for r in base + recovery + refs:
        p = prompt_map[r['id']]
        assert all(r[k] == p[k] for k in ('prompt', 'ground_truth', 'case_id', 'condition', 'task'))
        assert math.isfinite(r['cost_usd']) and r['cost_usd'] >= 0
        assert 'fable' not in r['model'] and 'astra' not in r['model']
    for r in base + recovery:
        assert r['request_settings']['model'] == r['model']
        assert r['request_settings']['max_tokens'] == 8192
    generation_ids = [r['response_id'] for r in base + recovery if r.get('response_id')]
    assert len(set(generation_ids)) == len(generation_ids)

    # Independently reconstruct each serialized graph from its node and edge text.
    cases = {c['id']: c for c in json.loads((ROOT.parent / 'hard_graph_v1/replication/cases.json').read_text())}
    for p in prompts:
        c = cases[p['case_id']]
        labels = p['prompt'].split('complete node set is:\n')[1].split('\nThe complete edge list')[0].split(', ')
        assert len(labels) == c['n'] == len(set(labels))
        edge_text = p['prompt'].split('The complete edge list is:\n')[1].split('\n\nQuestion:')[0]
        actual = set()
        for line in edge_text.splitlines():
            match = re.fullmatch(r'(\S+) -- (\S+)(?: \[weight=(\d+)\])?', line)
            assert match, line
            a, b, weight = match.groups()
            actual.add((frozenset((labels.index(a), labels.index(b))), int(weight) if weight else 1))
        expected_edges = {(frozenset((a, b)), 1 if c['task'] == 'triangle_count' else w) for a, b, w in c['edges']}
        assert actual == expected_edges and len(actual) == len(edge_text.splitlines())
        if c['task'] == 'weighted_shortest_path':
            assert f"a path from {labels[c['source']]} to {labels[c['target']]}?" in p['prompt']
        elif c['task'] == 'minimum_cut':
            assert f"disconnects {labels[c['source']]} from {labels[c['target']]}?" in p['prompt']
        assert p['ground_truth'] == c['answer']

    summary = json.loads((ROOT / 'summary.json').read_text())
    assert summary['new_requests'] == 456 and summary['reused_requests'] == 48
    for m, result in summary['models'].items():
        assert result['responses'] == 24
        assert sum(result[k] for k in ('correct', 'completed_numeric_wrong', 'invalid_completed', 'cutoffs', 'api_errors')) == 24
    spent = math.fsum(r['cost_usd'] for r in base + recovery)
    assert spent <= plan['new_budget_usd']
    assert math.isclose(spent, summary['new_cost_usd'], abs_tol=1e-9)
    ledger = {
        'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'additional_authorized_usd': plan['new_budget_usd'],
        'prior_recorded_spend_usd': plan['prior_recorded_spend_usd'],
        'new_cost_usd': spent,
        'remaining_additional_budget_usd': plan['new_budget_usd'] - spent,
        'cumulative_recorded_cost_usd': plan['prior_recorded_spend_usd'] + spent,
        'unique_new_slots': len(chosen), 'base_attempts': len(base),
        'provider_recovery_attempts': len(recovery), 'reused_claude_slots': len(refs),
        'new_model_slot_counts': dict(sorted(collections.Counter(r['model'] for r in chosen).items())),
        'cost_sources': dict(collections.Counter(r['cost_source'] for r in base + recovery)),
        'uncertain_cost_upper_bound_usd': summary['uncertain_cost_upper_bound_usd'],
        'raw_sha256': {p.name: sha(p) for p in (ROOT / 'results.jsonl', recovery_path) if p.exists()},
        'audit': 'All coverage, frozen prompt, graph equivalence, retry policy, accounting and score partition checks passed.'
    }
    (ROOT / 'spending_ledger.json').write_text(json.dumps(ledger, indent=2) + '\n')
    environment = {'python': platform.python_version(), 'platform': platform.platform(),
                   'packages': {name: importlib.metadata.version(name) for name in ('networkx', 'matplotlib', 'numpy')}}
    (ROOT / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
    helper_paths = [ROOT.parent / 'hard_graph_v1' / name for name in (
        'benchmark.py', 'run_pilot.py', 'replication/cases.json', 'replication/prompts.json',
        'runs/replication01/results.jsonl')]
    source = sorted(ROOT.glob('*.py')) + helper_paths
    (ROOT / 'source_manifest.json').write_text(json.dumps({str(p.relative_to(ROOT.parent)): sha(p) for p in source}, indent=2) + '\n')
    files = sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts) + helper_paths
    secret = os.environ.get('OPENROUTER_API_KEY', '').encode()
    if secret:
        assert all(secret not in p.read_bytes() for p in files), 'Credential detected in export.'
    archive = ROOT.parents[1] / 'output/benchmarks/family_comparison.zip'
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for path in files:
            z.write(path, path.relative_to(ROOT.parent))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    print(json.dumps({'audit': 'passed', 'new_slots': len(chosen), 'attempts': len(base) + len(recovery),
                      'new_cost_usd': spent, 'remaining_usd': plan['new_budget_usd'] - spent,
                      'bundle': str(archive), 'bundle_sha256': sha(archive)}))


if __name__ == '__main__':
    finalize()
