"""Matched-prompt family summaries; historical Claude references are not re-billed."""
import csv
import json
import sys
from statistics import median
from pathlib import Path
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT.parent/'hard_graph_v1'))
from run_pilot import final_answer
from run import normalize_record, select_attempts

def analyze():
    plan=json.loads((ROOT/'plan.json').read_text());raw=ROOT/'results.jsonl'
    new=[json.loads(line) for line in raw.read_text().splitlines()] if raw.exists() else []
    recovery=ROOT/'recovery_results.jsonl'
    recovered=[json.loads(line) for line in recovery.read_text().splitlines()] if recovery.exists() else []
    attempts=new+recovered;new=select_attempts(attempts)
    refs=json.loads((ROOT/'claude_reference_results.json').read_text())
    rows=[{**normalize_record(r),'comparison_source':'new'} for r in new]+[{**normalize_record(r),'family':'Claude','comparison_source':'historical'} for r in refs]
    for r in rows:
        if r['status']=='ok':r['parsed_answer']=final_answer(r['model_answer']);r['correct']=r['parsed_answer']==r['ground_truth']
    profiles={m['model']:m for m in plan['new_models']}
    for m in plan['reused_models']:profiles[m]={'family':'Claude','selection_note':'Reused matched prompts, high reasoning effort, 8192 max tokens; historical provider routing differs.'}
    models={}
    for model,profile in profiles.items():
        rr=[r for r in rows if r['model']==model];ok=[r for r in rr if r['status']=='ok'];groups={}
        for r in ok:groups.setdefault(r['case_id'],{})[r['condition']]=r
        b=[r for r in ok if r['condition']=='original']
        m={'family':profile['family'],'responses':len(rr),'successful_responses':len(ok),'planned':24,
           'correct':sum(r['correct'] for r in ok),'original_correct':sum(r['correct'] for r in b),'original_n':len(b),
           'completed_numeric_wrong':sum(r['finish_reason']!='length' and r['parsed_answer'] is not None and not r['correct'] for r in ok),
           'invalid_completed':sum(r['finish_reason']!='length' and r['parsed_answer'] is None for r in ok),
           'cutoffs':sum(r['finish_reason']=='length' and not r['correct'] for r in ok),
           'length_finish_count':sum(r['finish_reason']=='length' for r in ok),'api_errors':len(rr)-len(ok),
           'provider_error_attempts':sum(normalize_record(r)['status']!='ok' for r in attempts if r['model']==model),
           'over_requested_completion_allowance':sum(r.get('usage',{}).get('completion_tokens',0)>8192 for r in ok),
           'max_reported_completion_tokens':max([r.get('usage',{}).get('completion_tokens',0) for r in ok],default=0),
           'providers':sorted({r.get('provider') or 'not returned' for r in ok}),
           'returned_model_ids':sorted({r.get('model_returned') or 'not returned' for r in ok}),
           'median_latency_seconds':median([r.get('latency_seconds',r.get('latency_ms',0)/1000) for r in ok]) if ok else None,
           'new_cost_usd':sum(r['cost_usd'] for r in attempts if r['model']==model),
           'reused':model in plan['reused_models'],'selection_note':profile['selection_note'],'conditions':{},'tasks':{},'renaming':{}}
        for field,groupsource in [('conditions','condition'),('tasks','task')]:
            for v in dict.fromkeys(r[groupsource] for r in ok):
                subset=[r for r in ok if r[groupsource]==v]
                m[field][v]={'correct':sum(r['correct'] for r in subset),'n':len(subset),'cutoffs':sum(r['finish_reason']=='length' for r in subset)}
        for condition in ['neutral_relabel','semantic_congruent','semantic_incongruent']:
            pairs=[];survival=[];flips=[]
            for cid,g in groups.items():
                original=g.get('original');changed=g.get(condition)
                if not original or not changed:continue
                if original['parsed_answer'] is not None and changed['parsed_answer'] is not None:pairs.append(int(original['parsed_answer']==changed['parsed_answer']))
                if original['correct']:
                    survival.append(int(changed['correct']))
                    if not changed['correct']:flips.append({'case_id':cid,'expected':changed['ground_truth'],'answer':changed['parsed_answer'],'finish_reason':changed['finish_reason']})
            m['renaming'][condition]={'consistency':sum(pairs)/len(pairs) if pairs else None,'pairs':len(pairs),
                                      'conditional_survival':sum(survival)/len(survival) if survival else None,'initially_correct_pairs':len(survival),'flips':flips}
        models[model]=m
    cost=sum(r['cost_usd'] for r in attempts)
    uncertain=sum(r['cost_usd'] for r in attempts if r.get('cost_source') not in ['provider','pre_generation_rejection'])
    report={'new_requests':len(new),'new_request_attempts':len(attempts),'recovery_attempts':len(recovered),'new_planned_requests':plan['new_planned_requests'],'reused_requests':len(refs),
            'new_cost_usd':cost,'uncertain_cost_upper_bound_usd':uncertain,'prior_cost_usd':plan['prior_recorded_spend_usd'],'combined_recorded_cost_usd':cost+plan['prior_recorded_spend_usd'],
            'remaining_new_budget_usd':plan['new_budget_usd']-cost,'models':models}
    (ROOT/'summary.json').write_text(json.dumps(report,indent=2));(ROOT/'scored_results.json').write_text(json.dumps(rows,indent=2))
    fields=['model','family','responses','correct','original_correct','original_n','completed_numeric_wrong','invalid_completed','cutoffs','api_errors','new_cost_usd','reused']
    with (ROOT/'metrics.csv').open('w',newline='',encoding='utf-8') as out:
        writer=csv.DictWriter(out,fieldnames=fields);writer.writeheader()
        for model,m in models.items():writer.writerow({'model':model,**{k:m[k] for k in fields if k!='model'}})
    total_scored=sum(m['responses'] for m in models.values())
    total_cutoffs=sum(m['cutoffs'] for m in models.values())
    total_wrong=sum(m['completed_numeric_wrong'] for m in models.values())
    lines=['# Broad model-family graph pilot','',
           f'New requests: **{len(new)}/{plan["new_planned_requests"]}**; matched Claude reference responses reused: **{len(refs)}**. New recorded/charged upper-bound cost: **US${cost:.4f}** of the US$20 additional cap.','',
           'Six shared graph questions (three tasks, 32/64 nodes, first fixed seed per cell), each in four naming conditions. Each model has only six independent questions. This is a family-coverage pilot, not a precise ranking of frontier capabilities.','',
           f'Across {total_scored} scored slots, there are {total_wrong} completed numeric mistakes and {total_cutoffs} unsuccessful token cutoffs. Many low correct-answer rates are therefore resource-limit failures rather than completed incorrect judgments. Do not use this table as an equal-compute capability ranking.', '',
           f'Uncertain request charges are conservatively reserved at **US${uncertain:.6f}** within the reported spending total. Provider-reported charges account for the rest; a timed-out request may ultimately have cost less than its reserved bound.', '',
           '| Model | Correct / returned | Original | Completed wrong | Invalid | Cutoffs | API errors | New cost |',
           '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for model,m in models.items():
        charged='reused' if m['reused'] else f'${m["new_cost_usd"]:.4f}'
        lines.append(f'| {model} | {m["correct"]}/{m["successful_responses"]} | {m["original_correct"]}/{m["original_n"]} | {m["completed_numeric_wrong"]} | {m["invalid_completed"]} | {m["cutoffs"]} | {m["api_errors"]} | {charged} |')
    lines += ['', '## Outcomes by task and naming condition', '',
              'Counts below include cutoffs as unsuccessful responses. They are not accuracy conditional on finishing. Each task has two independent graphs, and each naming condition has six.', '',
              '| Model | Shortest path /8 | Triangles /8 | Minimum cut /8 | Original /6 | Neutral /6 | Degree-aligned /6 | Reverse-degree /6 |',
              '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for model,m in models.items():
        values=[m['tasks'].get(k,{}).get('correct',0) for k in ['weighted_shortest_path','triangle_count','minimum_cut']]
        values += [m['conditions'].get(k,{}).get('correct',0) for k in ['original','neutral_relabel','semantic_congruent','semantic_incongruent']]
        lines.append('| '+model+' | '+' | '.join(str(v) for v in values)+' |')
    lines += ['', '## Completed answer changes from correct originals', '',
              'These are recorded paired observations with the same graph and question. Token cutoffs and invalid answers are omitted from this table. With one sample per prompt and provider-default sampling, the observations do not isolate semantic meaning from sampling variance or tokenization effects.', '',
              '| Model | Case | Renaming | Correct original | Renamed answer |',
              '| --- | --- | --- | ---: | ---: |']
    for model,m in models.items():
        for condition,result in m['renaming'].items():
            for flip in result['flips']:
                if flip['finish_reason']!='length' and flip['answer'] is not None:
                    lines.append(f'| {model} | {flip["case_id"]} | {condition} | {flip["expected"]} | {flip["answer"]} |')
    lines += ['', '## Compute and availability audit', '',
              '| Model | Maximum billed completion tokens | Responses above requested 8,192 | Failed provider attempts retained |',
              '| --- | ---: | ---: | ---: |']
    for model,m in models.items():
        lines.append(f'| {model} | {m["max_reported_completion_tokens"]} | {m["over_requested_completion_allowance"]} | {m["provider_error_attempts"]} |')
    lines += ['', 'The exact ground-truth certificates and every completed numeric mistake are in `evidence/`. Final coverage, serialized-graph equivalence, retry policy and spending checks are recorded by `finalize.py` in `spending_ledger.json`. Raw provider attempt history is preserved even when an infrastructure error is recovered.', '', '## Selection and availability','',
              'Selection source: [Artificial Analysis model leaderboard](https://artificialanalysis.ai/leaderboards/models), checked 2026-11-02; model IDs and tariffs verified through the authenticated OpenRouter catalog. AA scores use its own reasoning settings; this experiment does not reproduce the AA evaluation or claim matching compute.', '',
              'Fable is excluded. GPT-6 Astra is excluded for its Fable-like output tariff; GPT-6.1 Sol is the price-aware OpenAI frontier alternative. Gemini Carbon and Muse Wonder Full were absent from the router catalog: Argon and Muse Wonder are explicit available substitutes. Nova Lite, Granite, Gemma and Llama are family controls; they are not all claimed to be overall SOTA.','']
    for model,m in models.items():lines.append(f'- `{model}`: {m["selection_note"]}')
    lines += ['', '## Interpretation','',
              f'Provider recovery attempts: {len(recovered)}. Only infrastructure/provider failures may be attempted once more. Incorrect answers and token cutoffs are never retried. Scoring uses the first valid model response for each model/prompt; all failed attempts and their costs remain in the raw files and spending total.', '',
              'Budget amendment: Grok exceeded the requested completion allowance because its visible-output limit excludes hidden reasoning. The guard paused at US$1.27; the original full-plan estimate was superseded. Future Grok calls reserve its full declared capacity plus the visible allowance. Original results and settings are retained. Grok must not be interpreted as receiving the same total-token cap as the other models. See budget_amendment.json and actual per-response usage.', '',
              'Every request specifies max_tokens=8192. Most services apply this to reasoning plus visible output; Grok applies it only to visible output, so total compute is not matched. High reasoning effort is requested only when the catalog advertises an effort parameter; otherwise reasoning is enabled at its default when supported, or omitted for non-reasoning models. Temperature is omitted for all models. Settings, returned model identity, provider, latency, token usage and raw answers are retained.', '',
              'Consistency excludes unparseable pairs; conditional survival treats an unparseable renamed answer as a failure among initially correct pairs. HTTP/provider failures are availability errors, not graph-reasoning mistakes. Cutoffs are not completed numeric errors. Explicit terminal JSON answers are parsed consistently for every model.', '',
              'Provider prices are capped per request. Tier-aware reservations cover the maximum output allowance and a conservative input bound. An error blocks further automatic requests to that model; authentication/credit errors halt the batch. No automatic inference retries occur. Historical Claude references have identical prompts and requested reasoning/output budgets, but were collected earlier with different provider-routing preferences.', '',
              'One response per prompt does not measure repeat variability. Degree-based names are not task-specific congruence, and semantic names change token length. All sampled questions are retained. Do not attribute a small score difference or a renamed-answer change solely to semantic meaning.', '',
              'See `plan.json` for every selection, checkpoint, tariff, exclusion and frozen prompt hash; `results.jsonl` contains new immutable response records, `scored_results.json` adds re-scoring and Claude references, and `metrics.csv` provides the summary table.']
    (ROOT/'REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'new_requests':len(new),'new_cost_usd':cost,'models_with_responses':sum(m['responses']>0 for m in models.values()),'api_errors':sum(m['api_errors'] for m in models.values())}))
    return report

if __name__=='__main__':analyze()
