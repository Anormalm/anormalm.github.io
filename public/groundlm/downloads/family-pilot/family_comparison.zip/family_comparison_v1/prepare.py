"""Freeze a price-aware, shared cross-family pilot before inference."""
import datetime
import hashlib
import json
import sys
from pathlib import Path
ROOT=Path(__file__).parent
sys.path.insert(0,str(ROOT.parent/'hard_graph_v1'))
from benchmark import SYSTEM

# Index entries are selection references; their reasoning settings are not reproduced.
SELECTION=[
 ('Grok','x-ai/grok-4.7',35,'AA high; newest listed Grok'),
 ('Qwen','qwen/qwen3.8-max-0902',34,'AA Max 0902 exact checkpoint'),
 ('GPT','openai/gpt-6.1-sol',55,'AA max; price-aware frontier alternative to Astra'),
 ('Gemini','google/gemini-4-argon',50,'AA high; Carbon absent from router catalog'),
 ('DeepSeek','deepseek/deepseek-v4.1-flash-1017',32,'AA max; higher-ranked than older Pro'),
 ('Kimi','moonshotai/kimi-k3.1-pro',46,'AA listed leading Kimi'),
 ('Muse','meta/muse-wonder',43,'AA max; Wonder Full absent from router catalog'),
 ('GLM','z-ai/glm-5.3',32,'AA max; leading ranked GLM checkpoint'),
 ('MiMo','xiaomi/mimo-v2.6-pro',30,'AA listed Pro'),
 ('MiniMax','minimax/minimax-m3.1-flash',29,'AA listed M3.1 Flash above older M3'),
 ('Step','stepfun/step-5-preview',29,'AA listed preview checkpoint'),
 ('Mistral','mistralai/mistral-large-4-0',26,'AA high; current Large'),
 ('Nemotron','nvidia/nemotron-3.5-super-vl',14,'AA listed above older Ultra'),
 ('Ling','inclusionai/ling-3.1-flash',29,'AA listed current Flash'),
 ('Command','cohere/command-a-plus',6,'Current ranked Cohere family representative'),
 ('Nova','amazon/nova-2-lite-v1',None,'Latest available Nova generation; indexed Pro/Omni unavailable here'),
 ('Granite','ibm-granite/granite-4.2-8b',5,'Current ranked available Granite'),
 ('Gemma','google/gemma-4-31b-it',None,'Open-weight Gemma family control; no matched index score recorded'),
 ('Llama','meta-llama/llama-4-maverick',None,'Llama-family legacy control; not claimed as a frontier winner'),
]

def price_bound(model,prompt,max_tokens=8192):
    token_bound=len((SYSTEM+prompt).encode())+4096
    prices=[model['pricing']]
    for tier in model['pricing'].get('overrides',[]):
        if tier.get('min_prompt_tokens',0)>token_bound:continue
        prices.append(tier)
    rates={k:max(float(p.get(k,0)) for p in prices) for k in ['prompt','completion','request']}
    if any(v<0 for v in rates.values()):raise ValueError('Dynamic/unknown prices are unsupported.')
    completion_bound=max_tokens
    if model.get('id','').startswith('x-ai/grok-4.7'):
        # xAI's limit covers visible text only, not internal reasoning. Reserve
        # the full declared model capacity plus the visible allowance instead.
        completion_bound=max(model.get('context_length',500000),model.get('top_provider',{}).get('max_completion_tokens') or 0)+max_tokens
    return token_bound*rates['prompt']+completion_bound*rates['completion']+rates['request'],rates

def prepare():
    if (ROOT/'plan.json').exists():raise SystemExit('Plan already frozen; not overwritten.')
    catalog={m['id']:m for m in json.loads((ROOT/'catalog_snapshot.json').read_text())}
    original=ROOT.parent/'hard_graph_v1/replication/prompts.json'
    prompts=[r for r in json.loads(original.read_text()) if r['replicate']==0]
    assert len(prompts)==24 and len({r['case_id'] for r in prompts})==6
    selected=[];upper=0
    for family,model,score,note in SELECTION:
        entry=catalog[model];assert 'fable' not in model
        assert float(entry['pricing']['completion'])<.000025
        bounds=[price_bound(entry,r['prompt'])[0] for r in prompts]
        selected.append({'family':family,'model':model,'aa_reference_score':score,'selection_note':note,
                         'maximum_output_tokens':8192,'supported_parameters':entry.get('supported_parameters',[]),
                         'pricing':entry['pricing'],'conservative_plan_usd':sum(bounds)})
        upper+=sum(bounds)
    # A provider-specific worst-case reasoning reservation can exceed the total
    # budget for a full plan; execution admits calls against the hard live cap.
    source_rows=[json.loads(line) for line in (ROOT.parent/'hard_graph_v1/runs/replication01/results.jsonl').read_text().splitlines()]
    prompt_map={p['id']:p for p in prompts};refs=[r for r in source_rows if r['id'] in prompt_map]
    assert len(refs)==48 and all(r['prompt']==prompt_map[r['id']]['prompt'] for r in refs)
    (ROOT/'prompts.json').write_text(json.dumps(prompts,indent=2))
    (ROOT/'claude_reference_results.json').write_text(json.dumps(refs,indent=2))
    old_cost=sum(json.loads(line)['cost_usd'] for f in (ROOT.parent/'hard_graph_v1/runs').glob('*/results.jsonl') for line in f.read_text().splitlines())
    plan={'version':'family-comparison-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'selection_source':'https://artificialanalysis.ai/leaderboards/models','selection_source_date':'2026-11-02',
          'pricing_source':'https://openrouter.ai/api/v1/models','new_budget_usd':20,'prior_recorded_spend_usd':old_cost,
          'prompt_sha256':hashlib.sha256((ROOT/'prompts.json').read_bytes()).hexdigest(),
          'new_models':selected,'reused_models':['anthropic/claude-sonnet-5.5','anthropic/claude-opus-5.5'],
          'independent_cases':6,'prompts_per_model':24,'new_planned_requests':len(selected)*24,'reused_requests':48,
          'full_plan_upper_bound_usd':upper,'reasoning_policy':'high effort when advertised; otherwise enable reasoning when available, otherwise omit',
          'temperature':'service default, omitted for every model','system_prompt':SYSTEM,
          'exclusions':{'anthropic/claude-fable':'explicit user exclusion','openai/gpt-6-astra':'Fable-like output tariff; use Sol for budget',
                        'google/gemini-4-carbon':'absent from available router catalog','meta/muse-wonder-full':'absent from available router catalog'},
          'interpretation':'Family-coverage pilot, not every SOTA checkpoint. Small paired sample. AA scores are selection references at their listed settings, not this graph run.'}
    (ROOT/'plan.json').write_text(json.dumps(plan,indent=2))
    print(json.dumps({'models_new':len(selected),'new_requests':len(selected)*24,'claude_reused':48,'conservative_upper_bound_usd':upper,'new_budget_usd':20}))

if __name__=='__main__':prepare()
