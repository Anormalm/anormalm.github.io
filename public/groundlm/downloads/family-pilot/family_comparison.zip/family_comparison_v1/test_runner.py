import json
import unittest
from pathlib import Path
from run import Budget,payload,reasoning,normalize_record,select_attempts
from prepare import price_bound
ROOT=Path(__file__).parent

class RunnerTests(unittest.TestCase):
    def test_recovery_never_selects_a_better_second_model_answer(self):
        wrong={'model':'m','id':'x','status':'ok','finish_reason':'stop','correct':False}
        correct={**wrong,'correct':True}
        self.assertFalse(select_attempts([wrong,correct])[0]['correct'])
        error={**wrong,'finish_reason':'error'}
        self.assertTrue(select_attempts([error,correct])[0]['correct'])
        cutoff={**wrong,'finish_reason':'length'}
        self.assertFalse(select_attempts([cutoff,correct])[0]['correct'])
    def test_inband_provider_errors_are_not_graph_mistakes(self):
        original={'status':'ok','finish_reason':'error','parsed_answer':None,'cost_usd':0}
        scored=normalize_record(original)
        self.assertEqual(scored['status'],'error');self.assertEqual(original['status'],'ok')
        self.assertEqual(normalize_record({'status':'ok','finish_reason':'length'})['status'],'ok')
    def test_budget_reserves_inflight_costs(self):
        b=Budget(1)
        self.assertTrue(b.reserve(.6));self.assertFalse(b.reserve(.6))
        self.assertTrue(b.settle(.6,.2));self.assertTrue(b.reserve(.7))
        self.assertFalse(b.reserve(.2));self.assertTrue(b.settle(.7,.7));self.assertAlmostEqual(b.spent,.9)
    def test_tiers_respect_context_bound_and_peak_time_rate(self):
        m={'pricing':{'prompt':'0.000002','completion':'0.00001','overrides':[{'min_prompt_tokens':272000,'prompt':'0.001','completion':'0.001'}]}}
        cost,rates=price_bound(m,'short');self.assertEqual(rates['completion'],.00001)
        m['pricing']['overrides']=[{'utc_start':0,'utc_end':2400,'completion':'0.00002'}]
        self.assertEqual(price_bound(m,'short')[1]['completion'],.00002)
    def test_no_label_or_key_leaks_to_payload(self):
        m={'id':'test','supported_parameters':['reasoning_effort']};r={'prompt':'graph','ground_truth':27}
        body=payload(m,r,{'prompt':.000002,'completion':.00001,'request':0})
        self.assertEqual(body['messages'][1]['content'],'graph');self.assertNotIn('ground_truth',str(body))
        self.assertEqual(body['provider']['max_price']['completion'],10)
        self.assertEqual(body['reasoning'],{'effort':'high'});self.assertIsNone(reasoning({'supported_parameters':[]}))
    def test_original_frozen_plan_and_matched_references(self):
        plan=json.loads((ROOT/'plan.json').read_text());self.assertLess(plan['full_plan_upper_bound_usd'],20)
        self.assertEqual(plan['new_planned_requests'],456)
        self.assertFalse(any('fable' in m['model'] for m in plan['new_models']))
        prompts={r['id']:r for r in json.loads((ROOT/'prompts.json').read_text())}
        refs=json.loads((ROOT/'claude_reference_results.json').read_text());self.assertEqual(len(refs),48)
        for r in refs:self.assertEqual(r['prompt'],prompts[r['id']]['prompt'])
    def test_grok_reserves_hidden_reasoning_outside_visible_cap(self):
        m={'id':'x-ai/grok-4.7','context_length':500000,'pricing':{'prompt':'0.000002','completion':'0.000006'}}
        self.assertGreater(price_bound(m,'short')[0],500000*.000006)

if __name__=='__main__':unittest.main()
