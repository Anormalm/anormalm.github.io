"""Export a static coverage/results figure without treating 24 variants as independent."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).parent

def plot():
    summary=json.loads((ROOT/'summary.json').read_text())
    catalog={m['id']:m for m in json.loads((ROOT/'catalog_snapshot.json').read_text())}
    ids=list(summary['models']);fig,(ax,table)=plt.subplots(1,2,figsize=(14,12),gridspec_kw={'width_ratios':[3.2,1.25]},sharey=True)
    names=[]
    styles=[('correct','#123348',None,'Correct'),('completed_numeric_wrong','#c36537',None,'Completed numeric wrong'),
            ('invalid_completed','#e5c6ae','//','Invalid completed answer'),('cutoffs','#bac2c7',None,'Token cutoff'),
            ('api_errors','white','xx','API error')]
    for i,id in enumerate(ids):
        m=summary['models'][id];label=catalog.get(id,{}).get('name',id).split(': ',1)[-1]+(' *' if m['reused'] else '')+(' †' if id.startswith('x-ai/grok-4.7') else '')
        names.append(label);left=0
        for key,color,hatch,legend in styles:
            value=m[key];ax.barh(i,value,left=left,color=color,hatch=hatch,edgecolor='#777' if key=='api_errors' else 'none',label=legend if i==0 else None);left+=value
        if left<24:ax.barh(i,24-left,left=left,color='white',edgecolor='#d1d7d8',linewidth=.8)
        ax.text(.3,i,str(m['correct']),va='center',ha='left',color='white' if m['correct']>0 else '#123348',fontsize=10)
        table.text(.05,i,f'{m["original_correct"]}/{m["original_n"]}',va='center',fontsize=10)
        table.text(.55,i,'reused' if m['reused'] else f'${m["new_cost_usd"]:.3f}',va='center',fontsize=10)
    ax.set_yticks(range(len(ids)),names);ax.invert_yaxis();ax.set_xlim(0,24);ax.set_xticks(range(0,25,4))
    ax.set_xlabel('Responses across 6 shared questions × 4 naming conditions')
    ax.spines[['top','right']].set_visible(False);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
    table.set_xlim(0,1);table.axis('off');table.text(.05,-1,'Original',weight='bold');table.text(.55,-1,'New cost',weight='bold')
    fig.suptitle('Broad model-family graph pilot',fontsize=19,y=.98)
    fig.text(.5,.945,f'{summary["new_requests"]}/456 new responses · 48 Claude references reused · US${summary["new_cost_usd"]:.2f} new cost',ha='center',fontsize=12)
    handles,labels=ax.get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=3,frameon=False,bbox_to_anchor=(.5,.025))
    pending=' White = not yet returned.' if summary['new_requests']<456 else ''
    fig.text(.5,.014,'Fixed order, not a statistical ranking. * Historical Claude references.'+pending,ha='center',fontsize=9)
    fig.text(.5,.003,'† Grok caps visible output only; its billed internal reasoning can exceed the requested token allowance.',ha='center',fontsize=9)
    fig.tight_layout(rect=[0,.085,1,.925]);fig.savefig(ROOT/'family_results.png',dpi=180);fig.savefig(ROOT/'family_results.svg');plt.close(fig)
    print(ROOT/'family_results.png')

if __name__=='__main__':plot()
