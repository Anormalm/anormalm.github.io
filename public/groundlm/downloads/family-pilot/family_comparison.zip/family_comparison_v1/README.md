# Broad model-family graph comparison

Budget amendment: the initial reservation assumed a combined completion cap.
Grok's native API instead caps only visible output, and one observed request used
about 16.4k billed completion tokens despite requesting 8,192. The guard paused
at US$1.27, retaining all 90 completed requests. New Grok calls reserve the full
declared model capacity plus visible output. The US$20 cap still governs live
admission; the original US$19.04 full-plan estimate is superseded. Details and
evidence are in `budget_amendment.json`. Grok is not an equal-total-token-budget
comparison, and its actual reasoning token counts must be reported separately.

The user approved **US$20 additional** for a broad, price-aware family pilot.
Previous experiments recorded US$16.743486; they are a separate historical spend.
The new maximum cumulative expenditure for this comparison is therefore
US$36.743486. An account top-up is not treated as an unlimited experiment budget.

The frozen plan has 19 new model configurations, 24 requests each (456 total),
plus 48 existing Claude responses reused without further inference charges.
All six graph questions and four naming conditions are identical across models.
Questions cover weighted shortest paths, triangle counts, and minimum cuts at
32 and 64 nodes, using the first fixed replication seed for each cell.

The [Artificial Analysis leaderboard](https://artificialanalysis.ai/leaderboards/models)
guides model selection. Availability, model IDs, supported parameters and prices
come from OpenRouter's live catalog. The report distinguishes frontier choices,
price-aware alternatives, unavailable checkpoints and older family controls.
This is not a claim to test every checkpoint or reproduce the AA Intelligence
Index. Fable and similarly priced Astra are excluded. Llama, Gemma, Granite and
Nova are included explicitly as family controls; their index scores are not
fabricated. The top Gemini Carbon and Muse Wonder Full were absent from the
available router catalog, so Argon and Muse Wonder are named substitutes.

## Run and inspect

```powershell
python -m unittest discover -s experiments/family_comparison_v1 -v
python experiments/family_comparison_v1/run.py
python experiments/family_comparison_v1/analyze.py
python experiments/family_comparison_v1/evidence.py
python experiments/family_comparison_v1/plot.py
python experiments/family_comparison_v1/finalize.py
```

`OPENROUTER_API_KEY` must exist in the environment. It is never saved in source,
reports, configuration or exports. `prepare.py` refuses to overwrite a frozen
plan. `run.py` resumes completed request IDs; it does not automatically retry
provider errors. Run only one copy against this ledger.
If a transient provider failure pauses a model, `run.py --resume-blocked` can
attempt its never-started slots after the previous process exits. Existing
response IDs, including failures, remain completed slots and are never repeated
by the main runner. Provider-error retries belong only in `recover.py`.

- Common output allowance: 8,192 tokens, including reasoning when the service
  accounts for it that way. No tools or model fallbacks to a different model.
- Reasoning: high effort where advertised; otherwise enable the service default
  when reasoning is supported; otherwise omit reasoning controls.
- Temperature: omitted for every model; the provider default applies.
- Scheduling: eight concurrent calls globally, at most two per model, round-robin
  model order. Timeout: 600 seconds per request.
- Provider routing: require supported parameters, prefer price, enforce explicit
  per-million-token price caps. Prompt-tier and time-tier prices are bounded
  conservatively. Input reservations use UTF-8 byte length plus overhead.
- A shared reservation ledger accounts for in-flight requests before launching
  new calls. Auth/credit errors stop the batch; other errors block that model.
  Uncertain request costs consume their reserved bound. No free-tier endpoints
  are selected, avoiding free-service rate-limit noise.

After all 456 base slots finish, `recover.py` may make one bounded recovery
attempt for each provider failure. It never retries incorrect answers or token
cutoffs. Failed attempts remain in a separate append-only recovery log and in
the spending total. Do not run recovery concurrently with the main runner.

Analysis requires Python and NetworkX; figures also require matplotlib and
NumPy. `environment.json` records the versions used. `finalize.py` performs no
network requests: it checks complete coverage, serialized graph equivalence,
immutable prompt hashes, recovery eligibility, score partitions and costs,
then exports `output/benchmarks/family_comparison.zip`. The bundle includes the
shared helper modules and source fixtures under a sibling `hard_graph_v1/`
directory, so the relative imports work after extraction. Do not rerun inference
to reproduce the analysis: use the saved raw responses.

## Artifacts and interpretation

`plan.json` records every checkpoint, selection rationale, price and exclusion.
`catalog_snapshot.json` preserves the selection-time catalog. `execution.json`
records the fresh execution tariffs and supported parameters. `results.jsonl`
is append-only new inference output. `claude_reference_results.json` preserves
the historical matched Claude observations. `scored_results.json`, `summary.json`,
`metrics.csv` and `REPORT.md` provide the common final-answer scoring.

Answers use an explicit terminal JSON integer; verbose reasoning before it is
allowed. Format compliance is separate. Numeric mistakes, invalid final answers,
token cutoffs and API availability errors are separate categories. Consistency
excludes unparseable pairs; conditional survival counts an unparseable renamed
answer as failure among initially correct pairs.

There are only six independent graph questions per model, not 24 independent
questions. One model sample per prompt does not quantify sampling variance.
Semantic identifiers also change token length. Historical Claude provider
routing differs from the new price-capped routing. These facts limit broad
ranking or semantic-causality claims; use this pilot to decide what deserves
larger independent runs.
