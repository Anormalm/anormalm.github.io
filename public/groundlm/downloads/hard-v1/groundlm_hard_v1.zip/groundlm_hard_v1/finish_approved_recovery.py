"""Wait for the existing pipeline, recover only eight approved slots, re-export."""
import argparse
import concurrent.futures
import datetime
import hashlib
import json
import math
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path
from core import SYSTEM
from run import RunLock, Budget, append, read_rows, select_attempts, collect_one
from service import api, reservation
from recovery_policy import approved_exception, audit_attempts

ROOT = Path(__file__).resolve().parent


def state(status, **values):
    record = {'status': status, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'cap_usd': 27, **values}
    (ROOT / 'runs/approved_recovery_state.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)


def load(path):
    for _ in range(20):
        try:
            return json.loads(path.read_text())
        except json.JSONDecodeError:
            time.sleep(.05)
    raise RuntimeError('State file remained unreadable.')


def finish(execute=False):
    policy, allowed, digest = approved_exception(ROOT)
    assert len(allowed) == 8 and policy['approval_status'] == 'approved'
    if not execute:
        state('dry_run', approved_slots=len(allowed), maximum_extra_cost_usd=policy['max_additional_cost_usd'])
        return
    state('waiting_for_existing_pipeline', approved_slots=len(allowed), maximum_extra_cost_usd=policy['max_additional_cost_usd'])
    while True:
        if (ROOT / 'runs/STOP').exists():
            state('stopped', reason='STOP file preserved; no additional inference launched.')
            return
        parent = load(ROOT / 'runs/supervisor.json')
        if parent['status'] in ('finished', 'export_requires_attention'):
            break
        time.sleep(10)
    lock = RunLock()
    while True:
        try:
            lock.__enter__()
            break
        except OSError:
            time.sleep(10)
    try:
        if (ROOT / 'runs/STOP').exists():
            state('stopped', reason='STOP file preserved.')
            return
        plan = load(ROOT / 'run_plan.json')
        scope = load(ROOT / 'collection_scope.json')
        assert scope['authorized_cap_usd'] == policy['unchanged_cumulative_cap_usd'] == 27
        assert hashlib.sha256((ROOT / 'run_plan.json').read_bytes()).hexdigest() == policy['frozen_plan_sha256']
        assert hashlib.sha256((ROOT / 'data/prompts.json').read_bytes()).hexdigest() == plan['fixture_sha256']
        assert SYSTEM == plan['system_prompt']
        for name, expected in load(ROOT / 'runs/collection_source_hashes.json').items():
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
        ledger, journal = ROOT / 'runs/results.jsonl', ROOT / 'runs/events.jsonl'
        rows, events = read_rows(ledger), read_rows(journal)
        done = {r['attempt_id'] for r in rows}
        for e in events:
            if e['event'] == 'launch' and e['attempt_id'] not in done:
                # A possibly billed launch remains charged conservatively after
                # interruption. An interrupted third attempt is never repeated.
                missing = {**e, 'status': 'provider_error', 'error_type': 'collector_interrupted',
                           'cost_usd': e['reserved_usd'], 'cost_source': 'uncertain_upper_bound'}
                append(ledger, missing)
                rows.append(missing)
                done.add(e['attempt_id'])
        audit_attempts(rows, ROOT)
        selected = select_attempts(rows)
        counts = {}
        for r in rows:
            slot = r['model'], r['id']
            counts[slot] = counts.get(slot, 0) + 1
        prompts = {p['id']: p for p in load(ROOT / 'data/prompts.json')}
        profiles = {m['model']: m for m in plan['models']}
        key = os.environ['OPENROUTER_API_KEY']
        credit = api('/credits', key)['data']
        spent = math.fsum(r['cost_usd'] for r in rows)
        budget = Budget(min(27, spent + max(0, credit['total_credits'] - credit['total_usage'] - .5)), spent)
        candidates = []
        for item in policy['slots']:
            slot = item['model'], item['id']
            row = selected.get(slot)
            if row and row['status'] == 'ok':
                continue
            if counts.get(slot, 0) >= 3:
                continue
            assert row and row['status'] == 'provider_error' and counts[slot] == 2
            bound = reservation(profiles[slot[0]], prompts[slot[1]]['prompt'], SYSTEM, plan['max_tokens'])
            assert bound <= item['request_bound_usd'] + 1e-12
            candidates.append((slot, bound))
        assert math.fsum(bound for _, bound in candidates) <= policy['max_additional_cost_usd'] + 1e-9
        state('running', remaining_approved_slots=len(candidates), starting_total_spend_usd=spent)
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            pending = {}
            for slot, bound in candidates:
                if (ROOT / 'runs/STOP').exists() or not budget.reserve(bound):
                    break
                prompt = prompts[slot[1]]
                attempt_id = uuid.uuid4().hex
                launch = {'event': 'launch', 'attempt_id': attempt_id, 'model': slot[0], 'id': slot[1],
                          'case_id': prompt['case_id'], 'variant': prompt['variant'], 'task': prompt['task'], 'n': prompt['n'],
                          'reserved_usd': bound, 'approved_extra_recovery': True, 'recovery_approval_sha256': digest,
                          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
                append(journal, launch)
                future = pool.submit(collect_one, profiles[slot[0]], prompt, plan, bound, attempt_id, key)
                pending[future] = bound
            for future in concurrent.futures.as_completed(pending):
                row = future.result()
                row.update(approved_extra_recovery=True, recovery_approval_sha256=digest)
                safe = budget.settle(pending[future], row['cost_usd'])
                append(ledger, row)
                rows.append(row)
                state('running', model=row['model'], prompt_id=row['id'], response_status=row['status'],
                      total_spend_usd=budget.spent, within_reservation=safe)
        audit_attempts(rows, ROOT)
        state('auditing_and_exporting', total_spend_usd=budget.spent)
        with (ROOT / 'runs/approved_recovery_export.log').open('a', encoding='utf-8') as out:
            result = subprocess.run([sys.executable, str(ROOT / 'export.py')], cwd=ROOT, stdout=out, stderr=subprocess.STDOUT)
        if result.returncode:
            state('export_requires_attention', returncode=result.returncode)
            return
        summary = load(ROOT / 'results/summary.json')
        state('finished', collection_complete=summary['collection_complete'], unique_slots=summary['new_slots'],
              total_spend_usd=summary['spent_usd'], exception_audit=audit_attempts(rows, ROOT))
    finally:
        lock.__exit__()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    finish(parser.parse_args().execute)
