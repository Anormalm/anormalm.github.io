"""Finish the already authorized collection and export it without a new budget.

Can attach while run.py holds the collector lock. It never launches another
collector concurrently, changes the dataset, increases the cap, or retries a
model answer. A STOP file is respected across every phase.
"""
import datetime
import collections
import json
import subprocess
import sys
import time
from pathlib import Path
from run import RunLock, read_rows, select_attempts
from budget_controls import maybe_admit_weak_baseline
from availability_controls import maybe_repin_unavailable_endpoint

ROOT = Path(__file__).resolve().parent


def state(**kwargs):
    row = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), **kwargs}
    (ROOT / 'runs/supervisor.json').write_text(json.dumps(row, indent=2) + '\n')
    print(json.dumps(row), flush=True)


def wait_for_collector():
    while True:
        try:
            with RunLock():
                return
        except OSError:
            time.sleep(10)


def has_default_recovery_work(rows, models, prompt_ids):
    selected = select_attempts(rows)
    counts = collections.Counter((r['model'], r['id']) for r in rows)
    for model in models:
        for prompt_id in prompt_ids:
            slot = model, prompt_id
            row = selected.get(slot)
            if row is None or (row['status'] == 'provider_error' and counts[slot] < 2):
                return True
    return False


def main():
    scope = json.loads((ROOT / 'collection_scope.json').read_text())
    assert scope['authorized_cap_usd'] == 27
    state(status='waiting_for_active_collector', cap_usd=27)
    wait_for_collector()
    prompt_ids = [p['id'] for p in json.loads((ROOT / 'data/prompts.json').read_text())]
    for phase in range(2):
        maybe_repin_unavailable_endpoint()
        maybe_admit_weak_baseline()
        scope = json.loads((ROOT / 'collection_scope.json').read_text())
        rows = read_rows(ROOT / 'runs/results.jsonl')
        selected = select_attempts(rows)
        complete = len(selected) == scope['planned_slots'] and all(r['status'] == 'ok' for r in selected.values())
        if complete or (ROOT / 'runs/STOP').exists():
            break
        if not has_default_recovery_work(rows, scope['models'], prompt_ids):
            # Exhausted slots cannot become eligible during a cooldown. The
            # separate approved follow-up handles its named exceptions.
            state(status='default_recovery_exhausted', cap_usd=27)
            break
        if phase:
            state(status='provider_cooldown', seconds=900, cap_usd=27)
            for _ in range(90):
                if (ROOT / 'runs/STOP').exists():
                    break
                time.sleep(10)
        if (ROOT / 'runs/STOP').exists():
            break
        state(status='bounded_provider_recovery_and_untouched_slots', phase=phase + 1, cap_usd=27)
        command = [sys.executable, str(ROOT / 'run.py'), '--budget-usd', '27', '--execute', '--recover',
                   '--workers', '8', '--per-model', '2' if phase == 0 else '1']
        with (ROOT / f'runs/recovery_phase_{phase + 1}.log').open('a', encoding='utf-8') as log:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        if result.returncode:
            state(status='collector_requires_attention', returncode=result.returncode, cap_usd=27)
            break
    wait_for_collector()
    state(status='scoring_auditing_exporting', cap_usd=27)
    with (ROOT / 'runs/export.log').open('a', encoding='utf-8') as log:
        result = subprocess.run([sys.executable, str(ROOT / 'export.py')], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    if result.returncode:
        state(status='export_requires_attention', returncode=result.returncode, cap_usd=27)
        return
    summary = json.loads((ROOT / 'results/summary.json').read_text())
    state(status='finished', collection_complete=summary['collection_complete'],
          slots=summary['new_slots'], planned_slots=summary['planned_slots'], cost_usd=summary['spent_usd'], cap_usd=27,
          note='Any unresolved provider failures and missing slots remain explicit; dataset readiness does not imply full model coverage.')


if __name__ == '__main__':
    main()
