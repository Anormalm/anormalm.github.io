"""Admit an optional weak baseline only after reserving unfinished core work."""
import collections
import datetime
import json
import math
from pathlib import Path
from core import SYSTEM
from run import append, read_rows, select_attempts
from service import reservation

ROOT = Path(__file__).resolve().parent


def admission_decision(plan, scope, prompts, rows, events, baseline, margin=.1):
    profiles = {p['model']: p for p in plan['models']}
    if baseline in scope['models']:
        return {'admit': False, 'reason': 'already included'}
    finished = {r['attempt_id'] for r in rows}
    launched = {e['attempt_id'] for e in events if e['event'] == 'launch'}
    if launched - finished:
        return {'admit': False, 'reason': 'in-flight or abandoned launches must be accounted for first'}
    selected = select_attempts(rows)
    attempts = collections.Counter((r['model'], r['id']) for r in rows)
    spent = math.fsum(r['cost_usd'] for r in rows)
    remaining = 0
    for model in scope['models']:
        for prompt in prompts:
            slot = model, prompt['id']
            row = selected.get(slot)
            if row is None or (row['status'] == 'provider_error' and attempts[slot] < 2):
                remaining += reservation(profiles[model], prompt['prompt'], SYSTEM, plan['max_tokens'])
    baseline_bound = math.fsum(reservation(profiles[baseline], p['prompt'], SYSTEM, plan['max_tokens']) for p in prompts)
    projected = spent + remaining + baseline_bound + margin
    return {'admit': projected <= scope['authorized_cap_usd'] + 1e-9,
            'reason': 'remaining core work and weak baseline both fit' if projected <= scope['authorized_cap_usd'] + 1e-9 else 'preserve the core collection budget',
            'baseline': baseline, 'spent_usd': spent, 'remaining_core_bound_usd': remaining,
            'baseline_full_bound_usd': baseline_bound, 'recovery_margin_usd': margin,
            'projected_total_bound_usd': projected, 'shared_collection_cap_usd': scope['authorized_cap_usd']}


def maybe_admit_weak_baseline():
    policy_path = ROOT / 'weak_baseline_policy.json'
    if not policy_path.exists() or (ROOT / 'runs/STOP').exists():
        return
    policy = json.loads(policy_path.read_text())
    scope_path = ROOT / 'collection_scope.json'
    scope = json.loads(scope_path.read_text())
    if policy['model'] in scope['models']:
        return
    plan = json.loads((ROOT / 'run_plan.json').read_text())
    prompts = json.loads((ROOT / 'data/prompts.json').read_text())
    decision = admission_decision(plan, scope, prompts, read_rows(ROOT / 'runs/results.jsonl'),
                                  read_rows(ROOT / 'runs/events.jsonl'), policy['model'], policy['recovery_margin_usd'])
    decision['utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    append(ROOT / 'runs/weak_baseline_decisions.jsonl', decision)
    (ROOT / 'runs/weak_baseline_decision.json').write_text(json.dumps(decision, indent=2) + '\n')
    if not decision['admit']:
        return
    # This changes model coverage only. Prompts, inference settings, endpoint
    # and scoring definitions were frozen before any model data was collected.
    (ROOT / 'runs/scope_before_weak_baseline.json').write_text(json.dumps(scope, indent=2) + '\n')
    scope['models'].append(policy['model'])
    scope['planned_slots'] = len(scope['models']) * len(prompts)
    scope['weak_control_models'] = [policy['model']]
    scope['all_requests_reservation_ceiling_usd'] = sum(p['all_request_reservations_usd'] for p in plan['models'] if p['model'] in scope['models'])
    scope['weak_baseline_admission'] = decision
    scope['scope_note'] += ' Granite 4.2 8B BF16 is an optional weak control, admitted only after reserving all unfinished core requests and eligible recovery calls.'
    scope['budget_note'] = 'The sum of all original request bounds can exceed the cap after admission because completed requests cost less than their bounds. Admission uses actual spend plus remaining bounds; it never increases the cap.'
    scope_path.write_text(json.dumps(scope, indent=2) + '\n')
    append(ROOT / 'runs/scope_amendments.jsonl', {'utc': decision['utc'], 'action': 'add affordable weak control',
           'model': policy['model'], 'cap_usd': scope['authorized_cap_usd'], 'decision': decision,
           'selection_basis': 'budget and model size, not observed answer quality'})
