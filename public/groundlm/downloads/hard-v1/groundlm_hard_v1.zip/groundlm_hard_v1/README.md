# GroundLM Hard v1

This is a frozen synthetic structural-invariance benchmark. It extends the
earlier difficulty pilot; it does not replace or reproduce the paper's original
small-graph protocol. The dataset is ready for collection, and reference results
are final only when `results/summary.json` says `collection_complete: true`.

## Frozen dataset

120 fresh graph cases: six tasks x two sizes (32/64 nodes) x ten independent
seeds. Tasks are weighted shortest distance, shortest-path count, exact-length
walk count, triangle count, minimum cut, and vertex-removal reachability.
Reachability has five yes and five no answers at each size.

Every case has eight prompts: original, identical-input repeat, neutral renaming,
degree-aligned names, degree-reversed names, JSON format, shuffled order, and a
disjoint path distractor. This is 960 calls per model configuration. Names are
explicitly arbitrary identifiers in the shared system instruction. Degree-based
names do not establish task-role congruence. The disjoint path preserves each
query's answer; it changes the graph and is not an isomorphic relabeling.

No graph is selected or rejected using model outcomes. No pilot observations
are reused in the final-test counts. `data/manifest.json` records seeds, counts
and file hashes. `validate.py` decodes all actual prompt strings, reconstructs
their graphs and query endpoints, checks equivalence and recomputes every
answer. Independent implementations cross-check the case oracles. The tests
also compare them against exhaustive enumeration on small graphs.

## Collection scope and budget

The original all-family plan in `RUN_PLAN.md` costs much more than the user's
remaining US$27.77. The authorized affordable collection therefore uses a
**US$27 hard cap**, leaving US$0.77 of that stated balance untouched:

| Model checkpoint | Frozen endpoint | Precision |
| --- | --- | --- |
| DeepSeek-V4.1-Flash-1017 | sail-research/fp4 | FP4 |
| GLM-5.3 | baidu/fp8 | FP8 |
| MiniMax-M3.1-Flash | tenstorrent/fp8 | FP8 |
| Ling-3.1-Flash | novita | Unspecified |
| Granite-4.2-8B (weak control) | coreweave/bf16 | BF16 |

The initial four-configuration matrix had 3,840 unique request slots and a
US$26.69 summed request bound before provider recovery. Granite was admitted
at a clean checkpoint, extending the target to **4,800 slots**. The admission
check included actual spend, all unfinished core work, the full weak baseline
and a recovery margin: **US$26.90**, below the unchanged US$27 cap.
Endpoint quantization is part of each configuration, not an invisible
implementation choice. Results must not be presented as the native full-
precision checkpoints or as the full 21-model leaderboard. The earlier broad
family pilot remains separately available under `experiments/family_comparison_v1`.

The user's **US$27.77 is the total available for this continuation**, including
what collection has already spent. It is not a new per-model or per-phase
allowance. The shared cap stays US$27 across collection, recovery and optional
controls.

Granite 4.2 8B at `coreweave/bf16` is an optional weaker baseline on all 960
prompts. Its frozen full-request bound is US$2.81. The supervisor admits it only
after the active batch ends and actual spend plus all unfinished core-request
bounds, eligible provider-recovery bounds, the whole baseline and a US$0.10
recovery margin fit the same cap. It never selects this control using answer
quality. This control was admitted after 765 completed slots at US$2.7423
recorded spend. See `weak_baseline_policy.json`,
`runs/weak_baseline_decision.json` and `runs/scope_amendments.jsonl`.

`run_plan.json` preserves all 21 planned configurations, endpoint snapshots,
16k cost scenarios and exclusions. `collection_scope.json` selects the four
affordable configurations plus the weak control and records the shared cap.
Fable remains excluded.

Each request uses one pinned endpoint, no fallback, high reasoning effort where
advertised (otherwise reasoning enabled where supported), `max_tokens=16384`,
no tools, and provider-default sampling. Identical-input repeats provide an
observed sampling control; they do not fully characterize stochastic variation.
Endpoint prices are capped. Billing, token usage, actual returned model and
provider are retained. Results are not an equal-compute model ranking.

## Run

Requirements: Python 3.10+, NetworkX and NumPy. Optional plots use matplotlib.
Set `OPENROUTER_API_KEY` in the environment; never place it in source files.

```powershell
python benchmark/v1/validate.py
python -m unittest discover -s benchmark/v1 -v
python benchmark/v1/run.py --budget-usd 27
python benchmark/v1/run.py --budget-usd 27 --execute
python benchmark/v1/score.py
python benchmark/v1/smoke_export.py
```

Without `--execute` the runner is a free dry run. Run only one collector at a
time; an OS lock enforces this. The launch journal is fsynced before submission.
On restart, abandoned launches consume their conservative reservation until
resolved; money for possibly billed requests is never silently released.
The journal and raw result ledger are append-only. Collection source hashes
are frozen at first execution and checked on resume.

To stop scheduling, create `benchmark/v1/runs/STOP`; active calls drain and
save their results. Remove that file to resume. Re-running the same command
attempts only untouched slots. Three consecutive provider failures pause that
model for the process. Wrong, invalid and cutoff answers are never retried.
After the main collection stops, `--recover` permits one recovery of each
provider failure, retaining every attempt and charge. Use the same US$27
cumulative collection cap; recovery is not a new budget.

After a network interruption, the user explicitly approved one additional
infrastructure-only attempt for eight named slots that had exhausted the usual
recovery. Their combined conservative extra bound is US$0.053849, inside the
same US$27 cumulative cap. This permits a third total attempt only for those
eight slots, only if every earlier attempt is a provider failure with no usable
model response. Wrong answers, invalid model answers and cutoffs remain
ineligible. The approved IDs and authorization are in
`runs/recovery_exception_plan.json`; `recovery_policy.py` audits the exception.

`finish_approved_recovery.py --execute` waits for the existing collection and
supervisor to finish, acquires the same exclusive collector lock, attempts the
approved slots once, then repeats scoring, certification, auditing and export.
It never runs paid inference concurrently with the main pipeline or increases
the cap. Its state is `runs/approved_recovery_state.json`. The first supervisor
export is provisional until this approved follow-up and its export finish.

`supervise.py` can attach while the collector is running. It waits for the OS
lock, makes up to two bounded follow-up passes for untouched slots and eligible
provider errors, then runs the validation, scoring, accounting audit and export.
It preserves the same US$27 cap and respects STOP. If an endpoint remains
unavailable, the export lists the missing coverage and does not call that
configuration complete. Progress is in `runs/progress.json`; completion state
is in `runs/supervisor.json`. The final archive is
`output/benchmarks/groundlm_hard_v1.zip` relative to the project root.
Empty default-recovery passes are skipped: exhausted slots do not trigger an
idle cooldown before the separately approved follow-up.

Ling's original DeepInfra endpoint returned only upstream 429 rejections before
generation. An availability-only revision pinned the previously listed Novita
endpoint at the same price before Ling had any successful response.
It changes neither prompts nor inference settings and does not mix generated
answers from different endpoints. The replacement catalog's precision is
reported explicitly (currently unspecified). The original plan, scope and
rejections remain archived under `runs/`; the revised plan and scope hashes are
recorded. If any original response exists or prices increase, the automatic
revision is refused. No per-request provider fallback is enabled.

`smoke_export.py` tests the entire export using synthetic perfect responses in
an isolated temporary tree. It performs no API calls and never writes to the
real response ledger or production archive.

## Scoring and uncertainty

The parser accepts an explicit nonnegative integer JSON answer, including a
terminal object after prose; format compliance is separate. It does not scrape
numbers out of reasoning. Completed numeric errors, invalid answers, cutoffs,
API failures and missing slots are distinct.

Accuracy uses returned responses and exposes their counts. Invariance agreement
requires parseable paired answers. Conditional survival requires an initially
correct original and a returned counterpart; invalid/cutoff counterparts fail
survival. API errors are excluded and reported through pair coverage. The
semantic gap uses the same parseable original/neutral/reversed-name triples.
Read coverage with every conditional rate.

Graph cases are the uncertainty unit. Variants are correlated and never
treated as independent samples. The scorer resamples graphs within each
task/size stratum with a fixed bootstrap seed. Binary rates also include Wilson
intervals, so a perfect sample's degenerate bootstrap interval does not imply
certainty. No final result is fabricated when a run is incomplete.

These tests concern controlled synthetic graph families. They do not isolate
semantic meaning from tokenization or establish natural-graph generalization.

## Exact-answer evidence

`evidence.py` saves and verifies a certificate for every graph case: shortest
paths plus distance potentials, matching flow/cut witnesses, complete triangle
enumerations, shortest-path count recurrences, exact walk-count tables, and
reachability paths or separating components. Certificate verification does not
call the benchmark answer oracle. The final export regenerates these witnesses
and indexes every completed numeric mistake and every completed change from a
correct original. Repeats are labeled as unchanged-input variation. Cutoffs and
provider errors are kept separate from completed numeric mistakes.
