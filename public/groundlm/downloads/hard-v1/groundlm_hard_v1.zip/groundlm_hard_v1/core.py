"""GroundLM Hard v1: deterministic cases, exact answers and prompt serialization."""
import hashlib
import itertools
import json
import random
from collections import deque

import networkx as nx

VERSION = 'groundlm-hard-v1'
TASKS = ('weighted_shortest_path', 'shortest_path_count', 'exact_walk_count',
         'triangle_count', 'minimum_cut', 'constrained_reachability')
VARIANTS = ('original', 'repeat', 'neutral', 'degree_aligned', 'degree_reversed',
            'format_json', 'order_shuffled', 'distractor')
SYSTEM = ('You solve graph problems using only the explicitly supplied edges and rules. '
          'All node names are arbitrary identifiers; their meanings give no evidence about edges or roles. '
          'Return only a JSON object with one nonnegative integer field: {"answer": INTEGER}.')


def seed_for(task, n, replicate):
    key = f'{VERSION}:2026-11-03:{task}:{n}:{replicate}'
    return int.from_bytes(hashlib.sha256(key.encode()).digest()[:8], 'big')


def graph_of(case):
    g = nx.Graph()
    g.add_nodes_from(range(case['n']))
    g.add_weighted_edges_from(case['edges'])
    return g


def oracle(g, task, s, t, blocked, length):
    if task == 'weighted_shortest_path':
        return int(nx.shortest_path_length(g, s, t, weight='weight'))
    if task == 'minimum_cut':
        return int(nx.minimum_cut_value(g, s, t, capacity='weight'))
    if task == 'triangle_count':
        return sum(nx.triangles(g).values()) // 3
    if task == 'constrained_reachability':
        h = g.copy()
        h.remove_nodes_from(blocked)
        return int(nx.has_path(h, s, t))
    if task == 'exact_walk_count':
        counts = {v: int(v == s) for v in g}
        for _ in range(length):
            counts = {v: sum(counts[u] for u in g[v]) for v in g}
        return counts[t]
    distance = nx.single_source_shortest_path_length(g, s)
    counts = dict.fromkeys(g, 0)
    counts[s] = 1
    for v in sorted(distance, key=distance.get):
        for u in g[v]:
            if distance.get(u) == distance[v] + 1:
                counts[u] += counts[v]
    return counts[t]


def make_case(task, n, replicate):
    seed = seed_for(task, n, replicate)
    rng = random.Random(seed)
    nodes = list(range(n))
    rng.shuffle(nodes)
    s, t = nodes[0], nodes[-1]
    mean_degree = 4 if replicate % 2 == 0 else 8
    g = nx.gnp_random_graph(n, mean_degree / n, seed=seed)
    components = sorted(nx.connected_components(g), key=lambda c: min(c))
    for a, b in zip(components, components[1:]):
        g.add_edge(min(a), min(b))
    blocked = []
    if task == 'shortest_path_count':
        g = nx.Graph()
        g.add_nodes_from(range(n))
        middle = nodes[1:-1]
        layers = [[s]] + [middle[i:i + 6] for i in range(0, len(middle), 6)] + [[t]]
        for left, right in zip(layers, layers[1:]):
            for a, b in itertools.product(left, right):
                if rng.random() < .5:
                    g.add_edge(a, b)
            for a in left:
                if not any(g.has_edge(a, b) for b in right):
                    g.add_edge(a, rng.choice(right))
            for b in right:
                if not any(g.has_edge(a, b) for a in left):
                    g.add_edge(rng.choice(left), b)
    if task == 'constrained_reachability':
        g = nx.Graph()
        g.add_nodes_from(range(n))
        left, right = nodes[:n // 2], nodes[n // 2:]
        for part in (left, right):
            g.add_edges_from(zip(part, part[1:] + part[:1]))
            for a, b in itertools.combinations(part, 2):
                if rng.random() < 4 / len(part):
                    g.add_edge(a, b)
        a, b = left[-1], right[0]
        g.add_edge(a, b)
        # Removing the bridge endpoint breaks the query; removing another
        # internal vertex leaves each side's cycle connected. Five of each
        # label per size, assigned before inference.
        blocked = [b if replicate % 2 == 0 else left[1]]
    for a, b in sorted(g.edges()):
        g[a][b]['weight'] = rng.randint(1, 9)
    length = 6 if n == 32 else 8
    y = oracle(g, task, s, t, blocked, length)
    if task == 'constrained_reachability':
        assert y == replicate % 2
    return {'id': f'{VERSION}-{task}-n{n}-r{replicate:02}', 'task': task,
            'n': n, 'replicate': replicate, 'seed': seed, 'source': s, 'target': t,
            'blocked': blocked, 'walk_length': length,
            'edges': [[a, b, g[a][b]['weight']] for a, b in sorted(g.edges())], 'answer': y}


def independent_answer(case):
    """Different algorithms for the release's six task oracles."""
    g = graph_of(case)
    task, s, t = case['task'], case['source'], case['target']
    if task == 'weighted_shortest_path':
        distance = dict.fromkeys(g, float('inf'))
        distance[s] = 0
        for _ in range(len(g) - 1):
            before = dict(distance)
            for a, b, d in g.edges(data=True):
                w = d['weight']
                distance[a] = min(distance[a], before[b] + w)
                distance[b] = min(distance[b], before[a] + w)
        return int(distance[t])
    if task == 'triangle_count':
        return sum(all(g.has_edge(a, b) for a, b in itertools.combinations(triple, 2))
                   for triple in itertools.combinations(g, 3))
    if task == 'minimum_cut':
        value, flow = nx.maximum_flow(g, s, t, capacity='weight', flow_func=nx.algorithms.flow.edmonds_karp)
        cut, (left, right) = nx.minimum_cut(g, s, t, capacity='weight')
        assert value == cut == sum(d['weight'] for a, b, d in g.edges(data=True) if (a in left) != (b in left))
        for a in g:
            assert all(0 <= flow[a][b] <= g[a][b]['weight'] for b in g[a])
            net = sum(flow[a].values()) - sum(flow[b].get(a, 0) for b in g)
            assert net == (value if a == s else -value if a == t else 0)
        return int(value)
    if task == 'constrained_reachability':
        parent = list(range(case['n']))
        def find(v):
            while parent[v] != v:
                parent[v] = parent[parent[v]]
                v = parent[v]
            return v
        for a, b in g.edges():
            if a not in case['blocked'] and b not in case['blocked']:
                parent[find(a)] = find(b)
        return int(find(s) == find(t))
    # Integer matrix multiplication counts walks independently of the
    # vector recurrence used by the main oracle. At the first reachable
    # length, all walks to t are shortest simple paths.
    row = [int(v == s) for v in range(case['n'])]
    limit = case['walk_length'] if task == 'exact_walk_count' else case['n'] - 1
    adjacency = [[int(g.has_edge(a, b)) for b in range(case['n'])] for a in range(case['n'])]
    for length in range(1, limit + 1):
        row = [sum(row[a] * adjacency[a][b] for a in range(case['n'])) for b in range(case['n'])]
        if task == 'shortest_path_count' and row[t]:
            return row[t]
    return row[t]


def spec_for(case, variant):
    g = graph_of(case)
    n = case['n']
    rng = random.Random(case['seed'] ^ 0xCE3B91)
    labels = [f'X{i:03}' for i in range(n)]
    if variant == 'neutral':
        rng.shuffle(labels)
    if variant in ('degree_aligned', 'degree_reversed'):
        ranked = sorted(g, key=lambda v: (-g.degree(v), v))
        if variant == 'degree_reversed':
            ranked.reverse()
        words = ('Hub', 'Center', 'Bridge', 'Core', 'Junction', 'Branch', 'Leaf', 'Tip')
        for rank, v in enumerate(ranked):
            labels[v] = words[min(7, rank * 8 // n)] + f'_{rank:03}'
    weighted = case['task'] in ('weighted_shortest_path', 'minimum_cut')
    nodes = list(labels)
    edges = [[labels[a], labels[b], w if weighted else 1] for a, b, w in case['edges']]
    if variant == 'order_shuffled':
        rng.shuffle(nodes)
        rng.shuffle(edges)
    if variant == 'distractor':
        nodes += ['D000', 'D001', 'D002']
        edges += [['D000', 'D001', 1], ['D001', 'D002', 1]]
    return {'nodes': nodes, 'edges': edges, 'source': labels[case['source']],
            'target': labels[case['target']], 'blocked': [labels[v] for v in case['blocked']],
            'walk_length': case['walk_length'], 'weighted': weighted,
            'node_index_to_identifier': labels, 'format': 'json' if variant == 'format_json' else 'edge_list'}


def render(case, spec):
    s, t = spec['source'], spec['target']
    questions = {
        'weighted_shortest_path': f'What is the minimum sum of edge weights along a path from {s} to {t}?',
        'minimum_cut': f'Edges are undirected and their weights are capacities. What is the minimum total capacity of edges whose removal disconnects {s} from {t}?',
        'shortest_path_count': f'How many distinct shortest paths (minimum number of edges) lead from {s} to {t}? Count paths, not their length.',
        'exact_walk_count': f'How many walks of exactly {spec["walk_length"]} edges lead from {s} to {t}? Vertices and edges may repeat; count walks, not simple paths.',
        'triangle_count': 'How many distinct triangles are in the whole graph? Count each unordered set of three vertices once.',
        'constrained_reachability': f'Remove these vertices and all their incident edges: {", ".join(spec["blocked"])}. Is there a path from {s} to {t} afterward? Return 1 for yes, 0 for no.'}
    if spec['format'] == 'json':
        edges = [{'u': a, 'v': b, **({'weight': w} if spec['weighted'] else {})} for a, b, w in spec['edges']]
        graph = 'This JSON specifies the complete simple undirected graph. Each edge is listed once:\n' + json.dumps({'nodes': spec['nodes'], 'edges': edges}, separators=(',', ':'))
    else:
        edges = [f'{a} -- {b}' + (f' [weight={w}]' if spec['weighted'] else '') for a, b, w in spec['edges']]
        graph = 'This is a simple undirected graph. The complete node set is:\n' + ', '.join(spec['nodes']) + '\nThe complete edge list is:\n' + '\n'.join(edges)
    return graph + '\n\nQuestion: ' + questions[case['task']] + '\nReturn only {"answer": INTEGER}.'
