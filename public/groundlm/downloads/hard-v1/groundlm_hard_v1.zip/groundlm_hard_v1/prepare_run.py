"""Freeze all-family endpoints/settings and create a reviewable cost plan; no inference."""
import concurrent.futures
import datetime
import hashlib
import json
import os
import shutil
from pathlib import Path
from core import SYSTEM, VERSION
from service import api, rates_for, reservation

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]


def prepare():
    if (ROOT / 'run_plan.json').exists():
        raise SystemExit('Run plan is frozen and will not be overwritten.')
    prior = WORKSPACE / 'experiments/family_comparison_v1'
    old_plan = json.loads((prior / 'plan.json').read_text())
    summary = json.loads((prior / 'summary.json').read_text())
    prompts = json.loads((ROOT / 'data/prompts.json').read_text())
    rows = [json.loads(s) for s in (prior / 'results.jsonl').read_text().splitlines()]
    rows += json.loads((prior / 'claude_reference_results.json').read_text())
    ids = [m['model'] for m in old_plan['new_models']] + old_plan['reused_models']
    key = os.environ['OPENROUTER_API_KEY']
    catalog = api('/models', key)['data']
    (ROOT / 'catalog_snapshot.json').write_text(json.dumps(catalog, indent=2))
    catalog = {m['id']: m for m in catalog}
    endpoint_data = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        pending = {pool.submit(api, '/models/' + m + '/endpoints', key): m for m in ids}
        for future in concurrent.futures.as_completed(pending):
            endpoint_data[pending[future]] = future.result()['data']
    (ROOT / 'endpoint_snapshot.json').write_text(json.dumps(endpoint_data, indent=2))
    profiles = []
    for model in ids:
        entry = catalog[model]
        params = entry.get('supported_parameters', [])
        reason = {'effort': 'high'} if 'reasoning_effort' in params else {'enabled': True} if 'reasoning' in params else None
        required = {'max_tokens'} | ({'reasoning_effort'} if reason and 'effort' in reason else {'reasoning'} if reason else set())
        input_bound = max(len((SYSTEM + p['prompt']).encode()) + 4096 for p in prompts)
        endpoints = []
        for endpoint in endpoint_data[model]['endpoints']:
            if endpoint.get('status', 0) != 0 or not required.issubset(endpoint.get('supported_parameters', [])):
                continue
            if (endpoint.get('max_completion_tokens') or 16384) < 16384:
                continue
            if (endpoint.get('max_prompt_tokens') or input_bound) < input_bound:
                continue
            if endpoint.get('context_length', entry['context_length']) < input_bound + 16384:
                continue
            rates = rates_for(endpoint['pricing'], input_bound)
            endpoints.append((endpoint, rates))
        if not endpoints:
            raise ValueError(f'No compatible endpoint: {model}')
        stable = [pair for pair in endpoints if (pair[0].get('uptime_last_30m') or 0) >= 99]
        choices = stable or endpoints
        endpoint, rates = min(choices, key=lambda pair: (pair[1]['prompt'] * 3000 + pair[1]['completion'] * 16384,
                                                         -(pair[0].get('uptime_last_30m') or 0), pair[0]['tag']))
        profile = {'model': model, 'family': summary['models'][model]['family'], 'reasoning': reason,
                   'endpoint': endpoint['tag'], 'provider_name': endpoint['provider_name'],
                   'quantization': endpoint.get('quantization'), 'rates': rates,
                   'context_length': endpoint.get('context_length', entry['context_length']),
                   'max_completion_tokens': endpoint.get('max_completion_tokens'),
                   'endpoint_selection': 'Cheapest compatible endpoint with >=99% recent uptime, else cheapest compatible endpoint; frozen before inference.'}
        observed = [r for r in rows if r['model'] == model and r.get('status') == 'ok' and r.get('usage')]
        completion_mean = sum(r['usage'].get('completion_tokens', 0) for r in observed) / len(observed)
        prompt_ratio = sum(r['usage'].get('prompt_tokens', 0) for r in observed) / sum(len((SYSTEM + r['prompt']).encode()) for r in observed)
        estimated_prompt_tokens = sum(len((SYSTEM + p['prompt']).encode()) for p in prompts) * prompt_ratio
        old_cost = sum(r['cost_usd'] for r in rows if r['model'] == model)
        profile['pilot_cost_scaled_8k_usd'] = old_cost * len(prompts) / 24
        # A planning scenario, not a prediction: double non-Grok billed
        # completion tokens under the doubled requested allowance.
        profile['extrapolated_16k_usd'] = (estimated_prompt_tokens * rates['input_bound_rate'] +
            len(prompts) * completion_mean * (1 if model.startswith('x-ai/') else 2) * rates['completion'] + len(prompts) * rates['request'])
        profile['all_request_reservations_usd'] = sum(reservation(profile, p['prompt'], SYSTEM) for p in prompts)
        profiles.append(profile)
    plan = {'version': VERSION, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'models': profiles, 'model_count': len(profiles), 'cases': 120, 'requests_per_model': len(prompts),
            'total_requests': len(profiles) * len(prompts), 'max_tokens': 16384,
            'temperature': 'omitted for all models; provider default; repeat control quantifies observed variation',
            'system_prompt': SYSTEM, 'timeout_seconds': 1800,
            'provider_policy': 'One frozen endpoint per model, no provider fallback; returned provider retained.',
            'retry_policy': 'At most one recovery of provider failures; never retry wrong, invalid or cutoff model responses.',
            'prior_total_recorded_spend_usd': summary['combined_recorded_cost_usd'],
            'remaining_authorized_usd': summary['remaining_new_budget_usd'],
            'estimated_old_budget_scaled_usd': sum(p['pilot_cost_scaled_8k_usd'] for p in profiles),
            'extrapolated_16k_usd': sum(p['extrapolated_16k_usd'] for p in profiles),
            'sum_all_request_reservations_usd': sum(p['all_request_reservations_usd'] for p in profiles),
            'cost_note': 'Pilot extrapolation changes task mix, endpoints and completion allowance; actual charges can differ substantially. Full reservations are a deliberately loose ceiling, especially for Grok native reasoning. No new spending authorization is inferred.',
            'fixture_sha256': hashlib.sha256((ROOT / 'data/prompts.json').read_bytes()).hexdigest(),
            'manifest_sha256': hashlib.sha256((ROOT / 'data/manifest.json').read_bytes()).hexdigest(),
            'exclusions': old_plan['exclusions']}
    (ROOT / 'run_plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    lines = ['# Full-release collection plan', '',
             f'120 fresh graphs x 8 variants x {len(profiles)} model configurations = **{plan["total_requests"]:,} new requests**.', '',
             'No pilot responses are counted as final-test results. No new inference has been launched.', '',
             f'Existing 8k pilot-cost scaling: **US${plan["estimated_old_budget_scaled_usd"]:.2f}**.',
             f'16k planning scenario at frozen endpoint prices: **US${plan["extrapolated_16k_usd"]:.2f}**.',
             f'Remaining authorization: **US${plan["remaining_authorized_usd"]:.2f}**.', '',
             'The scenario doubles observed non-Grok completion tokens, uses fresh endpoint tariffs and scales input bytes. Six tasks replace the pilot three, so these are planning estimates, not guaranteed prices. Grok has a native visible-only cap; it is not compute-matched.', '',
             '| Model | Frozen endpoint | 16k scenario | Reservation ceiling |',
             '| --- | --- | ---: | ---: |']
    for p in profiles:
        lines.append(f'| {p["model"]} | {p["endpoint"]} | ${p["extrapolated_16k_usd"]:.2f} | ${p["all_request_reservations_usd"]:.2f} |')
    lines += ['', 'A hard spending cap is separate from the total reservation ceiling: admission counts completed charges plus all in-flight reservations, and releases unused reservations when actual charges arrive. A cap below the eventual bill leaves the collection incomplete; it never authorizes overrun.', '',
              'The final run has not started. Approval is needed only to raise the existing spending cap. The frozen questions, provider choices, validation, runner and scoring can all be inspected locally first.']
    (ROOT / 'RUN_PLAN.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: plan[k] for k in ('total_requests', 'estimated_old_budget_scaled_usd', 'extrapolated_16k_usd', 'remaining_authorized_usd')}))


if __name__ == '__main__':
    prepare()
