"""Offline end-to-end export test in an isolated temporary tree, never real results."""
import contextlib
import io
import json
import shutil
import tempfile
from pathlib import Path
import export as exporter
import score as scorer
import validate as validator

ROOT = Path(__file__).resolve().parent


def smoke():
    temp_base = ROOT.parents[1] / 'tmp'
    temp_base.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='benchmark_export_TEST_ONLY_', dir=temp_base) as folder:
        tree = Path(folder).resolve()
        assert tree.is_relative_to(temp_base.resolve())
        target = tree / 'benchmark/v1'
        target.mkdir(parents=True)
        for path in ROOT.glob('*.py'):
            shutil.copy2(path, target / path.name)
        for name in ('run_plan.json', 'collection_scope.json'):
            shutil.copy2(ROOT / name, target / name)
        shutil.copytree(ROOT / 'data', target / 'data')
        (target / 'runs').mkdir()
        scope = json.loads((target / 'collection_scope.json').read_text())
        prompts = json.loads((target / 'data/prompts.json').read_text())
        records, events = [], []
        for model in scope['models']:
            for p in prompts:
                attempt = str(len(records))
                records.append({'attempt_id': attempt, 'model': model, 'id': p['id'], 'case_id': p['case_id'],
                                'variant': p['variant'], 'task': p['task'], 'n': p['n'], 'status': 'ok',
                                'answer_text': json.dumps({'answer': p['ground_truth']}), 'finish_reason': 'stop',
                                'cost_usd': 0, 'cost_source': 'provider', 'TEST_ONLY': True})
                events.append({'event': 'launch', 'attempt_id': attempt})
        (target / 'runs/results.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in records))
        (target / 'runs/events.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in events))
        # Module roots are patched only inside this isolated test process.
        exporter.ROOT = scorer.ROOT = validator.ROOT = target
        with contextlib.redirect_stdout(io.StringIO()):
            exporter.export()
        summary = json.loads((target / 'results/summary.json').read_text())
        assert summary['collection_complete'] and summary['new_slots'] == scope['planned_slots'] and summary['spent_usd'] == 0
        assert all(m['metrics']['accuracy_original']['n_graphs'] == 120 for m in summary['models'].values())
        assert all(m['metrics']['accuracy_original']['ci95'][0] < 1 for m in summary['models'].values())
        assert (tree / 'output/benchmarks/groundlm_hard_v1.zip').exists()
    print('PASS: isolated synthetic export, archive integrity, full graph denominators and non-degenerate Wilson bounds. No API requests or real-result writes.')


if __name__ == '__main__':
    smoke()
