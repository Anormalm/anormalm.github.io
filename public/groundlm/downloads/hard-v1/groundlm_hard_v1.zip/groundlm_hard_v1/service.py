"""Minimal OpenRouter transport and conservative endpoint tariff bounds."""
import json
import urllib.request

BASE = 'https://openrouter.ai/api/v1'


def api(path, key, body=None, timeout=1800):
    request = urllib.request.Request(BASE + path, data=None if body is None else json.dumps(body).encode(),
                                     headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def rates_for(pricing, input_bound):
    tiers = [pricing] + [t for t in pricing.get('overrides', []) if t.get('min_prompt_tokens', 0) <= input_bound]
    rates = {k: max(float(t.get(k, pricing.get(k, 0))) for t in tiers) for k in ('prompt', 'completion', 'request')}
    rates['input_bound_rate'] = max([rates['prompt']] + [float(t[k]) for t in tiers for k in ('input_cache_write', 'input_cache_write_1h') if k in t])
    if any(v < 0 for v in rates.values()):
        raise ValueError('Unknown endpoint prices cannot be bounded.')
    return rates


def reservation(profile, prompt, system, max_tokens=16384):
    input_bound = len((system + prompt).encode()) + 4096
    completion_bound = max_tokens
    if profile['model'].startswith('x-ai/grok-4.7'):
        completion_bound += max(profile['context_length'], profile.get('max_completion_tokens') or 0)
    rates = profile['rates']
    return input_bound * rates['input_bound_rate'] + completion_bound * rates['completion'] + rates['request']
