# Full-release collection plan

Budget amendment: the user has US$27.77 available. The active collection is the four affordable endpoint configurations in `collection_scope.json`, with 3,840 slots and a US$27 hard cap. The 21-model plan below is a costed design reference, not the active spending authorization.

120 fresh graphs x 8 variants x 21 model configurations = **20,160 new requests**.

No pilot responses are counted as final-test results. At original plan creation, no new inference had been launched.

Existing 8k pilot-cost scaling: **US$595.07**.
16k planning scenario at frozen endpoint prices: **US$955.77**.
Remaining authorization: **US$7.56**.

The scenario doubles observed non-Grok completion tokens, uses fresh endpoint tariffs and scales input bytes. Six tasks replace the pilot three, so these are planning estimates, not guaranteed prices. Grok has a native visible-only cap; it is not compute-matched.

| Model | Frozen endpoint | 16k scenario | Reservation ceiling |
| --- | --- | ---: | ---: |
| x-ai/grok-4.7 | xai | $115.05 | $2989.42 |
| qwen/qwen3.8-max-0902 | alibaba | $87.58 | $113.18 |
| openai/gpt-6.1-sol | openai/flex | $14.32 | $88.05 |
| google/gemini-4-argon | google-ai-studio/flex | $59.56 | $86.17 |
| deepseek/deepseek-v4.1-flash-1017 | sail-research/fp4 | $2.21 | $3.12 |
| moonshotai/kimi-k3.1-pro | moonshotai/mxfp4 | $68.53 | $172.33 |
| meta/muse-wonder | meta | $248.28 | $344.67 |
| z-ai/glm-5.3 | baidu/fp8 | $11.56 | $15.95 |
| xiaomi/mimo-v2.6-pro | deepinfra/fp8 | $8.18 | $15.23 |
| minimax/minimax-m3.1-flash | tenstorrent/fp8 | $2.43 | $3.52 |
| stepfun/step-5-preview | stepfun/fp8 | $35.96 | $49.99 |
| mistralai/mistral-large-4-0 | mistral | $29.07 | $38.30 |
| nvidia/nemotron-3.5-super-vl | coreweave/nvfp4 | $7.57 | $8.99 |
| inclusionai/ling-3.1-flash | deepinfra/fp4 | $3.31 | $4.10 |
| cohere/command-a-plus | cohere | $23.34 | $25.85 |
| amazon/nova-2-lite-v1 | amazon-bedrock | $38.75 | $41.58 |
| ibm-granite/granite-4.2-8b | coreweave/bf16 | $2.40 | $2.81 |
| google/gemma-4-31b-it | deepinfra/fp8/flex | $5.32 | $6.24 |
| meta-llama/llama-4-maverick | digitalocean | $1.13 | $11.67 |
| anthropic/claude-sonnet-5.5 | amazon-bedrock | $64.23 | $187.38 |
| anthropic/claude-opus-5.5 | amazon-bedrock | $127.00 | $374.77 |

A hard spending cap is separate from the total reservation ceiling: admission counts completed charges plus all in-flight reservations, and releases unused reservations when actual charges arrive. A cap below the eventual bill leaves the collection incomplete; it never authorizes overrun.

The all-21-model collection has not started. The affordable reference collection is tracked under `runs/` and `results/`; its cap is US$27. The larger matrix does not authorize additional spending.
