"""Paid collection: pinned endpoints, durable launch journal and a shared hard cap."""
import argparse
import collections
import concurrent.futures
import datetime
import hashlib
import json
import math
import os
import random
import time
import urllib.error
import uuid
from pathlib import Path

from core import SYSTEM
from service import api, reservation

ROOT = Path(__file__).resolve().parent


def append(path, row):
    with path.open('a', encoding='utf-8') as out:
        out.write(json.dumps(row) + '\n')
        out.flush()
        os.fsync(out.fileno())


def read_rows(path):
    return [json.loads(s) for s in path.read_text().splitlines()] if path.exists() else []


class Budget:
    def __init__(self, cap, spent=0):
        self.cap, self.spent, self.reserved = cap, spent, 0

    def reserve(self, bound):
        assert math.isfinite(bound) and bound >= 0
        if self.spent + self.reserved + bound > self.cap + 1e-10:
            return False
        self.reserved += bound
        return True

    def settle(self, bound, cost):
        assert math.isfinite(cost) and cost >= 0
        self.reserved -= bound
        self.spent += cost
        return cost <= bound + 1e-9 and self.spent + self.reserved <= self.cap + 1e-9


def payload(profile, prompt, plan):
    rates = profile['rates']
    body = {'model': profile['model'], 'messages': [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': prompt['prompt']}],
            'max_tokens': plan['max_tokens'], 'stream': False,
            'provider': {'only': [profile['endpoint']], 'order': [profile['endpoint']], 'allow_fallbacks': False,
                         'require_parameters': True, 'max_price': {'prompt': rates['prompt'] * 1e6,
                         'completion': rates['completion'] * 1e6, 'request': rates['request']}}}
    if profile['reasoning'] is not None:
        body['reasoning'] = profile['reasoning']
    return body


def collect_one(profile, prompt, plan, bound, attempt_id, key):
    body = payload(profile, prompt, plan)
    started = time.monotonic()
    result = {'attempt_id': attempt_id, 'model': profile['model'], 'id': prompt['id'], 'case_id': prompt['case_id'],
              'variant': prompt['variant'], 'task': prompt['task'], 'n': prompt['n'],
              'endpoint': profile['endpoint'], 'quantization': profile['quantization'], 'reserved_usd': bound,
              'request_settings': {k: v for k, v in body.items() if k != 'messages'}}
    try:
        response = api('/chat/completions', key, body, timeout=plan['timeout_seconds'])
        if response.get('error'):
            result.update(status='provider_error', error=json.dumps(response['error']).replace(key, '[REDACTED]')[:1500],
                          cost_usd=bound, cost_source='uncertain_upper_bound')
        else:
            choice = response['choices'][0]
            content = choice['message'].get('content') or ''
            if isinstance(content, list):
                content = ''.join(p.get('text', '') for p in content if isinstance(p, dict))
            if not isinstance(content, str):
                raise TypeError('Non-text answer')
            usage = response.get('usage') or {}
            cost = usage.get('cost')
            result.update(status='provider_error' if choice.get('finish_reason') == 'error' else 'ok',
                          answer_text=content.replace(key, '[REDACTED]'), response_id=response.get('id'),
                          model_returned=response.get('model'), provider=response.get('provider'),
                          finish_reason=choice.get('finish_reason'), usage=usage,
                          cost_usd=float(cost) if cost is not None else bound,
                          cost_source='provider' if cost is not None else 'uncertain_upper_bound')
            if result.get('provider') and result['provider'] != profile['provider_name']:
                result.update(status='protocol_error', error='Returned provider differs from frozen endpoint provider.')
    except urllib.error.HTTPError as exc:
        known_free = exc.code in (400, 401, 402, 403, 404, 422, 429)
        result.update(status='provider_error', http_status=exc.code, error=exc.read().decode(errors='replace').replace(key, '[REDACTED]')[:1500],
                      cost_usd=0 if known_free else bound, cost_source='pre_generation_rejection' if known_free else 'uncertain_upper_bound')
    except Exception as exc:
        result.update(status='provider_error', error_type=type(exc).__name__, cost_usd=bound, cost_source='uncertain_upper_bound')
    result['latency_seconds'] = round(time.monotonic() - started, 3)
    result['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    return result


def select_attempts(rows):
    selected = {}
    for row in rows:
        slot = (row['model'], row['id'])
        if slot not in selected or selected[slot]['status'] == 'provider_error':
            selected[slot] = row
    return selected


class RunLock:
    def __enter__(self):
        self.file = (ROOT / 'runs/run.lock').open('a+b')
        self.file.write(b'0')
        self.file.flush()
        self.file.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(self.file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return self

    def __exit__(self, *_):
        self.file.close()


def run(args):
    plan = json.loads((ROOT / 'run_plan.json').read_text())
    scope = json.loads((ROOT / 'collection_scope.json').read_text())
    assert args.budget_usd <= scope['authorized_cap_usd']
    assert math.isfinite(args.budget_usd) and args.budget_usd > 0
    assert hashlib.sha256((ROOT / 'data/prompts.json').read_bytes()).hexdigest() == plan['fixture_sha256']
    assert hashlib.sha256((ROOT / 'data/manifest.json').read_bytes()).hexdigest() == plan['manifest_sha256']
    assert SYSTEM == plan['system_prompt']
    profiles = {p['model']: p for p in plan['models'] if p['model'] in scope['models']}
    prompts = json.loads((ROOT / 'data/prompts.json').read_text())
    random.Random(20261103).shuffle(prompts)
    ledger = ROOT / 'runs/results.jsonl'
    journal = ROOT / 'runs/events.jsonl'
    rows = read_rows(ledger)
    events = read_rows(journal)
    finished = {r['attempt_id'] for r in rows}
    for e in events:
        if e['event'] == 'launch' and e['attempt_id'] not in finished:
            # A crash must not release money for a request that may have been billed.
            row = {**e, 'status': 'provider_error', 'error_type': 'collector_interrupted',
                   'cost_usd': e['reserved_usd'], 'cost_source': 'uncertain_upper_bound'}
            append(ledger, row)
            rows.append(row)
            finished.add(e['attempt_id'])
    spent = math.fsum(r['cost_usd'] for r in rows)
    selected = select_attempts(rows)
    attempts = collections.Counter((r['model'], r['id']) for r in rows)
    work = [(m, p) for p in prompts for m in profiles if (m, p['id']) not in selected or
            (args.recover and selected[(m, p['id'])]['status'] == 'provider_error' and attempts[(m, p['id'])] < 2)]
    print(json.dumps({'pending_slots': len(work), 'models': list(profiles), 'spent_usd': spent, 'cap_usd': args.budget_usd,
                      'execute': args.execute}), flush=True)
    if not args.execute:
        return
    source_hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in ('core.py', 'service.py', 'run.py')}
    source_path = ROOT / 'runs/collection_source_hashes.json'
    if source_path.exists():
        assert json.loads(source_path.read_text()) == source_hashes, 'Collection source changed; retain the old code or document a new protocol version.'
    else:
        source_path.write_text(json.dumps(source_hashes, indent=2) + '\n')
    key = os.environ['OPENROUTER_API_KEY']
    credit = api('/credits', key)['data']
    available = credit['total_credits'] - credit['total_usage']
    budget = Budget(min(args.budget_usd, spent + max(0, available - .5)), spent)
    append(ROOT / 'runs/execution_history.jsonl', {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'budget_usd': budget.cap, 'workers': args.workers, 'per_model': args.per_model, 'recover': args.recover,
           'plan_sha256': hashlib.sha256((ROOT / 'run_plan.json').read_bytes()).hexdigest(),
           'scope_sha256': hashlib.sha256((ROOT / 'collection_scope.json').read_bytes()).hexdigest()})
    active, errors = collections.Counter(), collections.Counter()
    pending, blocked, fatal = {}, set(), False
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        while pending or (work and not fatal):
            if (ROOT / 'runs/STOP').exists():
                fatal = True
            while len(pending) < args.workers and not fatal:
                picked = None
                for i, (m, p) in enumerate(work):
                    if m in blocked or active[m] >= args.per_model:
                        continue
                    bound = reservation(profiles[m], p['prompt'], SYSTEM, plan['max_tokens'])
                    if budget.reserve(bound):
                        picked = i, m, p, bound
                        break
                if picked is None:
                    break
                i, m, p, bound = picked
                work.pop(i)
                attempt_id = uuid.uuid4().hex
                launch = {'event': 'launch', 'attempt_id': attempt_id, 'model': m, 'id': p['id'], 'case_id': p['case_id'],
                          'variant': p['variant'], 'task': p['task'], 'n': p['n'], 'reserved_usd': bound,
                          'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
                append(journal, launch)
                active[m] += 1
                pending[pool.submit(collect_one, profiles[m], p, plan, bound, attempt_id, key)] = (m, bound)
            if not pending:
                break
            finished_futures, _ = concurrent.futures.wait(pending, return_when=concurrent.futures.FIRST_COMPLETED)
            for future in finished_futures:
                m, bound = pending.pop(future)
                active[m] -= 1
                row = future.result()
                if not budget.settle(bound, row['cost_usd']):
                    fatal = True
                append(ledger, row)
                rows.append(row)
                selected = select_attempts(rows)
                errors[m] = errors[m] + 1 if row['status'] == 'provider_error' else 0
                if errors[m] >= 3:
                    blocked.add(m)
                if row['status'] == 'protocol_error' or row.get('http_status') in (401, 402):
                    fatal = True
                progress = {'unique_slots': len(selected), 'planned_slots': len(profiles) * len(prompts), 'attempts': len(rows),
                            'spent_usd': budget.spent, 'reserved_usd': budget.reserved, 'cap_usd': budget.cap,
                            'blocked_models': sorted(blocked), 'fatal': fatal,
                            'by_model': dict(collections.Counter(r['model'] for r in selected.values()))}
                (ROOT / 'runs/progress.json').write_text(json.dumps(progress, indent=2))
                print(json.dumps({'slots': len(selected), 'attempts': len(rows), 'model': m, 'variant': row['variant'],
                                  'status': row['status'], 'finish_reason': row.get('finish_reason'),
                                  'spent_usd': round(budget.spent, 6)}), flush=True)
    print(json.dumps({'stopped': True, 'slots': len(select_attempts(rows)), 'planned': len(profiles) * len(prompts),
                      'spent_usd': budget.spent, 'blocked': sorted(blocked), 'fatal': fatal}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--budget-usd', type=float, required=True)
    parser.add_argument('--execute', action='store_true', help='Without this flag, collection is a free dry run.')
    parser.add_argument('--recover', action='store_true')
    parser.add_argument('--workers', type=int, default=32)
    parser.add_argument('--per-model', type=int, default=8)
    args = parser.parse_args()
    assert 1 <= args.workers <= 32 and 1 <= args.per_model <= 8
    (ROOT / 'runs').mkdir(exist_ok=True)
    with RunLock():
        run(args)
