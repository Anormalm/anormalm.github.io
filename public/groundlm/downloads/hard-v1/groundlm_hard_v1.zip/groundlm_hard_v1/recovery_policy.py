"""Audit the default one-recovery limit and the user's eight-slot exception."""
import collections
import hashlib
import json
import math
from pathlib import Path


def approved_exception(root):
    path = Path(root) / 'runs/recovery_exception_plan.json'
    if not path.exists():
        return None, set(), None
    policy = json.loads(path.read_text())
    if policy.get('approval_status') != 'approved':
        return policy, set(), None
    slots = {(s['model'], s['id']) for s in policy['slots']}
    assert len(policy['slots']) == len(slots) == 8
    assert policy['maximum_total_attempts_for_listed_slots'] == 3
    assert policy['unchanged_cumulative_cap_usd'] == 27
    assert math.isfinite(policy['max_additional_cost_usd']) and 0 <= policy['max_additional_cost_usd'] < .06
    return policy, slots, hashlib.sha256(path.read_bytes()).hexdigest()


def audit_attempts(rows, root):
    policy, approved, digest = approved_exception(root)
    groups = collections.defaultdict(list)
    for row in rows:
        groups[(row['model'], row['id'])].append(row)
    for slot, attempts in groups.items():
        assert len(attempts) <= (3 if slot in approved else 2), 'Unauthorized extra attempt.'
        assert all(r['status'] == 'provider_error' for r in attempts[:-1]), 'A recorded model answer was retried.'
        if len(attempts) == 3:
            assert attempts[-1].get('approved_extra_recovery') is True
            assert attempts[-1].get('recovery_approval_sha256') == digest
    extras = [r for r in rows if r.get('approved_extra_recovery')]
    assert all((r['model'], r['id']) in approved for r in extras)
    assert all(len(groups[(r['model'], r['id'])]) == 3 and groups[(r['model'], r['id'])][-1] is r for r in extras)
    assert len({(r['model'], r['id']) for r in extras}) == len(extras)
    if extras:
        assert math.fsum(r['cost_usd'] for r in extras) <= policy['max_additional_cost_usd'] + 1e-9
    return {'approved_exception_slots': len(approved), 'approved_extra_attempts': len(extras),
            'approved_extra_cost_usd': math.fsum(r['cost_usd'] for r in extras)}
