import itertools
import json
import threading
import unittest
import copy
import hashlib
import tempfile
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch
import networkx as nx
from core import oracle, independent_answer, graph_of
from score import parse_answer, estimate
from run import Budget, collect_one, payload, select_attempts
from validate import decode_prompt
from budget_controls import admission_decision
from evidence import certificate, verify_certificate
from availability_controls import eligible_rejections
from recovery_policy import audit_attempts
from supervise import has_default_recovery_work
import numpy as np


class ReleaseTests(unittest.TestCase):
    def test_supervisor_skips_empty_retry_passes_without_repeating_model_answers(self):
        valid={'model':'m','id':'q','status':'ok','correct':False,'finish_reason':'length'}
        failed={**valid,'status':'provider_error'}
        self.assertTrue(has_default_recovery_work([],['m'],['q']))
        self.assertTrue(has_default_recovery_work([failed],['m'],['q']))
        self.assertFalse(has_default_recovery_work([failed,failed],['m'],['q']))
        self.assertFalse(has_default_recovery_work([valid],['m'],['q']))
        self.assertTrue(has_default_recovery_work([valid],['m'],['q','untouched']))

    def test_approved_extra_recovery_is_limited_to_eight_slots_without_answer_retries(self):
        temp_base=Path(__file__).resolve().parents[2]/'tmp';temp_base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='extra_recovery_TEST_ONLY_',dir=temp_base) as folder:
            root=Path(folder).resolve();self.assertTrue(root.is_relative_to(temp_base.resolve()));(root/'runs').mkdir()
            policy={'approval_status':'approved','maximum_total_attempts_for_listed_slots':3,'unchanged_cumulative_cap_usd':27,
                    'max_additional_cost_usd':.054,'slots':[{'model':'m'+str(i),'id':'q'+str(i)} for i in range(8)]}
            path=root/'runs/recovery_exception_plan.json';path.write_text(json.dumps(policy))
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            failed={'model':'m0','id':'q0','status':'provider_error','cost_usd':0}
            third={**failed,'status':'ok','cost_usd':.001,'approved_extra_recovery':True,'recovery_approval_sha256':digest}
            self.assertEqual(audit_attempts([failed,failed,third],root)['approved_extra_attempts'],1)
            with self.assertRaises(AssertionError):audit_attempts([failed,{**failed,'status':'ok'},third],root)
            with self.assertRaises(AssertionError):audit_attempts([failed,failed,{**third,'approved_extra_recovery':False}],root)
            with self.assertRaises(AssertionError):audit_attempts([{**r,'id':'unapproved'} for r in [failed,failed,third]],root)
            with self.assertRaises(AssertionError):audit_attempts([failed,failed,{**third,'cost_usd':.055}],root)
            with self.assertRaises(AssertionError):audit_attempts([failed,failed,failed,third],root)
            with self.assertRaises(AssertionError):audit_attempts([third],root)

    def test_endpoint_revision_requires_unbilled_rejections_before_first_generation(self):
        row={'model':'m','status':'provider_error','http_status':429,'cost_source':'pre_generation_rejection','cost_usd':0}
        self.assertTrue(eligible_rejections([row],'m'))
        self.assertFalse(eligible_rejections([],'m'))
        for change in ({'status':'ok'},{'cost_usd':.001},{'response_id':'generated'},{'http_status':503}):
            self.assertFalse(eligible_rejections([{**row,**change}],'m'))

    def test_endpoint_revision_rejects_price_increase_and_preserves_original_plan(self):
        import availability_controls as controls
        import os
        model='inclusionai/ling-3.1-flash'
        temp_base=Path(__file__).resolve().parents[2]/'tmp'
        temp_base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='endpoint_revision_TEST_ONLY_',dir=temp_base) as folder:
            root=Path(folder).resolve()
            self.assertTrue(root.is_relative_to(temp_base.resolve()))
            (root/'runs').mkdir();(root/'data').mkdir()
            prices={'prompt':.000000075,'completion':.000000225,'request':0,'input_bound_rate':.000000075}
            plan={'system_prompt':'test','max_tokens':16384,'models':[{'model':model,'endpoint':'deepinfra/fp4','quantization':'fp4','rates':prices}]}
            raw_plan=json.dumps(plan).encode();(root/'run_plan.json').write_bytes(raw_plan)
            (root/'collection_scope.json').write_text(json.dumps({'authorized_cap_usd':27,'plan_sha256':hashlib.sha256(raw_plan).hexdigest(),'scope_note':'test'}))
            (root/'availability_policy.json').write_text(json.dumps({'model':model,'replacement_endpoint':'novita'}))
            (root/'data/prompts.json').write_text(json.dumps([{'id':'q','prompt':'fixed question'}]))
            row={'attempt_id':'a','model':model,'status':'provider_error','http_status':429,'cost_source':'pre_generation_rejection','cost_usd':0}
            (root/'runs/results.jsonl').write_text(json.dumps(row)+'\n')
            (root/'runs/events.jsonl').write_text(json.dumps({'event':'launch','attempt_id':'a'})+'\n')
            endpoint={'tag':'novita','provider_name':'Novita','quantization':'unknown','status':0,'context_length':1000000,'max_completion_tokens':262144,
                      'supported_parameters':['reasoning','max_tokens'],'pricing':{'prompt':prices['prompt'],'completion':prices['completion']*2}}
            with patch.object(controls,'ROOT',root),patch.dict(os.environ,{'OPENROUTER_API_KEY':'TEST_ONLY'}),patch.object(controls,'api',return_value={'data':{'endpoints':[endpoint]}}):
                controls.maybe_repin_unavailable_endpoint()
                self.assertEqual((root/'run_plan.json').read_bytes(),raw_plan)
                endpoint['pricing']['completion']=prices['completion']
                controls.maybe_repin_unavailable_endpoint()
            updated=json.loads((root/'run_plan.json').read_text())
            scope=json.loads((root/'collection_scope.json').read_text())
            self.assertEqual(updated['models'][0]['endpoint'],'novita')
            self.assertEqual(scope['authorized_cap_usd'],27)
            self.assertEqual(scope['plan_sha256'],hashlib.sha256((root/'run_plan.json').read_bytes()).hexdigest())
            self.assertEqual((root/'runs/run_plan_before_endpoint_revision.json').read_bytes(),raw_plan)
            self.assertEqual(json.loads((root/'data/prompts.json').read_text()),[{'id':'q','prompt':'fixed question'}])

    def test_serialized_certificates_reject_tampering_for_every_task(self):
        cases=json.loads((Path(__file__).parent/'data/cases.json').read_text())
        selected={}
        for c in cases:
            selected.setdefault(c['task'],c)
        for task,c in selected.items():
            with self.subTest(task=task):
                proof=json.loads(json.dumps(certificate(c)))
                self.assertTrue(verify_certificate(proof))
                broken=copy.deepcopy(proof)
                if task=='weighted_shortest_path': broken['distances'][c['target']]+=1
                elif task=='minimum_cut': broken['source_side'].append(c['target'])
                elif task=='triangle_count': broken['triangles'].append([0,1,2])
                elif task=='shortest_path_count': broken['path_counts'][c['target']]+=1
                elif task=='exact_walk_count': broken['walk_count_rows'][-1][c['target']]+=1
                else: broken['source_component'].append(c['target'])
                with self.assertRaises(AssertionError): verify_certificate(broken)

    def test_weak_baseline_reserves_remaining_core_work_and_retries(self):
        def profile(model, price):
            return {'model':model,'rates':{'input_bound_rate':0,'completion':price,'request':0}}
        plan={'max_tokens':10,'models':[profile('core',.01),profile('weak',.02)]}
        scope={'models':['core'],'authorized_cap_usd':.69}
        prompts=[{'id':name,'prompt':'question'} for name in ('a','b')]
        self.assertFalse(admission_decision(plan,scope,prompts,[],[],'weak')['admit'])
        rows=[{'attempt_id':name,'model':'core','id':name,'status':'ok','cost_usd':.01} for name in ('a','b')]
        events=[{'event':'launch','attempt_id':name} for name in ('a','b')]
        decision=admission_decision(plan,scope,prompts,rows,events,'weak')
        self.assertTrue(decision['admit']); self.assertAlmostEqual(decision['projected_total_bound_usd'],.52)
        self.assertFalse(admission_decision(plan,scope,prompts,rows,events+[{'event':'launch','attempt_id':'unresolved'}],'weak')['admit'])
        failed=[{**rows[0],'status':'provider_error','cost_usd':.03}]
        self.assertFalse(admission_decision(plan,scope,prompts,failed,events[:1],'weak')['admit'])

    def test_exact_oracles_against_exhaustive_small_graph(self):
        c = {'n': 5, 'edges': [[0,1,2],[1,2,3],[0,2,6],[2,3,1],[1,3,5],[3,4,1]],
             'source': 0, 'target': 4, 'blocked': [2], 'walk_length': 4}
        g = graph_of(c)
        paths = list(nx.all_simple_paths(g, 0, 4))
        lengths = [len(p)-1 for p in paths]
        expected = {'weighted_shortest_path': min(sum(g[a][b]['weight'] for a,b in zip(p,p[1:])) for p in paths),
                    'shortest_path_count': lengths.count(min(lengths)),
                    'triangle_count': sum(all(g.has_edge(a,b) for a,b in itertools.combinations(v,2)) for v in itertools.combinations(g,3)),
                    'exact_walk_count': sum(all(g.has_edge(a,b) for a,b in zip(p,p[1:])) for middle in itertools.product(g,repeat=3) for p in [[0,*middle,4]]),
                    'constrained_reachability': 1,
                    'minimum_cut': min(sum(d['weight'] for a,b,d in g.edges(data=True) if (a in subset)!=(b in subset))
                                       for mask in range(8) for subset in [{0}|{v for i,v in enumerate((1,2,3)) if mask>>i&1}])}
        for task, value in expected.items():
            with self.subTest(task=task):
                self.assertEqual(oracle(g,task,0,4,[2],4),value)
                self.assertEqual(independent_answer({**c,'task':task}),value)

    def test_parser_does_not_read_reasoning_numbers_or_boolean(self):
        self.assertEqual(parse_answer('I counted 999 items.\n{"answer":0}'), (0,False))
        for text in ('{"answer":true}', '{"answer":-1}', 'Answer: 3', '{"answer":2,"answer":3}', '{"answer":3,"extra":1}'):
            self.assertIsNone(parse_answer(text)[0])

    def test_full_denominator_perfect_sample_has_uncertainty(self):
        result = estimate([1]*120,np.tile(np.arange(120),(200,1)))
        self.assertEqual(result['value'],1)
        self.assertLess(result['ci95'][0],1)
        self.assertEqual(result['n_graphs'],120)

    def test_no_better_answer_selection_on_recovery(self):
        wrong={'model':'m','id':'q','status':'ok','answer_text':'{"answer":2}'}
        right={**wrong,'answer_text':'{"answer":3}'}
        self.assertEqual(select_attempts([wrong,right])[('m','q')],wrong)
        self.assertEqual(select_attempts([{**wrong,'status':'provider_error'},right])[('m','q')],right)

    def test_reservations_include_inflight_and_cannot_over_admit(self):
        b=Budget(1,.1)
        self.assertTrue(b.reserve(.7)); self.assertFalse(b.reserve(.3))
        self.assertTrue(b.settle(.7,.2)); self.assertTrue(b.reserve(.6))

    def test_duplicate_or_unknown_serialized_edges_rejected(self):
        for edges in ('X0 -- X1\nX0 -- X1','X0 -- X2'):
            with self.assertRaises(AssertionError):
                decode_prompt('The complete node set is:\nX0, X1\nThe complete edge list is:\n'+edges+'\n\nQuestion: test')

    def test_local_http_collection_sends_only_question_and_frozen_settings(self):
        captured=[]
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_POST(self):
                captured.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
                body=json.dumps({'id':'local-test','provider':'Mock','model':'test/m','choices':[{'message':{'content':'{"answer":3}'},'finish_reason':'stop'}],
                                 'usage':{'cost':.001,'completion_tokens':5}}).encode()
                self.send_response(200); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        profile={'model':'test/m','endpoint':'mock/fp8','quantization':'fp8','provider_name':'Mock',
                 'rates':{'prompt':.000001,'completion':.000002,'request':0},'reasoning':{'effort':'high'}}
        p={'id':'q','case_id':'c','variant':'original','task':'triangle_count','n':5,'prompt':'Question only','ground_truth':42}
        try:
            with patch('service.BASE',f'http://127.0.0.1:{server.server_port}'):
                r=collect_one(profile,p,{'max_tokens':16384,'timeout_seconds':2},.04,'attempt1','mock-secret')
            self.assertEqual(r['status'],'ok'); self.assertEqual(r['cost_usd'],.001)
            self.assertEqual(captured[0]['provider']['only'],['mock/fp8'])
            self.assertNotIn('ground_truth',json.dumps(captured))
            self.assertNotIn('mock-secret',json.dumps(r))
            self.assertEqual(captured[0]['messages'][1]['content'],'Question only')
        finally:
            server.shutdown();server.server_close();thread.join()


if __name__=='__main__': unittest.main()
