"""Document a same-price endpoint revision before a model has any generations."""
import datetime
import hashlib
import json
import os
from pathlib import Path
from run import append, read_rows
from service import api, rates_for

ROOT = Path(__file__).resolve().parent


def eligible_rejections(rows, model):
    records = [r for r in rows if r['model'] == model]
    return bool(records) and all(r['status'] == 'provider_error' and r.get('http_status') == 429
                                 and r.get('cost_source') == 'pre_generation_rejection'
                                 and r['cost_usd'] == 0 and not r.get('response_id') for r in records)


def maybe_repin_unavailable_endpoint():
    policy_path = ROOT / 'availability_policy.json'
    if not policy_path.exists() or (ROOT / 'runs/STOP').exists():
        return
    policy = json.loads(policy_path.read_text())
    scope_path, plan_path = ROOT / 'collection_scope.json', ROOT / 'run_plan.json'
    scope, plan = json.loads(scope_path.read_text()), json.loads(plan_path.read_text())
    profile = next(p for p in plan['models'] if p['model'] == policy['model'])
    if profile['endpoint'] == policy['replacement_endpoint']:
        return
    rows, events = read_rows(ROOT / 'runs/results.jsonl'), read_rows(ROOT / 'runs/events.jsonl')
    if {e['attempt_id'] for e in events if e['event'] == 'launch'} != {r['attempt_id'] for r in rows}:
        return
    if not eligible_rejections(rows, policy['model']):
        return
    # Catalog lookup only; this is not a billable generation or a test answer.
    response = api('/models/' + policy['model'] + '/endpoints', os.environ['OPENROUTER_API_KEY'])['data']
    candidates = [e for e in response['endpoints'] if e['tag'] == policy['replacement_endpoint'] and e.get('status', 0) == 0]
    if not candidates:
        return
    endpoint = candidates[0]
    prompts = json.loads((ROOT / 'data/prompts.json').read_text())
    input_bound = max(len((plan['system_prompt'] + p['prompt']).encode()) + 4096 for p in prompts)
    rates = rates_for(endpoint['pricing'], input_bound)
    if any(rates[k] > profile['rates'][k] + 1e-15 for k in profile['rates']):
        return
    if not {'reasoning', 'max_tokens'}.issubset(endpoint.get('supported_parameters', [])):
        return
    if (endpoint.get('max_completion_tokens') or 0) < plan['max_tokens'] or endpoint.get('context_length', 0) < input_bound + plan['max_tokens']:
        return
    previous_hash = hashlib.sha256(plan_path.read_bytes()).hexdigest()
    assert scope['plan_sha256'] == previous_hash
    old_profile = dict(profile)
    revision = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'model': policy['model'],
                'from_endpoint': profile['endpoint'], 'to_endpoint': endpoint['tag'],
                'from_precision': profile['quantization'], 'to_precision': endpoint.get('quantization') or 'unspecified',
                'reason': 'All prior attempts were zero-charge upstream 429 rejections; no successful model response exists.',
                'prior_plan_sha256': previous_hash, 'spending_cap_usd': scope['authorized_cap_usd'],
                'input_and_output_prices_increased': False, 'prompt_or_inference_setting_changes': False}
    (ROOT / 'runs/run_plan_before_endpoint_revision.json').write_bytes(plan_path.read_bytes())
    (ROOT / 'runs/scope_before_endpoint_revision.json').write_bytes(scope_path.read_bytes())
    (ROOT / 'runs/endpoint_revision_catalog.json').write_text(json.dumps(response, indent=2) + '\n')
    profile.update(endpoint=endpoint['tag'], provider_name=endpoint['provider_name'],
                   quantization=endpoint.get('quantization') or 'unspecified', rates=rates,
                   context_length=endpoint['context_length'], max_completion_tokens=endpoint.get('max_completion_tokens'),
                   endpoint_selection='Documented same-price availability revision before the first generation; see runs/endpoint_revisions.jsonl.')
    plan.setdefault('availability_revisions', []).append(revision)
    plan_path.write_text(json.dumps(plan, indent=2) + '\n')
    scope['plan_sha256'] = hashlib.sha256(plan_path.read_bytes()).hexdigest()
    scope.setdefault('availability_revisions', []).append(revision)
    scope['scope_note'] += ' Ling was repinned before its first generation after zero-charge rate-limit rejections; endpoint precision is reported from the replacement catalog.'
    scope_path.write_text(json.dumps(scope, indent=2) + '\n')
    append(ROOT / 'runs/endpoint_revisions.jsonl', {**revision, 'old_profile': old_profile, 'new_profile': dict(profile),
           'new_plan_sha256': scope['plan_sha256']})
