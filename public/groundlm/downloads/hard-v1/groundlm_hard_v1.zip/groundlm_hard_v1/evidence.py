"""Exact, independently checkable certificates and recorded completed errors.

No model calls. Certificate verification uses the saved graph and witness,
without invoking the benchmark's answer oracle.
"""
import hashlib
import itertools
import json
from pathlib import Path
import networkx as nx
from core import graph_of

ROOT = Path(__file__).resolve().parent


def certificate(case):
    g = graph_of(case)
    n, s, t, task = case['n'], case['source'], case['target'], case['task']
    proof = {k: case[k] for k in ('id', 'task', 'n', 'source', 'target', 'blocked', 'walk_length', 'edges', 'answer')}
    if task == 'weighted_shortest_path':
        distances, paths = nx.single_source_dijkstra(g, s, weight='weight')
        proof.update(path=paths[t], distances=[distances[v] for v in range(n)])
    elif task == 'minimum_cut':
        _, (left, right) = nx.minimum_cut(g, s, t, capacity='weight')
        value, flow = nx.maximum_flow(g, s, t, capacity='weight', flow_func=nx.algorithms.flow.edmonds_karp)
        proof.update(source_side=sorted(left), target_side=sorted(right), flow_value=value,
                     directed_flow=[[a, b, f] for a in sorted(flow) for b, f in sorted(flow[a].items()) if f])
    elif task == 'triangle_count':
        proof['triangles'] = [list(v) for v in itertools.combinations(range(n), 3)
                              if all(g.has_edge(a, b) for a, b in itertools.combinations(v, 2))]
    elif task == 'shortest_path_count':
        levels = nx.single_source_shortest_path_length(g, s)
        counts = dict.fromkeys(g, 0)
        counts[s] = 1
        for v in sorted(g, key=levels.get):
            if v != s:
                counts[v] = sum(counts[u] for u in g[v] if levels[u] == levels[v] - 1)
        proof.update(levels=[levels[v] for v in range(n)], path_counts=[counts[v] for v in range(n)])
    elif task == 'exact_walk_count':
        rows = [[int(v == s) for v in range(n)]]
        for _ in range(case['walk_length']):
            rows.append([sum(rows[-1][u] for u in g[v]) for v in range(n)])
        proof['walk_count_rows'] = rows
    else:
        h = g.copy()
        h.remove_nodes_from(case['blocked'])
        if case['answer']:
            proof['path'] = nx.shortest_path(h, s, t)
        else:
            proof['source_component'] = sorted(nx.node_connected_component(h, s))
    verify_certificate(proof)
    return proof


def verify_certificate(proof):
    g = graph_of(proof)
    n, s, t, task, y = proof['n'], proof['source'], proof['target'], proof['task'], proof['answer']
    assert type(y) is int and y >= 0
    if task == 'weighted_shortest_path':
        distances, path = proof['distances'], proof['path']
        assert len(distances) == n and distances[s] == 0 and path[0] == s and path[-1] == t
        assert all(type(d) is int and d >= 0 for d in distances)
        assert all(abs(distances[a] - distances[b]) <= d['weight'] for a, b, d in g.edges(data=True))
        assert sum(g[a][b]['weight'] for a, b in zip(path, path[1:])) == distances[t] == y
    elif task == 'minimum_cut':
        left, right = set(proof['source_side']), set(proof['target_side'])
        assert left.isdisjoint(right) and left | right == set(g) and s in left and t in right
        cut = sum(d['weight'] for a, b, d in g.edges(data=True) if (a in left) != (b in left))
        balances = dict.fromkeys(g, 0)
        seen = set()
        for a, b, flow in proof['directed_flow']:
            assert (a, b) not in seen and g.has_edge(a, b)
            assert type(flow) is int and 0 <= flow <= g[a][b]['weight']
            seen.add((a, b))
            balances[a] += flow
            balances[b] -= flow
        assert cut == proof['flow_value'] == y
        assert all(net == (y if v == s else -y if v == t else 0) for v, net in balances.items())
    elif task == 'triangle_count':
        triangles = {tuple(v) for v in proof['triangles']}
        actual = {v for v in itertools.combinations(range(n), 3) if all(g.has_edge(a, b) for a, b in itertools.combinations(v, 2))}
        assert triangles == actual and len(triangles) == len(proof['triangles']) == y
    elif task == 'shortest_path_count':
        levels, counts = proof['levels'], proof['path_counts']
        assert len(levels) == len(counts) == n and levels[s] == 0 and counts[s] == 1
        assert all(type(v) is int and v >= 0 for v in levels + counts)
        assert all(abs(levels[a] - levels[b]) <= 1 for a, b in g.edges())
        for v in g:
            if v != s:
                assert levels[v] > 0
                predecessors = [u for u in g[v] if levels[u] == levels[v] - 1]
                assert predecessors and counts[v] == sum(counts[u] for u in predecessors)
        assert counts[t] == y
    elif task == 'exact_walk_count':
        rows = proof['walk_count_rows']
        assert len(rows) == proof['walk_length'] + 1 and all(len(row) == n for row in rows)
        assert rows[0] == [int(v == s) for v in range(n)]
        assert all(type(v) is int and v >= 0 for row in rows for v in row)
        assert all(row[v] == sum(previous[u] for u in g[v]) for previous, row in zip(rows, rows[1:]) for v in g)
        assert rows[-1][t] == y
    elif task == 'constrained_reachability':
        h = g.copy()
        h.remove_nodes_from(proof['blocked'])
        assert y in (0, 1)
        if y:
            path = proof['path']
            assert path[0] == s and path[-1] == t and all(v in h for v in path)
            assert all(h.has_edge(a, b) for a, b in zip(path, path[1:]))
        else:
            component = set(proof['source_component'])
            assert component <= set(h) and s in component and t not in component
            assert not any((a in component) != (b in component) for a, b in h.edges())
    else:
        raise AssertionError('Unknown task')
    return True


def build(root=None):
    root = Path(root) if root else ROOT
    out = root / 'evidence'
    out.mkdir(exist_ok=True)
    cases = json.loads((root / 'data/cases.json').read_text())
    for c in cases:
        proof = certificate(c)
        (out / (c['id'] + '.json')).write_text(json.dumps(proof, indent=2) + '\n')
        # Check the actual JSON round trip as well as the in-memory witness.
        verify_certificate(json.loads((out / (c['id'] + '.json')).read_text()))
    scored_path = root / 'results/scored_results.json'
    rows = json.loads(scored_path.read_text()) if scored_path.exists() else []
    groups = {}
    for r in rows:
        groups.setdefault((r['model'], r['case_id']), {})[r['variant']] = r
    errors, changes = [], []
    for r in rows:
        if r['status'] != 'ok' or r.get('finish_reason') == 'length' or r['parsed_answer'] is None or r['correct']:
            continue
        record = {k: r.get(k) for k in ('model', 'id', 'case_id', 'task', 'variant', 'endpoint', 'quantization',
                                       'provider', 'model_returned', 'ground_truth', 'parsed_answer', 'answer_text', 'response_id')}
        record['certificate'] = r['case_id'] + '.json'
        errors.append(record)
        original = groups[(r['model'], r['case_id'])].get('original')
        if original and original['correct'] and r['variant'] != 'original':
            changes.append({**record, 'original_prompt_id': original['id'], 'original_answer_text': original.get('answer_text'),
                            'change_type': 'unchanged-input variation' if r['variant'] == 'repeat' else 'changed representation',
                            'interpretation': 'Recorded paired observation; one response per prompt does not isolate causality.'})
    (out / 'completed_numeric_errors.json').write_text(json.dumps(errors, indent=2) + '\n')
    (out / 'completed_changes_from_correct_originals.json').write_text(json.dumps(changes, indent=2) + '\n')
    manifest = {'verified_certificates': len(cases), 'completed_numeric_errors': len(errors),
                'completed_changes_from_correct_originals': len(changes),
                'scored_snapshot_sha256': hashlib.sha256(scored_path.read_bytes()).hexdigest() if scored_path.exists() else None,
                'case_fixture_sha256': hashlib.sha256((root / 'data/cases.json').read_bytes()).hexdigest(),
                'verification': 'Every serialized witness verified without calling the benchmark answer oracle.'}
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(manifest))
    return manifest


if __name__ == '__main__':
    build()
