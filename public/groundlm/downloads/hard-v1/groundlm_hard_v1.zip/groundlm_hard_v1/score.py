"""Answer scoring and graph-level, task/size-stratified uncertainty estimates."""
import collections
import csv
import json
import math
import re
from pathlib import Path
import numpy as np
from core import VARIANTS
from run import read_rows, select_attempts

ROOT = Path(__file__).resolve().parent


def parse_answer(text):
    def decode(value):
        try:
            pairs = json.loads(value, object_pairs_hook=list)
        except (ValueError, TypeError):
            return None
        if isinstance(pairs, list) and len(pairs) == 1 and isinstance(pairs[0], tuple):
            key, answer = pairs[0]
            if key == 'answer' and type(answer) is int and answer >= 0:
                return answer
        return None
    text = text.strip()
    plain = re.sub(r'^```(?:json)?\s*|\s*```$', '', text)
    direct = decode(plain)
    if direct is not None:
        return direct, True
    match = re.search(r'(\{\s*"answer"\s*:\s*\d+\s*\})\s*(?:```)?\s*$', text)
    return (decode(match.group(1)), False) if match else (None, False)


def estimate(values, bootstrap_indices):
    a = np.array(values, dtype=float)
    valid = a[np.isfinite(a)]
    result = {'value': float(valid.mean()) if len(valid) else None, 'n_graphs': len(valid)}
    if not len(valid):
        result.update(ci95=None, stratified_bootstrap_ci95=None)
        return result
    samples = a[bootstrap_indices]
    n = np.isfinite(samples).sum(axis=1)
    means = np.nansum(samples, axis=1) / np.maximum(1, n)
    means = means[n > 0]
    result['stratified_bootstrap_ci95'] = [float(v) for v in np.quantile(means, [.025, .975])] if len(means) else None
    if np.isin(valid, [0, 1]).all():
        z, count, p = 1.95996398454, len(valid), float(valid.mean())
        center = (p + z * z / (2 * count)) / (1 + z * z / count)
        half = z * math.sqrt(p * (1 - p) / count + z * z / (4 * count * count)) / (1 + z * z / count)
        result['ci95'] = [max(0, center - half), min(1, center + half)]
        result['ci_method'] = 'Wilson; graph unit, unconditional within the available denominator'
    else:
        result['ci95'] = result['stratified_bootstrap_ci95']
        result['ci_method'] = 'Task/size-stratified graph bootstrap'
    return result


def score(bootstrap_samples=2000):
    plan = json.loads((ROOT / 'run_plan.json').read_text())
    scope = json.loads((ROOT / 'collection_scope.json').read_text())
    cases = json.loads((ROOT / 'data/cases.json').read_text())
    prompts = {p['id']: p for p in json.loads((ROOT / 'data/prompts.json').read_text())}
    attempts = read_rows(ROOT / 'runs/results.jsonl')
    selected = select_attempts(attempts)
    scored = []
    for r in selected.values():
        p = prompts[r['id']]
        parsed, compliant = parse_answer(r.get('answer_text', '')) if r['status'] == 'ok' else (None, False)
        scored.append({**r, 'ground_truth': p['ground_truth'], 'parsed_answer': parsed,
                       'correct': r['status'] == 'ok' and parsed == p['ground_truth'], 'format_compliant': compliant})
    strata = collections.defaultdict(list)
    for i, c in enumerate(cases):
        strata[(c['task'], c['n'])].append(i)
    rng = np.random.default_rng(20261103)
    bootstrap = np.concatenate([rng.choice(ix, (bootstrap_samples, len(ix)), replace=True) for ix in strata.values()], axis=1)
    models = {}
    for model in scope['models']:
        profile = next(m for m in plan['models'] if m['model'] == model)
        rr = [r for r in scored if r['model'] == model]
        groups = collections.defaultdict(dict)
        for r in rr:
            groups[r['case_id']][r['variant']] = r
        metrics = collections.defaultdict(list)
        for c in cases:
            g = groups[c['id']]
            b = g.get('original', {})
            for v in VARIANTS:
                r = g.get(v, {})
                both = b.get('status') == r.get('status') == 'ok'
                parseable = both and b.get('parsed_answer') is not None and r.get('parsed_answer') is not None
                metrics['accuracy_' + v].append(float(r['correct']) if r.get('status') == 'ok' else np.nan)
                if v == 'original':
                    continue
                metrics['agreement_' + v].append(float(b['parsed_answer'] == r['parsed_answer']) if parseable else np.nan)
                metrics['survival_' + v].append(float(r['correct']) if both and b['correct'] else np.nan)
                metrics['returned_pair_coverage_' + v].append(float(both))
                metrics['parseable_pair_coverage_' + v].append(float(parseable))
            neutral, semantic = g.get('neutral', {}), g.get('degree_reversed', {})
            valid = all(r.get('status') == 'ok' and r.get('parsed_answer') is not None for r in (b, neutral, semantic))
            metrics['matched_semantic_gap'].append(float(b['parsed_answer'] == neutral['parsed_answer']) - float(b['parsed_answer'] == semantic['parsed_answer']) if valid else np.nan)
        correct = sum(r['correct'] for r in rr)
        wrong = sum(r['status'] == 'ok' and r.get('finish_reason') != 'length' and r['parsed_answer'] is not None and not r['correct'] for r in rr)
        invalid = sum(r['status'] == 'ok' and r.get('finish_reason') != 'length' and r['parsed_answer'] is None for r in rr)
        cutoffs = sum(r['status'] == 'ok' and r.get('finish_reason') == 'length' and not r['correct'] for r in rr)
        errors = sum(r['status'] != 'ok' for r in rr)
        assert correct + wrong + invalid + cutoffs + errors == len(rr)
        models[model] = {'endpoint': profile['endpoint'], 'quantization': profile['quantization'],
                         'collected_slots': len(rr), 'planned_slots': 960, 'correct': correct,
                         'completed_numeric_wrong': wrong, 'invalid_completed': invalid, 'cutoffs': cutoffs,
                         'provider_or_protocol_errors': errors, 'cost_usd': math.fsum(r['cost_usd'] for r in attempts if r['model'] == model),
                         'metrics': {name: estimate(values, bootstrap) for name, values in metrics.items()},
                         'by_task': {task: {'correct': sum(r['correct'] for r in rr if r['task'] == task),
                                          'collected': sum(r['task'] == task for r in rr), 'planned': 160} for task, _ in strata}}
    out = ROOT / 'results'
    out.mkdir(exist_ok=True)
    spent = math.fsum(r['cost_usd'] for r in attempts)
    complete = len(selected) == scope['planned_slots'] and all(r['status'] == 'ok' for r in selected.values())
    summary = {'version': plan['version'], 'collection_complete': complete, 'new_slots': len(selected),
               'planned_slots': scope['planned_slots'], 'attempts': len(attempts), 'spent_usd': spent,
               'cap_usd': scope['authorized_cap_usd'], 'remaining_cap_usd': scope['authorized_cap_usd'] - spent,
               'uncertain_cost_upper_bound_usd': math.fsum(r['cost_usd'] for r in attempts if r['cost_source'] == 'uncertain_upper_bound'),
               'bootstrap_samples': bootstrap_samples, 'bootstrap_unit': 'graph case, stratified by task and size',
               'models': models}
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    (out / 'scored_results.json').write_text(json.dumps(scored, indent=2) + '\n')
    with (out / 'metrics.csv').open('w', newline='') as f:
        fields = ['model', 'endpoint', 'quantization', 'metric', 'value', 'n_graphs', 'ci95_low', 'ci95_high']
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for model, m in models.items():
            for name, metric in m['metrics'].items():
                ci = metric['ci95'] or [None, None]
                writer.writerow({'model': model, 'endpoint': m['endpoint'], 'quantization': m['quantization'],
                                 'metric': name, 'value': metric['value'], 'n_graphs': metric['n_graphs'], 'ci95_low': ci[0], 'ci95_high': ci[1]})
    lines = ['# GroundLM Hard v1 reference evaluation', '',
             f'Collection complete: **{complete}**. Slots: **{len(selected)}/{scope["planned_slots"]}**. Recorded cost/upper bound: **US${spent:.4f} / US${scope["authorized_cap_usd"]:.2f}**.', '',
             f'120 fresh independent graphs, six tasks, 32/64 nodes, eight conditions including an identical-input repeat. The active scope contains {len(models)} endpoint configurations. Endpoints and inference settings were frozen before collection. An optional weak control may be admitted later using remaining budget, without inspecting answer quality. Endpoint precision is named explicitly. The earlier 21-model pilot is separate and is not represented as a full leaderboard.', '',
             '| Configuration | Slots | Correct | Completed wrong | Invalid | Cutoffs | Provider errors | Cost |',
             '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for model, m in models.items():
        lines.append(f'| {model} ({m["quantization"]}; {m["endpoint"]}) | {m["collected_slots"]}/960 | {m["correct"]} | {m["completed_numeric_wrong"]} | {m["invalid_completed"]} | {m["cutoffs"]} | {m["provider_or_protocol_errors"]} | ${m["cost_usd"]:.4f} |')
    lines += ['', '## Structural diagnostics', '',
              'Each rate below includes its actual graph denominator. Agreement requires two parseable answers; survival requires a correct original and a returned counterpart. Invalid/cutoff counterparts fail survival; API errors are excluded and exposed through coverage. Small parseable subsets must not be read as broad invariance. A repeat measures response variation without changing the input.', '',
              '| Configuration | Original accuracy | Neutral agreement | Reversed-name agreement | Reversed-name survival | Repeat agreement |',
              '| --- | ---: | ---: | ---: | ---: | ---: |']
    for model, m in models.items():
        values = []
        for key in ('accuracy_original', 'agreement_neutral', 'agreement_degree_reversed', 'survival_degree_reversed', 'agreement_repeat'):
            v = m['metrics'][key]
            values.append('n/a (0)' if v['value'] is None else f'{100*v["value"]:.1f}% ({v["n_graphs"]})')
        lines.append('| ' + model + ' | ' + ' | '.join(values) + ' |')
    lines += ['', '## Interpretation and reproducibility', '',
              'Confidence intervals use graph cases, never the eight correlated variants as independent observations. Binary rates include Wilson intervals plus the stratified bootstrap interval; the matched semantic gap uses the same parseable triples and a stratified graph bootstrap. Perfect bootstrap samples can be degenerate, so Wilson intervals remain visible.', '',
              'The main run requests high reasoning effort when available, 16,384 max_tokens and no tools. Sampling settings are omitted for all endpoints. Different tokenizers, reasoning implementations and endpoint quantization prevent equal-compute claims. Names encode degree alignment, not verified task roles; naming interventions also change tokenization. Distractors are query-equivalent additions, not graph isomorphisms.', '',
              'The reachability construction is a balanced controlled bridge test. Layered graphs provide shortest-path-count questions; the other numeric tasks use connected random graphs. This release tests these stated synthetic graph families and sizes; it does not establish natural-graph generalization.', '',
              'Raw attempts and the launch journal are immutable. Provider failures may normally be recovered once. The user approved one additional infrastructure-only attempt for exactly eight named slots after a network interruption; the approval, cost bound and affected IDs are recorded in runs/recovery_exception_plan.json. No wrong answer, invalid model answer or token cutoff is retried. No earlier pilot observations are counted in this release. See data/manifest.json, validation.json, run_plan.json and collection_scope.json for the frozen protocol.']
    (out / 'REPORT.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({k: summary[k] for k in ('collection_complete', 'new_slots', 'planned_slots', 'attempts', 'spent_usd')}))
    return summary


if __name__ == '__main__':
    score()
