"""Verify the saved collection and export a self-contained, explicitly scoped artifact."""
import collections
import hashlib
import importlib.metadata
import json
import math
import os
import platform
import zipfile
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from score import score
from run import read_rows, select_attempts
from validate import validate
from evidence import build as build_evidence
from recovery_policy import audit_attempts

ROOT = Path(__file__).resolve().parent


def export():
    validate()
    summary = score()
    evidence = build_evidence(ROOT)
    plan = json.loads((ROOT / 'run_plan.json').read_text())
    scope = json.loads((ROOT / 'collection_scope.json').read_text())
    rows = read_rows(ROOT / 'runs/results.jsonl')
    selected = select_attempts(rows)
    prompts = {p['id']: p for p in json.loads((ROOT / 'data/prompts.json').read_text())}
    assert hashlib.sha256((ROOT / 'data/prompts.json').read_bytes()).hexdigest() == plan['fixture_sha256']
    assert hashlib.sha256((ROOT / 'run_plan.json').read_bytes()).hexdigest() == scope['plan_sha256']
    assert all(r['model'] in scope['models'] and r['id'] in prompts for r in rows)
    assert len({r['attempt_id'] for r in rows}) == len(rows)
    recovery_audit = audit_attempts(rows, ROOT)
    for r in rows:
        assert math.isfinite(r['cost_usd']) and r['cost_usd'] >= 0
    assert math.fsum(r['cost_usd'] for r in rows) <= scope['authorized_cap_usd'] + 1e-8
    launched = {e['attempt_id'] for e in read_rows(ROOT / 'runs/events.jsonl') if e['event'] == 'launch'}
    assert launched == {r['attempt_id'] for r in rows}, 'Collector still has unresolved in-flight launches.'
    successful_full = [model for model in scope['models'] if sum(r['model'] == model and r['status'] == 'ok' for r in selected.values()) == 960]
    audit = {'dataset_validation_passed': True, 'accounting_and_retry_audit_passed': True,
             'reference_collection_complete': summary['collection_complete'],
             'complete_reference_configurations': successful_full,
             'selected_configurations': scope['models'], 'planned_slots': scope['planned_slots'],
             'collected_slots': len(selected), 'attempts': len(rows),
             'cost_usd': summary['spent_usd'], 'cap_usd': scope['authorized_cap_usd'],
             'verified_answer_certificates': evidence['verified_certificates'],
             'provider_recovery_audit': recovery_audit,
             'raw_sha256': hashlib.sha256((ROOT / 'runs/results.jsonl').read_bytes()).hexdigest() if rows else None}
    (ROOT / 'results/final_audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    environment = {'python': platform.python_version(), 'packages': {p: importlib.metadata.version(p) for p in ('networkx', 'numpy', 'matplotlib')}}
    (ROOT / 'environment.json').write_text(json.dumps(environment, indent=2) + '\n')
    (ROOT / 'requirements-lock.txt').write_text('\n'.join(f'{p}=={v}' for p, v in environment['packages'].items()) + '\n')
    fig, ax = plt.subplots(figsize=(13, 5.5))
    styles = [('correct', '#16374c', 'Correct'), ('completed_numeric_wrong', '#ca6b3b', 'Completed numeric error'),
              ('invalid_completed', '#ecd0b9', 'Invalid completed'), ('cutoffs', '#b8c1c7', 'Token cutoff'),
              ('provider_or_protocol_errors', '#ffffff', 'Provider / protocol error')]
    names = []
    for i, (model, m) in enumerate(summary['models'].items()):
        names.append(model.split('/')[-1] + ' (' + (m['quantization'] or 'unspecified') + ')')
        left = 0
        for key, color, label in styles:
            ax.barh(i, m[key], left=left, color=color, edgecolor='#777777' if key == 'provider_or_protocol_errors' else 'none',
                    hatch='xx' if key == 'provider_or_protocol_errors' else None, label=label if i == 0 else None)
            left += m[key]
        ax.barh(i, 960 - left, left=left, color='#ffffff', edgecolor='#d9dde0')
        ax.text(970, i, f'${m["cost_usd"]:.2f}', va='center')
    ax.set_yticks(range(len(names)), names)
    ax.invert_yaxis()
    ax.set_xlim(0, 960)
    ax.set_xlabel('Responses: 120 independent graphs x 8 correlated prompt variants')
    ax.spines[['top', 'right']].set_visible(False)
    fig.suptitle('GroundLM Hard v1: affordable endpoint configurations', fontsize=16)
    fig.text(.5, .89, f'{summary["new_slots"]}/{summary["planned_slots"]} slots | ${summary["spent_usd"]:.2f} recorded | collection complete: {summary["collection_complete"]}', ha='center')
    handles, labels = ax.get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower center', ncol=3, frameon=False, bbox_to_anchor=(.5, .02))
    fig.text(.5, .01, 'White space = uncollected. Quantization and endpoint are part of each configuration. Not a 21-model final leaderboard.', ha='center', fontsize=8)
    fig.tight_layout(rect=[0, .17, .95, .86])
    fig.savefig(ROOT / 'results/reference_results.png', dpi=180)
    fig.savefig(ROOT / 'results/reference_results.svg')
    plt.close(fig)
    source_files = sorted(ROOT.glob('*.py'))
    (ROOT / 'source_manifest.json').write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}, indent=2) + '\n')
    files = sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name not in ('run.lock', 'STOP'))
    secret = os.environ.get('OPENROUTER_API_KEY', '').encode()
    assert not secret or all(secret not in p.read_bytes() for p in files), 'Credential found in export.'
    archive = ROOT.parents[1] / 'output/benchmarks/groundlm_hard_v1.zip'
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in files:
            z.write(path, Path('groundlm_hard_v1') / path.relative_to(ROOT))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    print(json.dumps({'bundle': str(archive), **audit}))


if __name__ == '__main__':
    export()
