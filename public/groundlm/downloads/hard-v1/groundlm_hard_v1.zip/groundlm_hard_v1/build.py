"""Freeze fresh release fixtures before model collection; never overwrite them."""
import datetime
import hashlib
import json
from pathlib import Path
from core import VERSION, TASKS, VARIANTS, SYSTEM, make_case, independent_answer, spec_for, render

ROOT = Path(__file__).resolve().parent


def build():
    target = ROOT / 'data'
    if (target / 'manifest.json').exists():
        raise SystemExit('Release already frozen. Validate it; do not regenerate over it.')
    target.mkdir(exist_ok=True)
    cases, prompts = [], []
    for task in TASKS:
        for n in (32, 64):
            for replicate in range(10):
                case = make_case(task, n, replicate)
                assert independent_answer(case) == case['answer']
                cases.append(case)
                for variant in VARIANTS:
                    spec = spec_for(case, variant)
                    prompts.append({'id': case['id'] + '-' + variant, 'case_id': case['id'],
                                    'task': task, 'n': n, 'replicate': replicate, 'variant': variant,
                                    'ground_truth': case['answer'], 'spec': spec, 'prompt': render(case, spec)})
    for name, data in [('cases.json', cases), ('prompts.json', prompts)]:
        (target / name).write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    manifest = {'version': VERSION, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'system_prompt': SYSTEM, 'tasks': TASKS, 'variants': VARIANTS,
                'cases': len(cases), 'prompts_per_model': len(prompts), 'sizes': [32, 64],
                'independent_graphs_per_task_size': 10, 'pilot_results_reused': False,
                'selection': 'Fixed hash-derived seeds, no model-dependent rejection or selection.',
                'reachability_label_balance': {'per_size': {'0': 5, '1': 5}},
                'semantic_definition': 'Degree-aligned/reversed names, not task-role-congruent names.',
                'distractor_definition': 'A disjoint three-node path: query-equivalent, not graph-isomorphic.',
                'sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in target.glob('*.json')}}
    (target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'cases': len(cases), 'prompts_per_model': len(prompts), 'ground_truth_checks': 'passed'}))


if __name__ == '__main__':
    build()
