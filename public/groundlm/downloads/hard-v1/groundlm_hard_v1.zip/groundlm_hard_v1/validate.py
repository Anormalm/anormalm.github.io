"""Check actual serialized graphs and query answers, not only generator metadata."""
import collections
import hashlib
import json
import re
from pathlib import Path
import networkx as nx
from core import TASKS, VARIANTS, SYSTEM, graph_of, oracle, independent_answer, render

ROOT = Path(__file__).resolve().parent


def decode_prompt(prompt):
    text, question = prompt.split('\n\nQuestion: ', 1)
    if text.startswith('This JSON'):
        data = json.loads(text.split('\n', 1)[1])
        nodes = data['nodes']
        edges = [(e['u'], e['v'], e.get('weight', 1)) for e in data['edges']]
    else:
        nodes_text, edge_text = text.split('The complete node set is:\n')[1].split('\nThe complete edge list is:\n')
        nodes = nodes_text.split(', ')
        edges = []
        for line in edge_text.splitlines():
            match = re.fullmatch(r'(\S+) -- (\S+)(?: \[weight=(\d+)\])?', line)
            assert match, line
            a, b, w = match.groups()
            edges.append((a, b, int(w or 1)))
    assert len(set(nodes)) == len(nodes)
    g = nx.Graph()
    g.add_nodes_from(nodes)
    for a, b, w in edges:
        assert a in g and b in g and a != b and not g.has_edge(a, b) and type(w) is int and w > 0
        g.add_edge(a, b, weight=w)
    return g, question


def validate():
    manifest = json.loads((ROOT / 'data/manifest.json').read_text())
    for name, digest in manifest['sha256'].items():
        assert hashlib.sha256((ROOT / 'data' / name).read_bytes()).hexdigest() == digest
    cases = json.loads((ROOT / 'data/cases.json').read_text())
    prompts = json.loads((ROOT / 'data/prompts.json').read_text())
    assert len(cases) == 120 and len(prompts) == 960
    assert len({c['id'] for c in cases}) == len({c['seed'] for c in cases}) == 120
    assert len({p['id'] for p in prompts}) == 960
    assert collections.Counter((c['task'], c['n']) for c in cases) == collections.Counter({(t, n): 10 for t in TASKS for n in (32, 64)})
    case_map = {c['id']: c for c in cases}
    groups = collections.defaultdict(dict)
    for case in cases:
        assert independent_answer(case) == case['answer']
    for p in prompts:
        c, spec = case_map[p['case_id']], p['spec']
        assert p['prompt'] == render(c, spec)
        g, question = decode_prompt(p['prompt'])
        labels = spec['node_index_to_identifier']
        assert len(set(labels)) == c['n']
        inverse = {label: i for i, label in enumerate(labels)}
        h = nx.relabel_nodes(g.subgraph(labels), inverse)
        expected = graph_of(c)
        assert set(h) == set(expected)
        assert {frozenset(e) for e in h.edges()} == {frozenset(e) for e in expected.edges()}
        weighted = c['task'] in ('weighted_shortest_path', 'minimum_cut')
        assert all(h[a][b]['weight'] == (d['weight'] if weighted else 1) for a, b, d in expected.edges(data=True))
        if p['variant'] == 'distractor':
            assert set(g) - set(labels) == {'D000', 'D001', 'D002'}
            assert not any((a in labels) != (b in labels) for a, b in g.edges())
            assert g.subgraph({'D000', 'D001', 'D002'}).number_of_edges() == 2
        else:
            assert set(g) == set(labels)
        if c['task'] == 'weighted_shortest_path':
            s, t = re.search(r'a path from (\S+) to (\S+)\?', question).groups()
        elif c['task'] == 'minimum_cut':
            s, t = re.search(r'disconnects (\S+) from (\S+)\?', question).groups()
        elif c['task'] in ('exact_walk_count', 'shortest_path_count'):
            s, t = re.search(r'lead from (\S+) to (\S+)\?', question).groups()
        elif c['task'] == 'constrained_reachability':
            s, t = re.search(r'a path from (\S+) to (\S+) afterward', question).groups()
        else:
            s, t = spec['source'], spec['target']
        assert (s, t) == (labels[c['source']], labels[c['target']])
        blocked = re.search(r'Remove these vertices and all their incident edges: (.*?)\.', question).group(1).split(', ') if c['task'] == 'constrained_reachability' else []
        length = int(re.search(r'exactly (\d+) edges', question).group(1)) if c['task'] == 'exact_walk_count' else c['walk_length']
        assert blocked == spec['blocked']
        assert oracle(g, c['task'], s, t, blocked, length) == c['answer'] == p['ground_truth']
        groups[c['id']][p['variant']] = p
    for group in groups.values():
        assert set(group) == set(VARIANTS)
        assert group['original']['prompt'] == group['repeat']['prompt']
        assert group['original']['prompt'] != group['order_shuffled']['prompt']
    for n in (32, 64):
        assert collections.Counter(c['answer'] for c in cases if c['task'] == 'constrained_reachability' and c['n'] == n) == {0: 5, 1: 5}
    old = ROOT.parents[1] / 'experiments/hard_graph_v1'
    old_cases = []
    for path in [old / 'replication/cases.json', old / 'data/development_cases.json', old / 'data/holdout_cases.json', old / 'optimization/cases.json']:
        if path.exists():
            old_cases += json.loads(path.read_text())
    fingerprints = {(c['task'], c['n'], json.dumps(c['edges'])) for c in old_cases}
    assert all((c['task'], c['n'], json.dumps(c['edges'])) not in fingerprints for c in cases)
    result = {'passed': True, 'independent_cases': 120, 'serialized_prompts': 960,
              'oracle_cross_checks': 120, 'serialized_answer_checks': 960, 'unchanged_input_controls': 120,
              'prior_cases_checked_for_exact_overlap': len(old_cases),
              'reachability_labels_per_size': {'0': 5, '1': 5},
              'manifest_sha256': hashlib.sha256((ROOT / 'data/manifest.json').read_bytes()).hexdigest()}
    (ROOT / 'validation.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    validate()
