"""Paired graph-case summaries and graph-level bootstrap uncertainty."""
import json
from pathlib import Path
import numpy as np
from math import sqrt
from analyze import analyze

ROOT=Path(__file__).parent
RUN=ROOT/'runs/replication01'
CONDITIONS=['neutral_relabel','semantic_congruent','semantic_incongruent']

def estimate(values, proportion=True):
    v=np.array(values,dtype=float);v=v[np.isfinite(v)]
    if not len(v):return {'value':None,'n':0,'ci95':None}
    # Each entry is one independent graph query, not one naming variant.
    samples=np.random.default_rng(20261102).choice(v,size=(5000,len(v)),replace=True).mean(axis=1)
    boot=[float(x) for x in np.quantile(samples,[.025,.975])] if len(v)>1 else None
    mean=float(v.mean());ci=boot
    if proportion:
        z=1.959963984540054;n=len(v);denom=1+z*z/n
        center=(mean+z*z/(2*n))/denom;half=z*sqrt(mean*(1-mean)/n+z*z/(4*n*n))/denom
        ci=[max(0,center-half),min(1,center+half)]
    return {'value':mean,'n':len(v),'ci95':ci,'ci_method':'Wilson' if proportion else 'graph-case percentile bootstrap','bootstrap_ci95':boot}

def build():
    scored=analyze(RUN);rows=json.loads((RUN/'answer_scored_results.json').read_text())
    manifest=json.loads((ROOT/'replication/manifest.json').read_text())
    report={'planned_cases':manifest['cases'],'planned_requests':manifest['prompts']*2,'responses':len(rows),
            'cost_usd':sum(r['cost_usd'] for r in rows),'models':{}}
    for model in dict.fromkeys(r['model'] for r in rows):
        rr=[r for r in rows if r['model']==model];groups={}
        for row in rr:groups.setdefault(row['case_id'],{})[row['condition']]=row
        result={'responses':len(rr),'cases_seen':len(groups),'cost_usd':sum(r['cost_usd'] for r in rr),
                'correct':sum(r.get('correct',False) for r in rr),'truncated':sum(r.get('finish_reason')=='length' for r in rr),
                'errors':sum(r['status']!='ok' for r in rr),'completed_wrong':[], 'conditions':{},'tasks':{}}
        originals=[g['original'] for g in groups.values() if 'original' in g and g['original']['status']=='ok']
        result['original_accuracy']=estimate([int(r['correct']) for r in originals])
        for task in ['weighted_shortest_path','triangle_count','minimum_cut']:
            subset=[r for r in rr if r['task']==task and r['status']=='ok']
            result['tasks'][task]={'correct':sum(r['correct'] for r in subset),'n':len(subset),'cutoffs':sum(r['finish_reason']=='length' for r in subset)}
        for c in CONDITIONS:
            consistency=[];survival=[];paired_gap=[];flips=[]
            for cid,g in groups.items():
                b=g.get('original');r=g.get(c);neutral=g.get('neutral_relabel')
                if not b or not r or b['status']!='ok' or r['status']!='ok':continue
                if b['correct']:
                    survival.append(int(r['correct']))
                    if not r['correct']:flips.append({'case_id':cid,'expected':b['ground_truth'],'answer':r['parsed_answer'],'finish_reason':r['finish_reason']})
                if b['parsed_answer'] is not None and r['parsed_answer'] is not None:
                    agree=int(b['parsed_answer']==r['parsed_answer']);consistency.append(agree)
                    if neutral and neutral['status']=='ok' and neutral['parsed_answer'] is not None:
                        paired_gap.append(int(b['parsed_answer']==neutral['parsed_answer'])-agree)
            result['conditions'][c]={'consistency':estimate(consistency),'conditional_survival':estimate(survival),
                                     'paired_neutral_minus_condition_consistency':estimate(paired_gap,proportion=False),'correct_to_wrong':flips}
        for r in rr:
            if r['status']=='ok' and r['finish_reason']!='length' and r['parsed_answer'] is not None and not r['correct']:
                result['completed_wrong'].append({k:r[k] for k in ['case_id','task','n','condition','ground_truth','parsed_answer']})
        report['models'][model]=result
    all_cost=sum(json.loads(line)['cost_usd'] for f in (ROOT/'runs').glob('*/results.jsonl') for line in f.read_text().splitlines())
    report['cumulative_cost_usd']=all_cost;report['remaining_under_20_usd']=20-all_cost
    (RUN/'paired_summary.json').write_text(json.dumps(report,indent=2))
    def fmt(s):
        if s['value'] is None:return 'undefined'
        value=f'{s["value"]:.1%}'
        if s['ci95']:value+=f' [{s["ci95"][0]:.1%}, {s["ci95"][1]:.1%}]'
        return value+f' (n={s["n"]})'
    lines=['# Independent graph replication','',f'{len(rows)} / {report["planned_requests"]} responses. This round: US${report["cost_usd"]:.4f}; cumulative: US${all_cost:.4f}.','',
           '24 fixed independent graph cases; 32/64 nodes; four naming variants; high reasoning effort requested and 8,192 output tokens. Task selection follows the earlier calibration; results generalize only to this sampled task/generator distribution.','',
           'Proportions show descriptive Wilson 95% intervals over independent graph questions; paired differences show 5,000-resample graph-case percentile bootstrap intervals. The planned bootstrap intervals for proportions are also retained in paired_summary.json. One model sample per prompt; repeated model-sampling variability is not measured. Consistency excludes unparseable pairs; accuracy and conditional survival count unparseable answers as failures.','']
    for model,m in report['models'].items():
        lines += ['## '+model,'',f'Original accuracy: **{fmt(m["original_accuracy"])}**. Overall: {m["correct"]}/{m["responses"]}; {m["truncated"]} token cutoffs; {len(m["completed_wrong"])} completed numeric wrong answers; {m["errors"]} API errors.','',
                  '| Task | Correct / responses | Token cutoffs |','| --- | ---: | ---: |']
        for task,s in m['tasks'].items():lines.append(f'| {task} | {s["correct"]}/{s["n"]} | {s["cutoffs"]} |')
        lines += ['', '| Renaming | Consistency, 95% CI | Conditional survival, 95% CI |','| --- | --- | --- |']
        for c,s in m['conditions'].items():lines.append(f'| {c} | {fmt(s["consistency"])} | {fmt(s["conditional_survival"])} |')
        lines += ['','Neutral-minus-semantic consistency on the same complete graph pairs:','']
        for c in CONDITIONS[1:]:lines.append(f'- {c}: {fmt(m["conditions"][c]["paired_neutral_minus_condition_consistency"])}.')
        lines += ['', 'Every completed numeric wrong answer:','']
        for r in m['completed_wrong']:lines.append(f'- `{r["case_id"]}` / {r["condition"]}: expected {r["ground_truth"]}, returned {r["parsed_answer"]}.')
    lines += ['','A naming effect can include generic model sampling variability, tokenization or length effects. Degree-aligned names are not guaranteed task-congruent names. A semantic-specific claim requires a reproducible excess over the neutral renaming control. Full raw responses and parse/finish status are retained.']
    (ROOT/'REPLICATION_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'responses':len(rows),'round_cost':report['cost_usd'],'cumulative_cost':all_cost,'models':{k:{'correct':v['correct'],'responses':v['responses'],'cutoffs':v['truncated'],'completed_wrong':len(v['completed_wrong'])} for k,v in report['models'].items()}}))
    return report

if __name__=='__main__':build()
