# Harder graph reasoning pilot

## Independent replication

The continuation fixes 24 new independent cases before inference (four seeds
per task/size, three tasks, 32/64 nodes), and tests every naming variant with
both models. The replication allows 8,192 output tokens and requests high
reasoning effort. Its US$10 round cap and US$20 cumulative cap include earlier
saved runs. `REPLICATION_REPORT.md` contains graph-case analysis; the fixed plan,
hashes and independent answer checks are in `replication/`.

```powershell
python experiments/hard_graph_v1/run_pilot.py --budget-usd 10 --total-cap-usd 20 --split replication --fixture experiments/hard_graph_v1/replication/prompts.json --sizes 32 64 --max-tokens 8192 --reasoning-effort high --workers 4 --output experiments/hard_graph_v1/runs/replication01
python experiments/hard_graph_v1/replication_evidence.py
```

An additional unchanged-input control repeats all eight triangle prompts once
per model, with a US$2 round cap under the same cumulative cap. It assesses
sampling variation without a renaming intervention. See `REPEAT_CONTROL_REPORT.md`.
New collection uses the explicit terminal JSON answer directly and retains strict
format compliance separately; earlier raw ledgers keep their original strict
scores. Re-scoring all runs with `analyze.py` produces a common answer definition.

The separate exploratory optimization extension fixes four fresh minimum vertex
cover questions (24/32 nodes), with all four naming variants. Opus alone is
tested with high reasoning effort and 8,192 output tokens, under a US$3.40 cap
and the same cumulative US$20 cap. Exact answers agree between a zero-gap integer
program and exhaustive clique enumeration on the complement graph. These four
cases are difficulty exploration, not a held-out generalization estimate.

Read `REPORT.md` for the completed experiments and `failure_examples.json` for
full prompts and recorded completed errors. Plots are saved in each run folder.

After development calibration, `holdout01` tests 96-node weighted paths, triangle
counts and minimum cuts (24 calls). `holdout32` tests 32-node triangle counts and
minimum cuts (16 calls). Both request high reasoning effort and 4,096 output
tokens. These holdout tasks were selected after observing development outcomes;
they validate selected tasks, not an unbiased overall score for all six tasks.

This extends the small-graph GroundLM audit with 32/64/96/128-node cases and six
integer-answer tasks: weighted shortest distance, number of shortest paths,
number of fixed-length walks, total triangle count, undirected minimum cut,
and reachability after deleting vertices. This is a new experiment, not a
reproduction of the paper's table.

Each case has four naming conditions: original IDs, shuffled neutral IDs,
degree-aligned semantic names and reverse-degree semantic names. Edges, weights,
node order, query endpoints and ground truth stay matched. Semantic role labels
refer to **degree alignment**, not proven congruence with every task. The system
explicitly tells models that names are arbitrary identifiers.

`benchmark.py` generates separate fixed development and holdout seeds. Each split
has 24 cases and 96 prompts. `data/manifest.json` records hashes. The first pilot
uses development graphs with 32 and 96 nodes: 12 distinct questions per model,
48 calls per model, two Claude models. The untouched sizes and holdout are
available for subsequent validation. Questions within a naming group are
correlated; 96 responses are not 96 independent questions.

```powershell
python experiments/hard_graph_v1/benchmark.py
python -m unittest discover -s experiments/hard_graph_v1 -v
python experiments/hard_graph_v1/run_pilot.py --budget-usd 20
python experiments/hard_graph_v1/analyze.py experiments/hard_graph_v1/runs/pilot01
```

Set `OPENROUTER_API_KEY` in the environment. Never write it into this folder.
The runner uses the live model catalog, logs returned model/provider identities,
request settings and raw answers, persists each response, and sends no ground
truth to the service. It uses two workers, no retries, and stops on API errors.
The spending cap is the lesser of the user cap and available credit less $0.50.
It reserves a conservative byte-based input-token bound and maximum output cost
before launching each request; missing/uncertain usage consumes the reservation.
Do not run separate copies against the same output folder or budget concurrently.

The initial configurations use `anthropic/claude-sonnet-5.5` and
`anthropic/claude-opus-5.5`, low reasoning effort, 2,048 output tokens and provider
default temperature (the catalog does not advertise temperature for these IDs).
These settings describe one inference budget, not model capability in general.

Raw `results.jsonl` preserves the collector's strict JSON-only score. Claude can
give a correct final JSON object after extra explanation. The primary
`answer_scored_summary.json` and `answer_scored_results.json` accept that explicit
terminal JSON object, preserve strict-format compliance separately, and avoid
reading arbitrary numbers from reasoning. Use these answer-focused files for
accuracy and consistency. Truncations, invalid outputs, service errors, completed
wrong answers, and costs are listed separately. A cutoff is not evidence of a
completed reasoning error. No raw observations are overwritten by re-scoring.

Known pilot scope: constrained-reachability items currently all have answer 0;
they are an easy negative control, not a balanced reachability test. Do not use
them to claim general reachability performance. Larger counts and verbose
answers can hit the output budget. A follow-up should use fresh seeds, balanced
reachability labels and a larger output budget before attributing those failures
to reasoning. Development failures guide task selection; selected examples must
not be presented as an unbiased estimate of overall accuracy.

Model availability/prices were checked through the OpenRouter catalog.
References: https://openrouter.ai/docs/api_reference/limits and
https://openrouter.ai/docs/api/api-reference/models/list-all-models-and-their-properties.
