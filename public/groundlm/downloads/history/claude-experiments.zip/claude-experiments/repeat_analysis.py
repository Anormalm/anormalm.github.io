"""Compare unchanged-input repeats with naming changes on the same eight cases."""
import json
from pathlib import Path
from analyze import analyze
from replication_analysis import estimate

ROOT=Path(__file__).parent

def build():
    main=ROOT/'runs/replication01';repeat=ROOT/'runs/repeat_control01'
    analyze(main);analyze(repeat)
    originals=json.loads((main/'answer_scored_results.json').read_text())
    repeated=json.loads((repeat/'answer_scored_results.json').read_text())
    groups={}
    for r in originals+repeated:groups.setdefault((r['model'],r['case_id']),{})[r['condition']]=r
    result={}
    for model in dict.fromkeys(r['model'] for r in repeated):
        comparisons={c:[] for c in ['original_repeat','neutral_relabel','semantic_congruent','semantic_incongruent']}
        correctness={c:[] for c in comparisons};contrasts={c:[] for c in comparisons if c!='original_repeat'}
        for (m,cid),g in groups.items():
            if m!=model or 'original_repeat' not in g or 'original' not in g:continue
            b=g['original'];r=g['original_repeat'];assert b['prompt']==r['prompt']
            if b['status']!='ok' or r['status']!='ok':continue
            for c in comparisons:
                x=g.get(c)
                if not x or x['status']!='ok':continue
                correctness[c].append(int(x['correct']))
                if x['parsed_answer'] is not None and b['parsed_answer'] is not None:
                    comparisons[c].append(int(x['parsed_answer']==b['parsed_answer']))
                # Difference in correctness includes unparseable/cutoff failures.
                if c!='original_repeat':contrasts[c].append(int(r['correct'])-int(x['correct']))
        result[model]={'agreement':{k:estimate(v) for k,v in comparisons.items()},
                       'correctness':{k:estimate(v) for k,v in correctness.items()},
                       'repeat_minus_renamed_correctness':{k:estimate(v,proportion=False) for k,v in contrasts.items()}}
    (repeat/'repeat_comparison.json').write_text(json.dumps(result,indent=2))
    lines=['# Unchanged-input repeat control','',
           'All eight triangle cases were included. Each original neutral-ID prompt was sent once more, with identical settings and no text changes. This is one repeat per graph, not an estimate of full model sampling variability.','',
           '| Model | Input | Correctness | Agreement with first original |','| --- | --- | --- |']
    def fmt(s):return 'undefined' if s['value'] is None else f'{s["value"]:.1%} (n={s["n"]})'
    for m,s in result.items():
        for c in s['agreement']:lines.append(f'| {m} | {c} | {fmt(s["correctness"][c])} | {fmt(s["agreement"][c])} |')
    lines += ['','Correctness includes missing final answers as wrong; agreement excludes unparseable pairs. Denominators can differ. Full paired interval summaries are in repeat_comparison.json. Changing answers after renaming must be compared with this unchanged-input variability before attributing the changes to names.']
    (ROOT/'REPEAT_CONTROL_REPORT.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({m:{k:fmt(v) for k,v in s['correctness'].items()} for m,s in result.items()}))

if __name__=='__main__':build()
