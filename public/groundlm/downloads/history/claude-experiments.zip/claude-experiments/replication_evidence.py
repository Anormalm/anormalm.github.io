"""Save numerical witnesses for every completed numeric error in replication."""
import itertools
import json
from pathlib import Path
import networkx as nx
from replication_analysis import build, ROOT, RUN

def evidence():
    build();rows=json.loads((RUN/'answer_scored_results.json').read_text())
    cases={c['id']:c for c in json.loads((ROOT/'replication/cases.json').read_text())}
    out=RUN/'evidence';out.mkdir(exist_ok=True);index=[];seen=set()
    for r in rows:
        if r['status']!='ok' or r['finish_reason']=='length' or r['parsed_answer'] is None or r['correct']:continue
        case=cases[r['case_id']];g=nx.Graph();g.add_nodes_from(range(case['n']));g.add_weighted_edges_from(case['edges'])
        labels=r['prompt'].split('complete node set is:\n')[1].split('\nThe complete edge list')[0].split(', ')
        item={k:r[k] for k in ['id','case_id','model','task','condition','ground_truth','parsed_answer','model_answer','prompt','provider','finish_reason']}
        item['node_index_to_prompt_identifier']=labels
        index.append({'id':r['id'],'model':r['model'],'condition':r['condition'],'expected':r['ground_truth'],'returned':r['parsed_answer'],'witness':case['id']+'.json'})
        name=r['model'].split('/')[-1]+'__'+r['id']+'.json'
        (out/name).write_text(json.dumps(item,indent=2),encoding='utf-8')
        if case['id'] in seen:continue
        seen.add(case['id']);s,t=case['source'],case['target'];proof={'case_id':case['id'],'task':case['task'],'answer':case['answer'],'nodes':case['n'],'edges':case['edges']}
        if case['task']=='triangle_count':
            triples=[list(v) for v in itertools.combinations(g,3) if all(g.has_edge(a,b) for a,b in itertools.combinations(v,2))]
            assert len(triples)==case['answer'];proof['triangles']=triples
        elif case['task']=='weighted_shortest_path':
            distances,paths=nx.single_source_dijkstra(g,s,weight='weight');path=paths[t]
            assert distances[t]==case['answer']
            assert all(abs(distances[a]-distances[b])<=w['weight'] for a,b,w in g.edges(data=True))
            assert sum(g[a][b]['weight'] for a,b in zip(path,path[1:]))==case['answer']
            proof.update(source=s,target=t,path=path,distances=distances)
        else:
            value,(left,right)=nx.minimum_cut(g,s,t,capacity='weight')
            cut=[[a,b,d['weight']] for a,b,d in g.edges(data=True) if (a in left)!=(b in left)]
            flow_value,flow=nx.maximum_flow(g,s,t,capacity='weight',flow_func=nx.algorithms.flow.edmonds_karp)
            assert sum(w for a,b,w in cut)==flow_value==value==case['answer']
            for a in g:
                for b in g.neighbors(a):assert 0<=flow[a][b]<=g[a][b]['weight']
                net=sum(flow[a].values())-sum(flow[b].get(a,0) for b in g)
                assert net==(value if a==s else -value if a==t else 0)
            proof.update(source=s,target=t,source_side=sorted(left),target_side=sorted(right),cut_edges=cut,flow=flow)
        (out/(case['id']+'.json')).write_text(json.dumps(proof,indent=2))
    (out/'index.json').write_text(json.dumps(index,indent=2))
    print(f'Saved {len(index)} completed-error responses with independently checkable witnesses for {len(seen)} cases.')

if __name__=='__main__':evidence()
