# Continuation results

224 additional real OpenRouter requests are complete; 360 cumulative requests.
Recorded inference cost is **US$16.7435**, with **US$3.2565** left under the approved US$20 cap.

## Independent graph replication

24 new graph questions, four fixed independent seeds per task/size cell, 32/64
nodes, four naming variants, both Claude 5.5 models. High reasoning effort was
requested; the maximum output allowance was 8,192 tokens.

| Model | Correct / responses | Completed numeric wrong answers | Token cutoffs |
| --- | ---: | ---: | ---: |
| Sonnet 5.5 | 87/96 | 7 | 2 |
| Opus 5.5 | 91/96 | 0 | 5 |

Both models answered all 24 original-name questions correctly. Every failure
arose after renaming; this alone does not establish a semantic cause.

## Unchanged-input control

On all eight triangle graphs, both models answered the unchanged original prompt
correctly again (8/8 each). On the same cases:

| Naming condition | Sonnet correct | Opus correct |
| --- | ---: | ---: |
| Unchanged repeat | 8/8 | 8/8 |
| Neutral renaming | 7/8 | 8/8 |
| Degree-aligned semantic names | 3/8 | 5/8 |
| Reverse-degree semantic names | 5/8 | 6/8 |

The failed Opus responses here were cutoffs; Sonnet also gave completed wrong
counts. For example, two new 32-node graphs had 27 and 26 triangles, and Sonnet
returned 26 and 25 under degree-aligned names. Every completed numerical error
has a saved prompt, raw response and independently checkable triangle list.

## Exploratory optimization extension

Four fresh minimum-vertex-cover cases at 24/32 nodes, four names each, Opus 5.5
only: **10/16 correct, 6 token cutoffs, 0 completed numeric errors**. All four
original questions were correct. Optima were cross-checked by zero-gap integer
programming and exhaustive complement-graph clique enumeration.

## Interpretation and next experiment

The supported finding is that renaming can change Sonnet's completed counts and
can exhaust the tested output budget for Opus, despite correct original answers
and an explicit instruction that names are arbitrary. This continuation found
no completed numeric errors for Opus; it does not support claiming that Opus's
finished answers were wrong under this configuration.

The repeated original inputs provide a small sampling control, not a full
estimate of sampling variability. Semantic names also change tokenization and
length. A next study should match those properties and repeat every condition;
it should preserve all sampled graphs and distinguish wrong answers from cutoffs.
The optimization extension is exploratory and must not be pooled into an unbiased
leaderboard. Task/size replication cells contain only four graph seeds.

## Files

- [Paired replication analysis](REPLICATION_REPORT.md), with case-level uncertainty.
- [Unchanged-prompt control](REPEAT_CONTROL_REPORT.md).
- [Optimization results](OPTIMIZATION_REPORT.md), including every case/condition.
- [Control chart](runs/repeat_control01/naming_control.png).
- [Completed-error evidence](runs/replication01/evidence/index.json).
- [Spending and raw-file hashes](spending_ledger.json).
- [Full chronological run summaries](REPORT.md).

The original paper, poster and deployed website were not edited during these runs.
