# Independent graph replication

192 / 192 responses. This round: US$9.1129; cumulative: US$16.7435.

24 fixed independent graph cases; 32/64 nodes; four naming variants; high reasoning effort requested and 8,192 output tokens. Task selection follows the earlier calibration; results generalize only to this sampled task/generator distribution.

Proportions show descriptive Wilson 95% intervals over independent graph questions; paired differences show 5,000-resample graph-case percentile bootstrap intervals. The planned bootstrap intervals for proportions are also retained in paired_summary.json. One model sample per prompt; repeated model-sampling variability is not measured. Consistency excludes unparseable pairs; accuracy and conditional survival count unparseable answers as failures.

## anthropic/claude-sonnet-5.5

Original accuracy: **100.0% [86.2%, 100.0%] (n=24)**. Overall: 87/96; 2 token cutoffs; 7 completed numeric wrong answers; 0 API errors.

| Task | Correct / responses | Token cutoffs |
| --- | ---: | ---: |
| weighted_shortest_path | 32/32 | 0 |
| triangle_count | 23/32 | 2 |
| minimum_cut | 32/32 | 0 |

| Renaming | Consistency, 95% CI | Conditional survival, 95% CI |
| --- | --- | --- |
| neutral_relabel | 95.8% [79.8%, 99.3%] (n=24) | 95.8% [79.8%, 99.3%] (n=24) |
| semantic_congruent | 86.4% [66.7%, 95.3%] (n=22) | 79.2% [59.5%, 90.8%] (n=24) |
| semantic_incongruent | 87.5% [69.0%, 95.7%] (n=24) | 87.5% [69.0%, 95.7%] (n=24) |

Neutral-minus-semantic consistency on the same complete graph pairs:

- semantic_congruent: 9.1% [0.0%, 22.7%] (n=22).
- semantic_incongruent: 8.3% [0.0%, 20.8%] (n=24).

Every completed numeric wrong answer:

- `replication-n32-triangle_count-r2` / semantic_congruent: expected 27, returned 26.
- `replication-n32-triangle_count-r3` / semantic_congruent: expected 26, returned 25.
- `replication-n64-triangle_count-r0` / semantic_incongruent: expected 33, returned 32.
- `replication-n64-triangle_count-r1` / semantic_incongruent: expected 31, returned 30.
- `replication-n64-triangle_count-r3` / semantic_congruent: expected 48, returned 51.
- `replication-n64-triangle_count-r3` / neutral_relabel: expected 48, returned 47.
- `replication-n64-triangle_count-r3` / semantic_incongruent: expected 48, returned 49.
## anthropic/claude-opus-5.5

Original accuracy: **100.0% [86.2%, 100.0%] (n=24)**. Overall: 91/96; 5 token cutoffs; 0 completed numeric wrong answers; 0 API errors.

| Task | Correct / responses | Token cutoffs |
| --- | ---: | ---: |
| weighted_shortest_path | 32/32 | 0 |
| triangle_count | 27/32 | 5 |
| minimum_cut | 32/32 | 0 |

| Renaming | Consistency, 95% CI | Conditional survival, 95% CI |
| --- | --- | --- |
| neutral_relabel | 100.0% [86.2%, 100.0%] (n=24) | 100.0% [86.2%, 100.0%] (n=24) |
| semantic_congruent | 100.0% [84.5%, 100.0%] (n=21) | 87.5% [69.0%, 95.7%] (n=24) |
| semantic_incongruent | 100.0% [85.1%, 100.0%] (n=22) | 91.7% [74.2%, 97.7%] (n=24) |

Neutral-minus-semantic consistency on the same complete graph pairs:

- semantic_congruent: 0.0% [0.0%, 0.0%] (n=21).
- semantic_incongruent: 0.0% [0.0%, 0.0%] (n=22).

Every completed numeric wrong answer:


A naming effect can include generic model sampling variability, tokenization or length effects. Degree-aligned names are not guaranteed task-congruent names. A semantic-specific claim requires a reproducible excess over the neutral renaming control. Full raw responses and parse/finish status are retained.
