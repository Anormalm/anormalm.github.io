"""Static, exportable figures from answer-focused saved pilot records."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from benchmark import TASKS
from analyze import analyze

ROOT=Path(__file__).parent
for folder in sorted((ROOT/'runs').iterdir()):
    if not (folder/'results.jsonl').exists():continue
    analyze(folder)
    rows=json.loads((folder/'answer_scored_results.json').read_text())
    models=list(dict.fromkeys(r['model'] for r in rows))
    fig,axes=plt.subplots(1,len(models),figsize=(13,5),sharey=True,squeeze=False)
    for ax,model in zip(axes[0],models):
        subset=[r for r in rows if r['model']==model]
        ordered=list(TASKS)+sorted({r['task'] for r in subset}-set(TASKS))
        tasks=[t for t in ordered if any(r['task']==t for r in subset)]
        totals=[];correct=[];wrong=[];cut=[]
        for task in tasks:
            rr=[r for r in subset if r['task']==task]
            n=len(rr);a=sum(r.get('correct',False) for r in rr);c=sum(r.get('finish_reason')=='length' for r in rr)
            totals.append(n);correct.append(a);cut.append(c);wrong.append(n-a-c)
        ys=list(range(len(tasks)))
        ax.barh(ys,correct,color='#123348',label='Correct')
        ax.barh(ys,wrong,left=correct,color='#c36537',label='Completed wrong / invalid')
        ax.barh(ys,cut,left=[a+b for a,b in zip(correct,wrong)],color='#bbc2c7',label='Token cutoff')
        for y,n in zip(ys,totals):ax.text(n+.08,y,str(n),va='center',fontsize=10)
        ax.set_yticks(ys,[t.replace('_',' ') for t in tasks]);ax.set_title(model.split('/')[-1]);ax.set_xlabel('Responses (correlated naming variants)')
        ax.set_xlim(0,max(totals)+.8);ax.spines[['top','right']].set_visible(False)
    axes[0,0].invert_yaxis();handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',ncol=3,frameon=False)
    fig.suptitle(f'Hard graph pilot: {folder.name} | final-answer scoring',fontsize=16)
    fig.tight_layout(rect=(0,.08,1,.94))
    fig.savefig(folder/'task_results.png',dpi=180);fig.savefig(folder/'task_results.svg');plt.close(fig)
    print(folder/'task_results.png')
