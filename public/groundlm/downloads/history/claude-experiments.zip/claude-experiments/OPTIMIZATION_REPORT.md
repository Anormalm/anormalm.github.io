# Exploratory minimum-vertex-cover extension

Four fresh exact optimization questions, each with four naming variants. Opus 5.5 only, high reasoning effort requested, 8,192 output tokens, no tools. This task was chosen after observing easier-task performance; it is exploratory difficulty development.

Each ground truth was cross-checked by a zero-gap integer program and exhaustive maximal-clique enumeration of the complement graph. Feasible minimum covers and solver bounds are retained in optimization/cases.json.

16/16 responses; recorded cost US$2.1632.

| Case | Exact answer | Original | Neutral rename | Degree-aligned | Reverse-degree |
| --- | ---: | --- | --- | --- | --- |
| optimization-n24-vertex_cover-r0 | 16 | 16 (correct) | 16 (correct) | 16 (correct) | cutoff |
| optimization-n24-vertex_cover-r1 | 16 | 16 (correct) | cutoff | 16 (correct) | cutoff |
| optimization-n32-vertex_cover-r0 | 20 | 20 (correct) | 20 (correct) | 20 (correct) | cutoff |
| optimization-n32-vertex_cover-r1 | 21 | 21 (correct) | cutoff | 21 (correct) | cutoff |

anthropic/claude-opus-5.5: 10/16 correct; 6 cutoffs; 0 completed numeric errors.

Cutoffs indicate failure within the tested inference budget, not a completed wrong calculation. An exact optimum can require substantial search. These results must not be pooled with the earlier task accuracy as a single unbiased leaderboard.
