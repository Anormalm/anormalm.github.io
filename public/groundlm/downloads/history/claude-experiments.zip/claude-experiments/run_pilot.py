"""Run a resumable, cost-bounded OpenRouter pilot; credentials stay in environment."""
import argparse
import concurrent.futures
import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path
from benchmark import SYSTEM, VERSION

BASE='https://openrouter.ai/api/v1'
def api(path, key, body=None, timeout=180):
    req=urllib.request.Request(BASE+path, data=None if body is None else json.dumps(body).encode(),
        headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'})
    with urllib.request.urlopen(req, timeout=timeout) as response: return json.load(response)

def parse(text):
    if not isinstance(text,str): return None
    text=re.sub(r'^```(?:json)?\s*|\s*```$', '', text.strip())
    try: obj=json.loads(text)
    except (ValueError,TypeError): return None
    value=obj.get('answer') if isinstance(obj,dict) else None
    return value if type(value) is int and value>=0 else None

def final_answer(text):
    direct=parse(text)
    if direct is not None:return direct
    match=re.search(r'(\{\s*"answer"\s*:\s*\d+\s*\})\s*(?:```)?\s*$',text or '')
    return parse(match.group(1)) if match else None

def summary(rows):
    groups={}; by_model={}
    for row in rows:
        model=row['model']; m=by_model.setdefault(model,{'requests':0,'errors':0,'invalid':0,'truncated':0,'correct':0,'cost_usd':0,'conditions':{},'tasks':{}})
        m['requests']+=1;m['cost_usd']+=row.get('cost_usd',0)
        if row['status']!='ok': m['errors']+=1;continue
        m['invalid']+=int(row['parsed_answer'] is None);m['truncated']+=int(row['finish_reason']=='length');m['correct']+=int(row['correct'])
        for field,key in [('conditions','condition'),('tasks','task')]:
            stat=m[field].setdefault(row[key],{'correct':0,'n':0});stat['n']+=1;stat['correct']+=int(row['correct'])
        groups.setdefault((model,row['case_id']),{})[row['condition']]=row
    for model,m in by_model.items():
        pairs={'neutral':[],'semantic_congruent':[],'semantic_incongruent':[]};survival=[];flips=[]
        for (which,cid),group in groups.items():
            if which!=model: continue
            b=group.get('original');s=group.get('semantic_incongruent')
            if not b: continue
            for condition,label in [('neutral_relabel','neutral'),('semantic_congruent','semantic_congruent'),('semantic_incongruent','semantic_incongruent')]:
                r=group.get(condition)
                if r and b['parsed_answer'] is not None and r['parsed_answer'] is not None:
                    pairs[label].append(int(b['parsed_answer']==r['parsed_answer']))
            if s and b['correct']:
                survival.append(int(s['correct']))
                if not s['correct']:flips.append(cid)
        m['consistency']={k:{'value':sum(v)/len(v) if v else None,'n':len(v)} for k,v in pairs.items()}
        m['conditional_survival']={'value':sum(survival)/len(survival) if survival else None,'n':len(survival)}
        m['correct_to_wrong_cases']=flips
    return by_model

def main():
    p=argparse.ArgumentParser();p.add_argument('--budget-usd',required=True,type=float)
    p.add_argument('--models',nargs='+',default=['anthropic/claude-sonnet-5.5','anthropic/claude-opus-5.5'])
    p.add_argument('--sizes',nargs='+',type=int,default=[32,96]);p.add_argument('--split',choices=['development','holdout','replication'],default='development')
    p.add_argument('--fixture',type=Path);p.add_argument('--total-cap-usd',type=float)
    p.add_argument('--tasks',nargs='+');p.add_argument('--conditions',nargs='+')
    p.add_argument('--max-tokens',type=int,default=2048);p.add_argument('--workers',type=int,default=2)
    p.add_argument('--reasoning-effort',choices=['low','medium','high'],default='low')
    p.add_argument('--output',type=Path,default=Path(__file__).parent/'runs/pilot01');args=p.parse_args()
    if args.budget_usd<=0 or not 1<=args.workers<=4: p.error('Positive budget and 1-4 workers required.')
    key=os.environ.get('OPENROUTER_API_KEY');
    if not key: raise SystemExit('OPENROUTER_API_KEY is not set.')
    credit=api('/credits',key)['data'];available=credit['total_credits']-credit['total_usage']
    cap=min(args.budget_usd,max(0,available-.50))
    catalog=api('/models',key)['data'];models={m['id']:m for m in catalog}
    for model in args.models:
        if model not in models:raise SystemExit('Model not in live catalog: '+model)
    fixture=args.fixture or Path(__file__).parent/f'data/{args.split}_prompts.json'
    prompts=[r for r in json.loads(fixture.read_text()) if r['n'] in args.sizes
             and (not args.tasks or r['task'] in args.tasks)
             and (not args.conditions or r['condition'] in args.conditions)]
    if not prompts:raise SystemExit('No matching prompts.')
    args.output.mkdir(parents=True,exist_ok=True)
    identity={'version':VERSION,'models':args.models,'sizes':args.sizes,'split':args.split,'max_tokens':args.max_tokens,'tasks':args.tasks,'conditions':args.conditions,
              'reasoning':{'effort':args.reasoning_effort},'temperature':'omitted (service default)','fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest()}
    configfile=args.output/'config.json'
    if configfile.exists():
        prior=json.loads(configfile.read_text())['identity']
        prior.setdefault('tasks',None);prior.setdefault('conditions',None)
        if prior!=identity:raise SystemExit('Resume configuration mismatch; choose a new output folder.')
    config={'identity':identity,'budget_usd':args.budget_usd,'effective_cap_usd':cap,'available_credit_at_start':available,'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'catalog':[{k:models[m].get(k) for k in ['id','name','pricing','supported_parameters']} for m in args.models]}
    if not configfile.exists():configfile.write_text(json.dumps(config,indent=2))
    ledger=args.output/'results.jsonl';rows=[json.loads(line) for line in ledger.read_text().splitlines()] if ledger.exists() else []
    spent=sum(r['cost_usd'] for r in rows); cap=min(args.budget_usd,spent+cap)
    if args.total_cap_usd is not None:
        prior_cost=sum(json.loads(line)['cost_usd'] for f in (Path(__file__).parent/'runs').glob('*/results.jsonl')
                       if f.resolve()!=ledger.resolve() for line in f.read_text().splitlines())
        cap=min(cap,max(0,args.total_cap_usd-prior_cost))
        (args.output/'budget.json').write_text(json.dumps({'cumulative_cap_usd':args.total_cap_usd,'prior_runs_usd':prior_cost,'this_run_cap_usd':cap},indent=2))
    done={(r['model'],r['id']) for r in rows};work=[(model,r) for model in args.models for r in prompts if (model,r['id']) not in done]
    def reserve(model,r):
        price=models[model]['pricing']
        if price.get('overrides'):raise ValueError('Tiered prices require explicit accounting before running.')
        # UTF-8 byte length is a conservative text-token bound, with message overhead.
        return (len((SYSTEM+r['prompt']).encode())+4096)*float(price['prompt'])+args.max_tokens*float(price['completion'])+float(price.get('request',0))
    def call(model,r,bound):
        started=time.time(); result={**r,'model':model,'reserved_usd':bound}
        try:
            body={'model':model,'messages':[{'role':'system','content':SYSTEM},{'role':'user','content':r['prompt']}],
                  'max_tokens':args.max_tokens,'reasoning':{'effort':args.reasoning_effort},'stream':False}
            response=api('/chat/completions',key,body,timeout=360);choice=response['choices'][0];text=choice['message'].get('content') or ''
            text=text.replace(key,'[REDACTED]');usage=response.get('usage',{});cost=usage.get('cost')
            parsed=final_answer(text)
            result.update(status='ok',response_id=response.get('id'),provider=response.get('provider'),model_returned=response.get('model'),
                          model_answer=text,parsed_answer=parsed,format_compliant=parse(text) is not None,correct=parsed==r['ground_truth'],finish_reason=choice.get('finish_reason'),
                          usage=usage,cost_usd=float(cost) if cost is not None else bound,cost_source='provider' if cost is not None else 'reserved_upper_bound')
        except Exception as exc:
            result.update(status='error',error_type=type(exc).__name__,http_status=getattr(exc,'code',None),cost_usd=bound,cost_source='reserved_uncertain_request')
        result['latency_seconds']=round(time.time()-started,3);return result
    print(json.dumps({'planned_requests':len(work),'effective_budget_usd':round(cap,4),'account_credit_usd':round(available,4)}),flush=True)
    halted=False;index=0;pending={};reserved=0
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        while pending or (index<len(work) and not halted):
            while not halted and len(pending)<args.workers and index<len(work):
                model,r=work[index];bound=reserve(model,r)
                if spent+reserved+bound>cap:
                    if not pending:halted=True
                    break
                index+=1;reserved+=bound;pending[pool.submit(call,model,r,bound)]=bound
            if not pending:break
            finished,_=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
            for future in finished:
                reserved-=pending.pop(future);row=future.result();spent+=row['cost_usd'];rows.append(row)
                with ledger.open('a',encoding='utf-8') as out:out.write(json.dumps(row)+'\n');out.flush();os.fsync(out.fileno())
                print(json.dumps({'completed':len(rows),'model':row['model'],'task':row['task'],'n':row['n'],'condition':row['condition'],
                                  'correct':row.get('correct'),'finish_reason':row.get('finish_reason'),'status':row['status'],'cost_usd':round(spent,5)}),flush=True)
                if row['status']!='ok' or row['cost_usd']>row['reserved_usd'] or spent>cap:halted=True
                report={'completed':len(rows),'planned_total':len(args.models)*len(prompts),'cost_usd':spent,'cap_usd':cap,'models':summary(rows)}
                (args.output/'summary.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'finished':True,'completed':len(rows),'spent_usd':spent,'halted':halted}),flush=True)

if __name__=='__main__':main()
