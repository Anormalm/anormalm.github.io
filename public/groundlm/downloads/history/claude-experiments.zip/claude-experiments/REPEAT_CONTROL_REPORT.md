# Unchanged-input repeat control

All eight triangle cases were included. Each original neutral-ID prompt was sent once more, with identical settings and no text changes. This is one repeat per graph, not an estimate of full model sampling variability.

| Model | Input | Correctness | Agreement with first original |
| --- | --- | --- |
| anthropic/claude-sonnet-5.5 | original_repeat | 100.0% (n=8) | 100.0% (n=8) |
| anthropic/claude-sonnet-5.5 | neutral_relabel | 87.5% (n=8) | 87.5% (n=8) |
| anthropic/claude-sonnet-5.5 | semantic_congruent | 37.5% (n=8) | 50.0% (n=6) |
| anthropic/claude-sonnet-5.5 | semantic_incongruent | 62.5% (n=8) | 62.5% (n=8) |
| anthropic/claude-opus-5.5 | original_repeat | 100.0% (n=8) | 100.0% (n=8) |
| anthropic/claude-opus-5.5 | neutral_relabel | 100.0% (n=8) | 100.0% (n=8) |
| anthropic/claude-opus-5.5 | semantic_congruent | 62.5% (n=8) | 100.0% (n=5) |
| anthropic/claude-opus-5.5 | semantic_incongruent | 75.0% (n=8) | 100.0% (n=6) |

Correctness includes missing final answers as wrong; agreement excludes unparseable pairs. Denominators can differ. Full paired interval summaries are in repeat_comparison.json. Changing answers after renaming must be compared with this unchanged-input variability before attributing the changes to names.
