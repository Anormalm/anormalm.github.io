"""Deterministic harder graph audit; no model calls in this module."""
import argparse
import hashlib
import itertools
import json
import random
from pathlib import Path
import networkx as nx

VERSION = 'hard-graph-v1'
TASKS = ('weighted_shortest_path', 'shortest_path_count', 'exact_walk_count',
         'triangle_count', 'minimum_cut', 'constrained_reachability')
CONDITIONS = ('original', 'neutral_relabel', 'semantic_congruent', 'semantic_incongruent')
SYSTEM = ('You solve graph problems using only the explicitly supplied edges and rules. '
          'All node names are arbitrary identifiers; their meanings give no evidence about edges or roles. '
          'Return only a JSON object with one integer field: {"answer": INTEGER}.')

def answer(g, task, s, t, blocked, length):
    if task == 'weighted_shortest_path':
        return int(nx.shortest_path_length(g, s, t, weight='weight'))
    if task == 'minimum_cut':
        return int(nx.minimum_cut_value(g, s, t, capacity='weight'))
    if task == 'triangle_count':
        return sum(nx.triangles(g).values()) // 3
    if task == 'constrained_reachability':
        h = g.copy(); h.remove_nodes_from(blocked)
        return int(nx.has_path(h, s, t))
    if task == 'exact_walk_count':
        counts = {v: int(v == s) for v in g}
        for _ in range(length):
            counts = {v: sum(counts[u] for u in g.neighbors(v)) for v in g}
        return counts[t]
    distances = nx.single_source_shortest_path_length(g, s)
    counts = dict.fromkeys(g, 0); counts[s] = 1
    for v in sorted(distances, key=distances.get):
        for u in g.neighbors(v):
            if distances.get(u) == distances[v] + 1:
                counts[u] += counts[v]
    return counts[t]

def make_case(n, task, seed):
    rng = random.Random(seed)
    g = nx.gnp_random_graph(n, 6 / n, seed=seed)
    for component in list(nx.connected_components(g))[1:]:
        g.add_edge(0, min(component))
    s, t = 0, n - 1
    if task == 'shortest_path_count':
        # A layered graph makes multiple shortest routes common without listing them.
        g = nx.Graph(); g.add_nodes_from(range(n))
        layers = [[0]] + [list(range(i, min(i + 8, n - 1))) for i in range(1, n - 1, 8)] + [[n - 1]]
        for left, right in zip(layers, layers[1:]):
            for a, b in itertools.product(left, right):
                if rng.random() < .55: g.add_edge(a, b)
            for a in left:
                if not any(g.has_edge(a, b) for b in right): g.add_edge(a, rng.choice(right))
            for b in right:
                if not any(g.has_edge(a, b) for a in left): g.add_edge(rng.choice(left), b)
    blocked = []
    if task == 'constrained_reachability':
        mid = n // 2
        g = nx.disjoint_union(nx.gnp_random_graph(mid, .3, seed=seed), nx.gnp_random_graph(n-mid, .3, seed=seed+1))
        for a in range(n-1):
            if a != mid-1: g.add_edge(a, a+1)
        g.add_edge(mid-1, mid)
        blocked = [mid if seed % 2 else mid + 1]
    for a, b in g.edges: g[a][b]['weight'] = rng.randint(1, 9)
    length = {32:6, 64:8, 96:10, 128:12}.get(n, 4)
    y = answer(g, task, s, t, blocked, length)
    return {'n':n, 'task':task, 'seed':seed, 'edges':[[a,b,g[a][b]['weight']] for a,b in g.edges],
            'source':s, 'target':t, 'blocked':blocked, 'walk_length':length, 'answer':y}

def render(case, condition):
    n = case['n']; rng = random.Random(case['seed']+271)
    g = nx.Graph(); g.add_nodes_from(range(n));g.add_weighted_edges_from(case['edges'])
    labels = [f'X{i:03}' for i in range(n)]
    if condition == 'neutral_relabel': rng.shuffle(labels)
    if condition.startswith('semantic_'):
        ranked = sorted(g, key=lambda v:(-g.degree(v),v))
        if condition == 'semantic_incongruent': ranked.reverse()
        words = ['Hub','Center','Bridge','Core','Junction','Branch','Leaf','Tip']
        for rank, v in enumerate(ranked): labels[v] = words[min(7, rank*8//n)]+f'_{rank:03}'
    weighted = case['task'] in ('weighted_shortest_path','minimum_cut')
    lines = [f'{labels[a]} -- {labels[b]}' + (f' [weight={w}]' if weighted else '') for a,b,w in case['edges']]
    s,t = labels[case['source']],labels[case['target']]
    questions = {
        'weighted_shortest_path':f'What is the minimum sum of edge weights along a path from {s} to {t}?',
        'minimum_cut':f'Edges are undirected and their weights are capacities. What is the minimum total capacity of edges whose removal disconnects {s} from {t}?',
        'shortest_path_count':f'How many distinct shortest paths (minimum number of edges) lead from {s} to {t}? Count paths, not their length.',
        'exact_walk_count':f'How many walks of exactly {case["walk_length"]} edges lead from {s} to {t}? Vertices and edges may repeat; count walks, not simple paths.',
        'triangle_count':'How many distinct triangles are in the whole graph? Count each unordered set of three vertices once.',
        'constrained_reachability':f'Remove these vertices and all their incident edges: {", ".join(labels[v] for v in case["blocked"])}. Is there a path from {s} to {t} afterward? Return 1 for yes, 0 for no.'}
    return ('This is a simple undirected graph. The complete node set is:\n'+', '.join(labels)+
            '\nThe complete edge list is:\n'+'\n'.join(lines)+'\n\nQuestion: '+questions[case['task']]+
            '\nReturn only {"answer": INTEGER}.')

def generate(output):
    output.mkdir(parents=True, exist_ok=True)
    for split, offset in [('development',11000),('holdout',91000)]:
        cases=[];records=[]
        for ni,n in enumerate((32,64,96,128)):
            for ti,task in enumerate(TASKS):
                case=make_case(n,task,offset+ni*100+ti)
                cid=f'{split}-n{n}-{task}';case['id']=cid;cases.append(case)
                for condition in CONDITIONS:
                    records.append({'id':cid+'-'+condition,'case_id':cid,'task':task,'n':n,
                                    'condition':condition,'ground_truth':case['answer'],'prompt':render(case,condition)})
        for name,data in [('cases',cases),('prompts',records)]:
            (output/f'{split}_{name}.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    manifest={'version':VERSION,'system_prompt':SYSTEM,'tasks':TASKS,'conditions':CONDITIONS,
              'development_cases':24,'holdout_cases':24,'prompts_per_split':96,
              'notes':'Development is for difficulty calibration. Holdout seeds are fixed separately. Semantic names are ranked degree cues, not guaranteed task-congruent roles.',
              'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in output.glob('*.json') if p.name!='manifest.json'}}
    (output/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('Generated 48 exact-answer cases, 192 prompts; holdout remains separate.')

if __name__ == '__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path(__file__).parent/'data')
    generate(parser.parse_args().output)
