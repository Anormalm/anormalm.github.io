"""Build an inspectable pilot report from saved responses, without API calls."""
import json
from pathlib import Path
from analyze import analyze

ROOT=Path(__file__).parent
def build():
    folders=[p for p in (ROOT/'runs').iterdir() if (p/'results.jsonl').exists()]
    text=['# Harder graph benchmark: Claude pilot','',
          'All numbers below come from saved API responses. This is exploratory difficulty calibration, not a leaderboard or a reproduction of the paper.','']
    total=0
    for folder in sorted(folders,key=lambda p:(p.name!='pilot01',p.name)):
        r=analyze(folder);total+=r['cost_usd']
        config=json.loads((folder/'config.json').read_text())['identity']
        text += [f'## {folder.name}', '',f'Split: {config["split"]}. Sizes: {config["sizes"]}. Output limit: {config["max_tokens"]:,} tokens. Reasoning: {config["reasoning"]["effort"]}; temperature: service default.', '',
                 '| Model | Responses | Correct | Completed wrong/invalid | Token cutoffs | Cost (USD) |',
                 '| --- | ---: | ---: | ---: | ---: | ---: |']
        for model,m in r['models'].items():
            wrong=m['requests']-m['correct']-m['truncated']-m['errors']
            text.append(f'| {model} | {m["requests"]} | {m["correct"]} | {wrong} | {m["truncated"]} | ${m["cost_usd"]:.4f} |')
        for model,m in r['models'].items():
            text += ['',f'### {model}', '', '| Task | Correct / returned |','| --- | ---: |']
            for task,s in m['tasks'].items():text.append(f'| {task} | {s["correct"]} / {s["n"]} |')
            text += ['', 'Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.','',
                     '| Measure | Value | Pairs |','| --- | ---: | ---: |']
            for k,s in {**m['consistency'],'conditional_survival':m['conditional_survival']}.items():
                value='undefined' if s['value'] is None else f'{s["value"]:.1%}'
                text.append(f'| {k} | {value} | {s["n"]} |')
            text += ['','Completed wrong examples (exploratory; see full records for every outcome):','']
            for e in m['completed_wrong_cases'][:4]:text.append(f'- `{e["case_id"]}` / {e["condition"]}: expected **{e["expected"]}**, returned **{e["answer"]}**.')
        text += ['',f'Raw records: `{folder.relative_to(ROOT)}/results.jsonl`. Answer-focused results: `answer_scored_results.json`; summary: `answer_scored_summary.json`.','']
    text += ['## Interpretation','',
             f'Total recorded inference cost: **US${total:.4f}**. The agent made no credit purchases.', '',
             'Correctness uses an explicit final JSON answer, even when preceded by explanation. Strict format compliance remains separate. Token cutoffs are counted separately from completed wrong answers. Earlier collector scores used strict JSON-only parsing; new collection uses the terminal answer directly. All reports apply the same answer-focused re-scoring.', '',
             'Naming changes preserve the exact graph and query. Both ordinary computational mistakes and invariance failures can occur. A harder task does not automatically demonstrate semantic-name interference. Inspect paired results before making that claim.', '',
             'The development seed set was used to choose follow-up tasks. Any subsequent holdout task choice is therefore a targeted validation, not a full unbiased test-suite estimate. Reachability controls all have negative labels in v1; do not generalize their accuracy. Future work should balance those labels and increase repeated graph samples.', '',
             'All question fixtures, exact answers, source seeds, model IDs, provider IDs, usage and settings are retained locally. The paper/poster and deployed website were not altered.']
    (ROOT/'REPORT.md').write_text('\n'.join(text)+'\n',encoding='utf-8')
    print(f'Report written: {sum(analyze(p)["requests"] for p in folders)} calls, ${total:.4f}.')

if __name__=='__main__':build()
