"""Freeze independent cases before any replication responses are observed."""
import hashlib
import itertools
import json
from pathlib import Path
import networkx as nx
from benchmark import make_case, render, answer, CONDITIONS

ROOT=Path(__file__).parent/'replication'
TASKS=['weighted_shortest_path','triangle_count','minimum_cut']

def generate():
    if (ROOT/'manifest.json').exists():raise SystemExit('Replication already frozen; refusing to overwrite.')
    ROOT.mkdir(exist_ok=True);cases=[];prompts=[]
    old_seeds={c['seed'] for p in (ROOT.parent/'data').glob('*_cases.json') for c in json.loads(p.read_text())}
    for n,ti,rep in itertools.product([32,64],range(3),range(4)):
        seed=410000+n*100+ti*10+rep
        assert seed not in old_seeds
        task=TASKS[ti];case=make_case(n,task,seed);case['id']=f'replication-n{n}-{task}-r{rep}';cases.append(case)
        g=nx.Graph();g.add_nodes_from(range(n));g.add_weighted_edges_from(case['edges'])
        # Independent checks on every selected query, not only failed examples.
        if task=='triangle_count':
            oracle=sum(all(g.has_edge(a,b) for a,b in itertools.combinations(trio,2)) for trio in itertools.combinations(g,3))
        elif task=='weighted_shortest_path':
            oracle=nx.floyd_warshall(g,weight='weight')[case['source']][case['target']]
        else:
            oracle=nx.maximum_flow_value(g,case['source'],case['target'],capacity='weight',flow_func=nx.algorithms.flow.edmonds_karp)
        assert oracle==case['answer']
        for condition in CONDITIONS:
            prompt=render(case,condition)
            labels=prompt.split('complete node set is:\n')[1].split('\nThe complete edge list')[0].split(', ')
            mapped=nx.relabel_nodes(g,dict(enumerate(labels)))
            assert answer(mapped,task,labels[case['source']],labels[case['target']],[],case['walk_length'])==case['answer']
            prompts.append({'id':case['id']+'-'+condition,'case_id':case['id'],'task':task,'n':n,'seed':seed,'replicate':rep,
                            'condition':condition,'ground_truth':case['answer'],'prompt':prompt})
    for name,data in [('cases',cases),('prompts',prompts)]:
        (ROOT/f'{name}.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    manifest={'version':'replication-v1','cases':len(cases),'prompts':len(prompts),'planned_models':['anthropic/claude-sonnet-5.5','anthropic/claude-opus-5.5'],
              'max_tokens':8192,'reasoning_effort':'high','selection':'Four independent seeds per task/size, all fixed before observing responses; tasks selected using earlier pilots.',
              'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.json')}}
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2))
    print(f'Frozen {len(cases)} independent cases and {len(prompts)} naming variants; every answer and remapping checked.')

if __name__=='__main__':generate()
