import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from repeat_analysis import build, ROOT

build()
main=json.loads((ROOT/'runs/replication01/answer_scored_results.json').read_text())
repeat=json.loads((ROOT/'runs/repeat_control01/answer_scored_results.json').read_text())
rows=[r for r in main+repeat if r['task']=='triangle_count']
models=list(dict.fromkeys(r['model'] for r in rows))
conditions=['original_repeat','neutral_relabel','semantic_congruent','semantic_incongruent']
labels=['Unchanged repeat','Neutral renaming','Degree-aligned names','Reverse-degree names']
fig,axes=plt.subplots(1,2,figsize=(12,4.8),sharey=True)
for ax,model in zip(axes,models):
    correct=[];wrong=[];cut=[]
    for condition in conditions:
        rr=[r for r in rows if r['model']==model and r['condition']==condition]
        assert len(rr)==8
        a=sum(r['correct'] for r in rr);b=sum(r['finish_reason']=='length' and not r['correct'] for r in rr)
        correct.append(a);cut.append(b);wrong.append(len(rr)-a-b)
    ax.barh(range(4),correct,color='#123348',label='Correct')
    ax.barh(range(4),wrong,left=correct,color='#c36537',label='Completed wrong')
    ax.barh(range(4),cut,left=[a+b for a,b in zip(correct,wrong)],color='#bbc2c7',label='Token cutoff')
    for i,a in enumerate(correct):ax.text(a/2,i,f'{a}/8',ha='center',va='center',color='white',weight='bold')
    ax.set_yticks(range(4),labels);ax.set_xticks(range(9));ax.set_xlim(0,8);ax.set_xlabel('Fixed graph questions');ax.set_title(model.split('/')[-1]);ax.spines[['top','right']].set_visible(False)
axes[0].invert_yaxis();handles,names=axes[0].get_legend_handles_labels()
fig.suptitle('Same eight triangle graphs: unchanged input versus renamed nodes',fontsize=15)
fig.legend(handles,names,loc='lower center',ncol=3,frameon=False)
fig.tight_layout(rect=[0,.09,1,.94])
out=ROOT/'runs/repeat_control01';fig.savefig(out/'naming_control.png',dpi=200);fig.savefig(out/'naming_control.svg')
print(out/'naming_control.png')
