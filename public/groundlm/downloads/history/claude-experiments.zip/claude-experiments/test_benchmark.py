import itertools
import json
import unittest
import networkx as nx
from benchmark import answer, make_case, render, CONDITIONS, TASKS
from run_pilot import parse, summary
from analyze import final_answer
from replication_analysis import estimate

class BenchmarkTests(unittest.TestCase):
    def test_perfect_small_sample_does_not_report_certainty(self):
        result=estimate([1]*4)
        self.assertEqual(result['value'],1)
        self.assertLess(result['ci95'][0],.6)
        self.assertGreater(result['ci95'][1],.99)
        self.assertEqual(result['bootstrap_ci95'],[1,1])
    def test_answers_against_independent_enumeration(self):
        g=nx.Graph();g.add_weighted_edges_from([(0,1,2),(1,2,3),(0,2,6),(2,3,1),(1,3,5)])
        paths=list(nx.all_simple_paths(g,0,3))
        distances=[len(p)-1 for p in paths]
        self.assertEqual(answer(g,'shortest_path_count',0,3,[],3),distances.count(min(distances)))
        self.assertEqual(answer(g,'weighted_shortest_path',0,3,[],3),min(sum(g[a][b]['weight'] for a,b in zip(p,p[1:])) for p in paths))
        self.assertEqual(answer(g,'triangle_count',0,3,[],3),sum(all(g.has_edge(a,b) for a,b in itertools.combinations(v,2)) for v in itertools.combinations(g,3)))
        walks=[p for p in itertools.product(g,repeat=2) if g.has_edge(0,p[0]) and g.has_edge(p[0],p[1]) and g.has_edge(p[1],3)]
        self.assertEqual(answer(g,'exact_walk_count',0,3,[],3),len(walks))
        cut=min(sum(d['weight'] for a,b,d in g.edges(data=True) if (a in subset)!=(b in subset)) for mask in range(4) for subset in [{0}|{v for i,v in enumerate([1,2]) if mask>>i&1}])
        self.assertEqual(answer(g,'minimum_cut',0,3,[],3),cut)
    def test_all_transformations_preserve_ground_truth(self):
        import re
        for task in TASKS:
            case=make_case(32,task,123)
            for condition in CONDITIONS:
                prompt=render(case,condition); edges=prompt.split('The complete edge list is:\n')[1].split('\n\nQuestion:')[0]
                h=nx.Graph()
                for line in edges.splitlines():
                    match=re.fullmatch(r'(\S+) -- (\S+)(?: \[weight=(\d+)\])?',line)
                    a,b,w=match.groups();h.add_edge(a,b,weight=int(w or 1))
                self.assertEqual(sorted(dict(h.degree()).values()),sorted(dict(nx.Graph([(a,b) for a,b,w in case['edges']]).degree()).values()))
                self.assertTrue(nx.is_isomorphic(h,nx.Graph([(a,b) for a,b,w in case['edges']])) )
                labels=prompt.split('complete node set is:\n')[1].split('\nThe complete edge list')[0].split(', ')
                self.assertEqual(answer(h,task,labels[case['source']],labels[case['target']],
                                        [labels[v] for v in case['blocked']],case['walk_length']),case['answer'])
    def test_strict_parsing_and_unclear_survival(self):
        self.assertEqual(parse('{"answer": 3}'),3)
        self.assertEqual(final_answer('Reasoning has 27 steps.\n{"answer": 3}'),3)
        self.assertIsNone(final_answer('I guess 3 after 27 steps.'))
        for value in ['{"answer":true}','3','Some thoughts: 3','{"answer":-1}']:self.assertIsNone(parse(value))
        rows=[{'model':'m','id':'a','case_id':'q','condition':c,'task':'t','status':'ok','parsed_answer':v,'correct':v==3,'finish_reason':'stop'} for c,v in [('original',3),('semantic_incongruent',None)]]
        result=summary(rows)['m'];self.assertEqual(result['conditional_survival'],{'value':0,'n':1});self.assertEqual(result['consistency']['semantic_incongruent']['n'],0)

if __name__=='__main__':unittest.main()
