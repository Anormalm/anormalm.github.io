# Harder graph benchmark: Claude pilot

All numbers below come from saved API responses. This is exploratory difficulty calibration, not a leaderboard or a reproduction of the paper.

## pilot01

Split: development. Sizes: [32, 96]. Output limit: 2,048 tokens. Reasoning: low; temperature: service default.

| Model | Responses | Correct | Completed wrong/invalid | Token cutoffs | Cost (USD) |
| --- | ---: | ---: | ---: | ---: | ---: |
| anthropic/claude-sonnet-5.5 | 48 | 26 | 11 | 11 | $0.8684 |
| anthropic/claude-opus-5.5 | 48 | 28 | 3 | 17 | $1.9365 |

### anthropic/claude-sonnet-5.5

| Task | Correct / returned |
| --- | ---: |
| weighted_shortest_path | 7 / 8 |
| shortest_path_count | 4 / 8 |
| exact_walk_count | 0 / 8 |
| triangle_count | 3 / 8 |
| minimum_cut | 4 / 8 |
| constrained_reachability | 8 / 8 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | 55.6% | 9 |
| semantic_congruent | 66.7% | 9 |
| semantic_incongruent | 66.7% | 9 |
| conditional_survival | 100.0% | 6 |

Completed wrong examples (exploratory; see full records for every outcome):

- `development-n32-triangle_count` / original: expected **25**, returned **26**.
- `development-n32-triangle_count` / semantic_congruent: expected **25**, returned **52**.
- `development-n32-minimum_cut` / original: expected **32**, returned **29**.
- `development-n32-minimum_cut` / neutral_relabel: expected **32**, returned **28**.

### anthropic/claude-opus-5.5

| Task | Correct / returned |
| --- | ---: |
| weighted_shortest_path | 7 / 8 |
| shortest_path_count | 3 / 8 |
| exact_walk_count | 0 / 8 |
| triangle_count | 2 / 8 |
| minimum_cut | 8 / 8 |
| constrained_reachability | 8 / 8 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | 100.0% | 7 |
| semantic_congruent | 87.5% | 8 |
| semantic_incongruent | 100.0% | 6 |
| conditional_survival | 75.0% | 8 |

Completed wrong examples (exploratory; see full records for every outcome):

- `development-n96-weighted_shortest_path` / semantic_congruent: expected **12**, returned **13**.
- `development-n96-exact_walk_count` / semantic_congruent: expected **1796345**, returned **6000000**.
- `development-n96-exact_walk_count` / semantic_incongruent: expected **1796345**, returned **11000000**.

Raw records: `runs\pilot01/results.jsonl`. Answer-focused results: `answer_scored_results.json`; summary: `answer_scored_summary.json`.

## holdout01

Split: holdout. Sizes: [96]. Output limit: 4,096 tokens. Reasoning: high; temperature: service default.

| Model | Responses | Correct | Completed wrong/invalid | Token cutoffs | Cost (USD) |
| --- | ---: | ---: | ---: | ---: | ---: |
| anthropic/claude-sonnet-5.5 | 12 | 8 | 0 | 4 | $0.3741 |
| anthropic/claude-opus-5.5 | 12 | 8 | 0 | 4 | $0.7583 |

### anthropic/claude-sonnet-5.5

| Task | Correct / returned |
| --- | ---: |
| weighted_shortest_path | 4 / 4 |
| triangle_count | 0 / 4 |
| minimum_cut | 4 / 4 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | 100.0% | 2 |
| semantic_congruent | 100.0% | 2 |
| semantic_incongruent | 100.0% | 2 |
| conditional_survival | 100.0% | 2 |

Completed wrong examples (exploratory; see full records for every outcome):


### anthropic/claude-opus-5.5

| Task | Correct / returned |
| --- | ---: |
| weighted_shortest_path | 4 / 4 |
| triangle_count | 0 / 4 |
| minimum_cut | 4 / 4 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | 100.0% | 2 |
| semantic_congruent | 100.0% | 2 |
| semantic_incongruent | 100.0% | 2 |
| conditional_survival | 100.0% | 2 |

Completed wrong examples (exploratory; see full records for every outcome):


Raw records: `runs\holdout01/results.jsonl`. Answer-focused results: `answer_scored_results.json`; summary: `answer_scored_summary.json`.

## holdout32

Split: holdout. Sizes: [32]. Output limit: 4,096 tokens. Reasoning: high; temperature: service default.

| Model | Responses | Correct | Completed wrong/invalid | Token cutoffs | Cost (USD) |
| --- | ---: | ---: | ---: | ---: | ---: |
| anthropic/claude-sonnet-5.5 | 8 | 7 | 1 | 0 | $0.1793 |
| anthropic/claude-opus-5.5 | 8 | 5 | 0 | 3 | $0.4546 |

### anthropic/claude-sonnet-5.5

| Task | Correct / returned |
| --- | ---: |
| triangle_count | 3 / 4 |
| minimum_cut | 4 / 4 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | 100.0% | 2 |
| semantic_congruent | 50.0% | 2 |
| semantic_incongruent | 100.0% | 2 |
| conditional_survival | 100.0% | 2 |

Completed wrong examples (exploratory; see full records for every outcome):

- `holdout-n32-triangle_count` / semantic_congruent: expected **27**, returned **29**.

### anthropic/claude-opus-5.5

| Task | Correct / returned |
| --- | ---: |
| triangle_count | 1 / 4 |
| minimum_cut | 4 / 4 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | 100.0% | 1 |
| semantic_congruent | 100.0% | 1 |
| semantic_incongruent | 100.0% | 1 |
| conditional_survival | 50.0% | 2 |

Completed wrong examples (exploratory; see full records for every outcome):


Raw records: `runs\holdout32/results.jsonl`. Answer-focused results: `answer_scored_results.json`; summary: `answer_scored_summary.json`.

## optimization01

Split: replication. Sizes: [24, 32]. Output limit: 8,192 tokens. Reasoning: high; temperature: service default.

| Model | Responses | Correct | Completed wrong/invalid | Token cutoffs | Cost (USD) |
| --- | ---: | ---: | ---: | ---: | ---: |
| anthropic/claude-opus-5.5 | 16 | 10 | 0 | 6 | $2.1632 |

### anthropic/claude-opus-5.5

| Task | Correct / returned |
| --- | ---: |
| minimum_vertex_cover | 10 / 16 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | 100.0% | 2 |
| semantic_congruent | 100.0% | 4 |
| semantic_incongruent | undefined | 0 |
| conditional_survival | 0.0% | 4 |

Completed wrong examples (exploratory; see full records for every outcome):


Raw records: `runs\optimization01/results.jsonl`. Answer-focused results: `answer_scored_results.json`; summary: `answer_scored_summary.json`.

## repeat_control01

Split: replication. Sizes: [32, 64]. Output limit: 8,192 tokens. Reasoning: high; temperature: service default.

| Model | Responses | Correct | Completed wrong/invalid | Token cutoffs | Cost (USD) |
| --- | ---: | ---: | ---: | ---: | ---: |
| anthropic/claude-sonnet-5.5 | 8 | 8 | 0 | 0 | $0.2442 |
| anthropic/claude-opus-5.5 | 8 | 8 | 0 | 0 | $0.6519 |

### anthropic/claude-sonnet-5.5

| Task | Correct / returned |
| --- | ---: |
| triangle_count | 8 / 8 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | undefined | 0 |
| semantic_congruent | undefined | 0 |
| semantic_incongruent | undefined | 0 |
| conditional_survival | undefined | 0 |

Completed wrong examples (exploratory; see full records for every outcome):


### anthropic/claude-opus-5.5

| Task | Correct / returned |
| --- | ---: |
| triangle_count | 8 / 8 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | undefined | 0 |
| semantic_congruent | undefined | 0 |
| semantic_incongruent | undefined | 0 |
| conditional_survival | undefined | 0 |

Completed wrong examples (exploratory; see full records for every outcome):


Raw records: `runs\repeat_control01/results.jsonl`. Answer-focused results: `answer_scored_results.json`; summary: `answer_scored_summary.json`.

## replication01

Split: replication. Sizes: [32, 64]. Output limit: 8,192 tokens. Reasoning: high; temperature: service default.

| Model | Responses | Correct | Completed wrong/invalid | Token cutoffs | Cost (USD) |
| --- | ---: | ---: | ---: | ---: | ---: |
| anthropic/claude-sonnet-5.5 | 96 | 87 | 7 | 2 | $2.7776 |
| anthropic/claude-opus-5.5 | 96 | 91 | 0 | 5 | $6.3353 |

### anthropic/claude-sonnet-5.5

| Task | Correct / returned |
| --- | ---: |
| weighted_shortest_path | 32 / 32 |
| triangle_count | 23 / 32 |
| minimum_cut | 32 / 32 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | 95.8% | 24 |
| semantic_congruent | 86.4% | 22 |
| semantic_incongruent | 87.5% | 24 |
| conditional_survival | 87.5% | 24 |

Completed wrong examples (exploratory; see full records for every outcome):

- `replication-n32-triangle_count-r2` / semantic_congruent: expected **27**, returned **26**.
- `replication-n32-triangle_count-r3` / semantic_congruent: expected **26**, returned **25**.
- `replication-n64-triangle_count-r0` / semantic_incongruent: expected **33**, returned **32**.
- `replication-n64-triangle_count-r1` / semantic_incongruent: expected **31**, returned **30**.

### anthropic/claude-opus-5.5

| Task | Correct / returned |
| --- | ---: |
| weighted_shortest_path | 32 / 32 |
| triangle_count | 27 / 32 |
| minimum_cut | 32 / 32 |

Consistency compares parsed answers; conditional survival counts initially correct pairs with a returned semantic counterpart. Small denominators make these pilot estimates unstable.

| Measure | Value | Pairs |
| --- | ---: | ---: |
| neutral | 100.0% | 24 |
| semantic_congruent | 100.0% | 21 |
| semantic_incongruent | 100.0% | 22 |
| conditional_survival | 91.7% | 24 |

Completed wrong examples (exploratory; see full records for every outcome):


Raw records: `runs\replication01/results.jsonl`. Answer-focused results: `answer_scored_results.json`; summary: `answer_scored_summary.json`.

## Interpretation

Total recorded inference cost: **US$16.7435**. The agent made no credit purchases.

Correctness uses an explicit final JSON answer, even when preceded by explanation. Strict format compliance remains separate. Token cutoffs are counted separately from completed wrong answers. Earlier collector scores used strict JSON-only parsing; new collection uses the terminal answer directly. All reports apply the same answer-focused re-scoring.

Naming changes preserve the exact graph and query. Both ordinary computational mistakes and invariance failures can occur. A harder task does not automatically demonstrate semantic-name interference. Inspect paired results before making that claim.

The development seed set was used to choose follow-up tasks. Any subsequent holdout task choice is therefore a targeted validation, not a full unbiased test-suite estimate. Reachability controls all have negative labels in v1; do not generalize their accuracy. Future work should balance those labels and increase repeated graph samples.

All question fixtures, exact answers, source seeds, model IDs, provider IDs, usage and settings are retained locally. The paper/poster and deployed website were not altered.
