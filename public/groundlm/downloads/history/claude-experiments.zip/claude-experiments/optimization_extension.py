"""Freeze four exact minimum-vertex-cover cases, with two independent solvers."""
import hashlib
import json
from pathlib import Path
import networkx as nx
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from benchmark import make_case, render, CONDITIONS

ROOT=Path(__file__).parent/'optimization'

def solve(g):
    n=len(g);matrix=np.zeros((len(g.edges),n))
    for i,(a,b) in enumerate(g.edges):matrix[i,a]=matrix[i,b]=1
    result=milp(np.ones(n),integrality=np.ones(n),bounds=Bounds(0,1),
                constraints=LinearConstraint(matrix,1,np.inf),options={'mip_rel_gap':0,'time_limit':60})
    if not result.success or result.mip_gap>1e-9:raise RuntimeError('Exact optimum not established.')
    independent=max(nx.find_cliques(nx.complement(g)),key=len)
    optimum=n-len(independent);cover=[v for v in g if v not in independent]
    assert abs(result.fun-optimum)<1e-6
    assert all(a in cover or b in cover for a,b in g.edges)
    return optimum,{'minimum_cover':cover,'maximum_independent_set':independent,'milp_objective':float(result.fun),
                    'milp_lower_bound':float(result.mip_dual_bound),'milp_gap':float(result.mip_gap)}

def generate():
    if (ROOT/'manifest.json').exists():raise SystemExit('Optimization fixtures already frozen.')
    ROOT.mkdir(exist_ok=True);cases=[];prompts=[]
    for n in [24,32]:
        for rep in range(2):
            seed=730000+n*100+rep
            case=make_case(n,'triangle_count',seed)
            g=nx.Graph();g.add_nodes_from(range(n));g.add_edges_from((a,b) for a,b,w in case['edges'])
            value,certificate=solve(g)
            cid=f'optimization-n{n}-vertex_cover-r{rep}'
            cases.append({**case,'id':cid,'task':'minimum_vertex_cover','answer':value,'certificate':certificate})
            for condition in CONDITIONS:
                base=render(case,condition).split('\n\nQuestion:')[0]
                question=('What is the minimum number of vertices in a vertex cover? A vertex cover is a set of vertices '
                          'such that every listed edge has at least one endpoint in the set. Minimize the number of selected vertices; '
                          'do not return a maximal or merely locally minimal cover. Return only {"answer": INTEGER}.')
                prompts.append({'id':cid+'-'+condition,'case_id':cid,'task':'minimum_vertex_cover','n':n,'seed':seed,'replicate':rep,
                                'condition':condition,'ground_truth':value,'prompt':base+'\n\nQuestion: '+question})
    for name,data in [('cases',cases),('prompts',prompts)]:
        (ROOT/f'{name}.json').write_text(json.dumps(data,indent=2))
    manifest={'version':'optimization-v1','cases':4,'prompts':16,'planned_models':['anthropic/claude-opus-5.5'],'planned_requests':16,'max_tokens':8192,'reasoning_effort':'high',
              'selection':'All four fresh fixed seeds, before any optimization inference. Separate exploratory task extension.',
              'oracle':'Integer program solved to zero gap, cross-checked by exhaustive maximal-clique enumeration on the complement graph.',
              'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.json')}}
    (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2));print('Frozen 4 exact optimization cases, 16 variants, 32 planned model requests.')

if __name__=='__main__':generate()
