"""Answer-focused scoring of immutable raw outputs, with format compliance separate."""
import argparse
import json
import re
from pathlib import Path
from run_pilot import parse, summary, final_answer

def analyze(folder):
    rows=[json.loads(line) for line in (folder/'results.jsonl').read_text().splitlines()]
    for row in rows:
        if row['status']=='ok':
            row['format_compliant']=parse(row['model_answer']) is not None
            row['parsed_answer']=final_answer(row['model_answer'])
            row['correct']=row['parsed_answer']==row['ground_truth']
    result={'scoring':'Final explicit JSON answer; original strict-format fields preserved in results.jsonl.',
            'requests':len(rows),'cost_usd':sum(r['cost_usd'] for r in rows),'models':summary(rows)}
    for model,stats in result['models'].items():
        subset=[r for r in rows if r['model']==model and r['status']=='ok']
        stats['format_compliant']=sum(r['format_compliant'] for r in subset)
        completed=[r for r in subset if r['finish_reason']!='length']
        stats['completed_accuracy']={'correct':sum(r['correct'] for r in completed),'n':len(completed)}
        stats['completed_wrong_cases']=[{'case_id':r['case_id'],'condition':r['condition'],'expected':r['ground_truth'],'answer':r['parsed_answer']} for r in completed if r['parsed_answer'] is not None and not r['correct']]
    (folder/'answer_scored_summary.json').write_text(json.dumps(result,indent=2))
    (folder/'answer_scored_results.json').write_text(json.dumps(rows,indent=2))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('folder',type=Path);args=p.parse_args()
    print(json.dumps(analyze(args.folder),indent=2))
