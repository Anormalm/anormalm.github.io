import json
from pathlib import Path
from analyze import analyze
from run_pilot import final_answer

ROOT=Path(__file__).parent;RUN=ROOT/'runs/optimization01'

def build():
    result=analyze(RUN);rows=json.loads((RUN/'answer_scored_results.json').read_text())
    cases=json.loads((ROOT/'optimization/cases.json').read_text());evidence=[]
    lines=['# Exploratory minimum-vertex-cover extension','',
           'Four fresh exact optimization questions, each with four naming variants. Opus 5.5 only, high reasoning effort requested, 8,192 output tokens, no tools. This task was chosen after observing easier-task performance; it is exploratory difficulty development.','',
           'Each ground truth was cross-checked by a zero-gap integer program and exhaustive maximal-clique enumeration of the complement graph. Feasible minimum covers and solver bounds are retained in optimization/cases.json.','',
           f'{len(rows)}/16 responses; recorded cost US${result["cost_usd"]:.4f}.','',
           '| Case | Exact answer | Original | Neutral rename | Degree-aligned | Reverse-degree |',
           '| --- | ---: | --- | --- | --- | --- |']
    for case in cases:
        group={r['condition']:r for r in rows if r['case_id']==case['id']}
        cells=[]
        for c in ['original','neutral_relabel','semantic_congruent','semantic_incongruent']:
            r=group.get(c)
            if not r:cell='pending'
            elif r['status']!='ok':cell='API error'
            elif r['finish_reason']=='length':cell='cutoff'
            elif r['parsed_answer'] is None:cell='invalid final answer'
            else:cell=str(r['parsed_answer'])+(' (correct)' if r['correct'] else ' (wrong)')
            cells.append(cell)
            if r and r['status']=='ok' and r['finish_reason']!='length' and r['parsed_answer'] is not None and not r['correct']:
                evidence.append({'response':r,'oracle_case':case})
        lines.append('| '+case['id']+' | '+str(case['answer'])+' | '+' | '.join(cells)+' |')
    for model,m in result['models'].items():
        lines += ['',f'{model}: {m["correct"]}/{m["requests"]} correct; {m["truncated"]} cutoffs; {len(m["completed_wrong_cases"])} completed numeric errors.']
    lines += ['','Cutoffs indicate failure within the tested inference budget, not a completed wrong calculation. An exact optimum can require substantial search. These results must not be pooled with the earlier task accuracy as a single unbiased leaderboard.']
    (ROOT/'OPTIMIZATION_REPORT.md').write_text('\n'.join(lines)+'\n')
    (RUN/'completed_error_evidence.json').write_text(json.dumps(evidence,indent=2))
    print(json.dumps({'responses':len(rows),'cost':result['cost_usd'],'completed_numeric_errors':len(evidence)}))
    return result

if __name__=='__main__':build()
